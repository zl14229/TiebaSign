# AIS 实时接入与轨迹查询系统（后端）实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 从零构建 AIS 后端：多基站 TCP 接入并解析 NMEA → 去重 → WebSocket 实时推送 + Redis 最新船位快照 + 电子围栏进出告警 + PostgreSQL(+PostGIS) 批量落库（保留 1 个月），并提供轨迹/最新船位/围栏/船舶等 REST API 与 JWT 鉴权。

**Architecture:** 单一 Go 二进制（module `ais`）同时承担 gateway（接入/解析/状态机/写入）与 api（REST/WS）职责，代码按包分层隔离，为后续拆分与水平扩展预留。PostgreSQL 为唯一数据库（轨迹按天分区 + PostGIS GIST 索引），Redis 承担最新船位哈希、围栏船舶集合与 pub/sub 扇出，Nginx 负责 TLS/WSS 与反向代理，Docker Compose 一键编排。前端（地图 UI）为独立子任务，不在本计划内。

**Tech Stack:**
- Go 1.22+（标准库 `net/http` 方法路由 + `log/slog`），module 名 `ais`
- `github.com/BertoldVdb/go-ais` v0.4.0（NMEA VDM/VDO 解析 + 多句重组）
- `github.com/jackc/pgx/v5` v5.7.1（PostgreSQL 驱动/连接池）
- `github.com/redis/go-redis/v9` v9.7.0（Redis）
- `github.com/gorilla/websocket` v1.5.3（WebSocket）
- `github.com/golang-jwt/jwt/v5` v5.2.1（JWT）
- `github.com/paulmach/orb` v0.11.1（GeoJSON 编解码与空间数据结构）
- `github.com/prometheus/client_golang` v1.20.5（指标）
- `golang.org/x/crypto` v0.31.0（bcrypt）
- 测试：`github.com/alicebob/miniredis/v2` v2.33.0
- 部署镜像：`postgis/postgis:16-3.4`、`redis:7-alpine`、`nginx:1.27-alpine`、`prom/prometheus:v2.53.0`、`grafana/grafana:11.1.0`

## Global Constraints

- 项目根目录：`E:\Codes\dev\ais`（`E:\Codes\dev` 根目录存在旧 Java 骨架，**不得改动**；Go 工程全部放在 `ais/` 子目录内）。
- **不使用 git（用户明确要求）**：本计划所有任务**没有 Commit 步骤**；每个任务的"验收"= 执行 `go build ./...`、`go test ./...`（或任务内指定的命令）并确认输出符合预期。
- Go 版本 ≥ 1.22：`go.mod` 声明 `go 1.22`；本机若未安装 Go，按 Task 1 Step 1 安装。
- 单一 PostgreSQL 数据库（含 PostGIS 扩展），**不使用 ClickHouse 或其他数据库**。
- 轨迹数据保留 1 个月：`ais_positions` 按天分区，超期分区由例行任务删除；`fence_events` 同样删除 30 天前的数据。
- 经纬度校验：`lat ∈ [-90, 90]`、`lon ∈ [-180, 180]`；越界（含 AIS "不可用" 哨兵值 lat=91/lon=181）丢弃该位置并计入解析指标，不中断链路。
- 所有配置通过环境变量（前缀 `AIS_*`）注入，见 `ais/.env.example`；禁止硬编码连接串。
- 业务日志统一使用 `log/slog`（JSON 输出）；禁止使用 `fmt.Println` 打印业务日志。
- 坐标系约定：应用内存与 GeoJSON 均使用 `[lon, lat]`（`orb.Point` 约定）；PostGIS 列 `geometry(Point/Polygon, 4326)`。
- 前端（地图 UI）为独立子任务，本计划不包含任何前端代码；Nginx 的 `/ui/` 仅提供占位页。
- 每个任务依赖前一任务的产物；任务实现者只读自己的任务 + Interfaces 块，不要假设其他任务细节。

---

## 文件地图（最终工程结构）

```
ais/
  go.mod / go.sum / .env.example / README.md
  Dockerfile
  cmd/ais/main.go                     # 子命令: run / user-create / maintenance
  internal/
    config/config.go, config_test.go  # 环境变量配置
    logging/logging.go                # slog JSON logger
    model/model.go                    # 领域类型（Position/Vessel/Geofence/FenceEvent/...）
    nmea/parser.go, parser_test.go    # go-ais 封装
    dedup/dedup.go, dedup_test.go     # 30s 窗口去重
    station/station.go, station_test.go  # 多基站 TCP 连接管理
    store/store.go                    # 仓储接口 + ErrNotFound
    store/pg/pg.go                    # 连接池
    store/pg/migrate.go               # 内嵌 SQL 迁移执行器
    store/pg/migrations/0001_init.sql # 全部 DDL
    store/pg/partman.go, partman_test.go # 分区维护
    store/pg/positions.go             # InsertBatch / Track / LatestFallback / FenceHistoryVessels
    store/pg/writer.go, writer_test.go   # 批量写入器
    store/pg/geofences.go             # 围栏与事件仓储
    store/pg/vessels.go               # 船舶元数据仓储
    store/pg/users.go                 # 用户仓储
    cache/redis.go, redis_test.go     # Redis 快照/集合/pubsub
    wshub/hub.go, hub_test.go         # WebSocket hub
    api/server.go                     # 路由与依赖装配
    api/response.go                   # JSON 响应助手
    api/auth.go, auth_test.go         # JWT
    api/handlers.go                   # login/track/latest/vessels/base-stations
    api/handlers_geofences.go         # 围栏 CRUD 与查询
    api/handlers_test.go, handlers_geofences_test.go
    fence/geo.go, geo_test.go         # 点-多边形判断
    fence/engine.go, engine_test.go   # 围栏状态机
    pipeline/pipeline.go, pipeline_test.go  # 基站行 → 解析/去重/扇出管道
    metrics/metrics.go                # Prometheus 指标
  deployment/
    docker-compose.yml
    nginx/default.conf
    prometheus/prometheus.yml
    grafana/provisioning/datasources/prometheus.yml
    grafana/provisioning/dashboards/dashboards.yaml
    grafana/provisioning/dashboards/ais.json
    backup/Dockerfile, backup/backup.sh
```

任务依赖顺序：T1 → T2 → T3 → T4 → T5 → T6 → T7 → T8 → T9 → T10 → T11 → T12 → T13。

---

### Task 1: 环境准备、工程骨架、配置与日志

**Files:**
- Create: `ais/go.mod`
- Create: `ais/.env.example`
- Create: `ais/internal/config/config.go`
- Create: `ais/internal/config/config_test.go`
- Create: `ais/internal/logging/logging.go`

**Interfaces:**
- Produces: `config.Config` 结构体（全部字段见下）；`func Load() (config.Config, error)`；`logging.New(level string) *slog.Logger`。
- Consumes: 无（本任务自包含）。

- [ ] **Step 1: 安装 Go 1.22+ 并验证环境**

如果 `go version` 已输出 ≥ go1.22 则跳过。Windows 安装：
```powershell
winget install GoLang.Go
# 或从 https://go.dev/dl/ 下载 go1.22+ Windows amd64 安装包
```
验证：
```powershell
go version
```
Expected: 输出 `go version go1.22.x ...` 或更高。

- [ ] **Step 2: 创建 go.mod 与 .env.example**

创建 `ais/go.mod`：
```
module ais

go 1.22

require (
	github.com/BertoldVdb/go-ais v0.4.0
	github.com/alicebob/miniredis/v2 v2.33.0
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/gorilla/websocket v1.5.3
	github.com/jackc/pgx/v5 v5.7.1
	github.com/paulmach/orb v0.11.1
	github.com/prometheus/client_golang v1.20.5
	github.com/redis/go-redis/v9 v9.7.0
	golang.org/x/crypto v0.31.0
)
```

创建 `ais/.env.example`：
```bash
# --- PostgreSQL ---
POSTGRES_PASSWORD=ais

# --- App ---
AIS_HTTP_ADDR=0.0.0.0:8080
AIS_LOG_LEVEL=info
AIS_DB_URL=postgres://ais:ais@localhost:5432/ais?sslmode=disable
AIS_REDIS_ADDR=localhost:6379
AIS_REDIS_PASSWORD=
AIS_JWT_SECRET=change-me-to-a-long-random-string
AIS_JWT_TTL=24h
AIS_STATIONS=[{"id":"st1","name":"主站","host":"10.0.0.10","port":4001,"enabled":true}]
AIS_WRITER_FLUSH_INTERVAL=1s
AIS_WRITER_BATCH_SIZE=1000
AIS_WRITER_QUEUE_SIZE=100000
AIS_RETENTION_DAYS=30
AIS_FENCE_RELOAD_INTERVAL=60s
AIS_FENCE_SILENCE_TIMEOUT=5m
AIS_FENCE_DEBOUNCE_COUNT=2
AIS_STATION_CONNECT_TIMEOUT=10s
AIS_STATION_RECONNECT_BASE=1s
AIS_STATION_RECONNECT_MAX=60s
AIS_STATION_IDLE_TIMEOUT=5m

# --- OSS 备份（可选）---
OSS_ENDPOINT=
OSS_BUCKET=
OSS_ACCESS_KEY_ID=
OSS_ACCESS_KEY_SECRET=

# --- Grafana ---
GRAFANA_ADMIN_PASSWORD=admin
```

- [ ] **Step 3: 写失败测试**

创建 `ais/internal/config/config_test.go`：
```go
package config

import (
	"os"
	"strings"
	"testing"
	"time"
)

func clearAISEnv(t *testing.T) {
	t.Helper()
	for _, kv := range os.Environ() {
		k := kv[:strings.Index(kv, "=")]
		if strings.HasPrefix(k, "AIS_") {
			os.Unsetenv(k)
		}
	}
}

func TestLoad_defaults(t *testing.T) {
	clearAISEnv(t)
	c, err := Load()
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if c.HTTPAddr != "0.0.0.0:8080" {
		t.Errorf("HTTPAddr = %q, want 0.0.0.0:8080", c.HTTPAddr)
	}
	if c.RetentionDays != 30 {
		t.Errorf("RetentionDays = %d, want 30", c.RetentionDays)
	}
	if c.WriterBatchSize != 1000 {
		t.Errorf("WriterBatchSize = %d, want 1000", c.WriterBatchSize)
	}
	if c.WriterFlushInterval != time.Second {
		t.Errorf("WriterFlushInterval = %v, want 1s", c.WriterFlushInterval)
	}
	if c.FenceDebounceCount != 2 {
		t.Errorf("FenceDebounceCount = %d, want 2", c.FenceDebounceCount)
	}
	if c.FenceSilenceTimeout != 5*time.Minute {
		t.Errorf("FenceSilenceTimeout = %v, want 5m", c.FenceSilenceTimeout)
	}
	if len(c.Stations) != 0 {
		t.Errorf("Stations = %v, want empty", c.Stations)
	}
}

func TestLoad_envOverrides(t *testing.T) {
	clearAISEnv(t)
	t.Setenv("AIS_HTTP_ADDR", ":9999")
	t.Setenv("AIS_JWT_TTL", "2h")
	t.Setenv("AIS_RETENTION_DAYS", "45")
	t.Setenv("AIS_STATIONS", `[{"id":"s1","name":"n","host":"1.2.3.4","port":4001,"enabled":true}]`)
	c, err := Load()
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if c.HTTPAddr != ":9999" {
		t.Errorf("HTTPAddr = %q, want :9999", c.HTTPAddr)
	}
	if c.JWTTTL != 2*time.Hour {
		t.Errorf("JWTTTL = %v, want 2h", c.JWTTTL)
	}
	if c.RetentionDays != 45 {
		t.Errorf("RetentionDays = %d, want 45", c.RetentionDays)
	}
	if len(c.Stations) != 1 || c.Stations[0].Host != "1.2.3.4" {
		t.Errorf("Stations = %+v, want one station with host 1.2.3.4", c.Stations)
	}
}

func TestLoad_invalidDuration(t *testing.T) {
	clearAISEnv(t)
	t.Setenv("AIS_JWT_TTL", "not-a-duration")
	if _, err := Load(); err == nil {
		t.Fatal("Load() expected error for invalid AIS_JWT_TTL")
	}
}
```

- [ ] **Step 4: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/config/...
```
Expected: FAIL（`config.go` 不存在 / 编译错误 `undefined: Load`）。

- [ ] **Step 5: 实现 config 与 logging**

创建 `ais/internal/config/config.go`：
```go
// Package config loads all runtime configuration from AIS_* environment variables.
package config

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"
)

type Station struct {
	ID      string `json:"id"`
	Name    string `json:"name"`
	Host    string `json:"host"`
	Port    int    `json:"port"`
	Enabled bool   `json:"enabled"`
}

type Config struct {
	HTTPAddr              string
	LogLevel              string
	DBURL                 string
	RedisAddr             string
	RedisPassword         string
	JWTSecret             string
	JWTTTL                time.Duration
	Stations              []Station
	WriterFlushInterval   time.Duration
	WriterBatchSize       int
	WriterQueueSize       int
	RetentionDays         int
	FenceReloadInterval   time.Duration
	FenceSilenceTimeout   time.Duration
	FenceDebounceCount    int
	StationConnectTimeout time.Duration
	StationReconnectBase  time.Duration
	StationReconnectMax   time.Duration
	StationIdleTimeout    time.Duration
	MetricsAddr           string
}

func Load() (Config, error) {
	c := Config{
		HTTPAddr:              "0.0.0.0:8080",
		LogLevel:              "info",
		DBURL:                 "postgres://ais:ais@localhost:5432/ais?sslmode=disable",
		RedisAddr:             "localhost:6379",
		JWTSecret:             "dev-secret-change-me",
		JWTTTL:                24 * time.Hour,
		WriterFlushInterval:   time.Second,
		WriterBatchSize:       1000,
		WriterQueueSize:       100000,
		RetentionDays:         30,
		FenceReloadInterval:   time.Minute,
		FenceSilenceTimeout:   5 * time.Minute,
		FenceDebounceCount:    2,
		StationConnectTimeout: 10 * time.Second,
		StationReconnectBase:  time.Second,
		StationReconnectMax:   60 * time.Second,
		StationIdleTimeout:    5 * time.Minute,
		MetricsAddr:           "0.0.0.0:9090",
	}
	var err error
	if v := os.Getenv("AIS_HTTP_ADDR"); v != "" {
		c.HTTPAddr = v
	}
	if v := os.Getenv("AIS_LOG_LEVEL"); v != "" {
		c.LogLevel = v
	}
	if v := os.Getenv("AIS_DB_URL"); v != "" {
		c.DBURL = v
	}
	if v := os.Getenv("AIS_REDIS_ADDR"); v != "" {
		c.RedisAddr = v
	}
	if v := os.Getenv("AIS_REDIS_PASSWORD"); v != "" {
		c.RedisPassword = v
	}
	if v := os.Getenv("AIS_JWT_SECRET"); v != "" {
		c.JWTSecret = v
	}
	if v := os.Getenv("AIS_JWT_TTL"); v != "" {
		if c.JWTTTL, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_JWT_TTL: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATIONS"); v != "" {
		if err := json.Unmarshal([]byte(v), &c.Stations); err != nil {
			return c, fmt.Errorf("AIS_STATIONS: %w", err)
		}
	}
	if v := os.Getenv("AIS_WRITER_FLUSH_INTERVAL"); v != "" {
		if c.WriterFlushInterval, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_WRITER_FLUSH_INTERVAL: %w", err)
		}
	}
	if v := os.Getenv("AIS_WRITER_BATCH_SIZE"); v != "" {
		if c.WriterBatchSize, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_WRITER_BATCH_SIZE: %w", err)
		}
	}
	if v := os.Getenv("AIS_WRITER_QUEUE_SIZE"); v != "" {
		if c.WriterQueueSize, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_WRITER_QUEUE_SIZE: %w", err)
		}
	}
	if v := os.Getenv("AIS_RETENTION_DAYS"); v != "" {
		if c.RetentionDays, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_RETENTION_DAYS: %w", err)
		}
	}
	if v := os.Getenv("AIS_FENCE_RELOAD_INTERVAL"); v != "" {
		if c.FenceReloadInterval, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_FENCE_RELOAD_INTERVAL: %w", err)
		}
	}
	if v := os.Getenv("AIS_FENCE_SILENCE_TIMEOUT"); v != "" {
		if c.FenceSilenceTimeout, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_FENCE_SILENCE_TIMEOUT: %w", err)
		}
	}
	if v := os.Getenv("AIS_FENCE_DEBOUNCE_COUNT"); v != "" {
		if c.FenceDebounceCount, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_FENCE_DEBOUNCE_COUNT: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_CONNECT_TIMEOUT"); v != "" {
		if c.StationConnectTimeout, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_CONNECT_TIMEOUT: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_RECONNECT_BASE"); v != "" {
		if c.StationReconnectBase, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_RECONNECT_BASE: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_RECONNECT_MAX"); v != "" {
		if c.StationReconnectMax, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_RECONNECT_MAX: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_IDLE_TIMEOUT"); v != "" {
		if c.StationIdleTimeout, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_IDLE_TIMEOUT: %w", err)
		}
	}
	if v := os.Getenv("AIS_METRICS_ADDR"); v != "" {
		c.MetricsAddr = v
	}
	return c, nil
}
```

创建 `ais/internal/logging/logging.go`：
```go
// Package logging builds the application-wide slog JSON logger.
package logging

import (
	"log/slog"
	"os"
	"strings"
)

func New(level string) *slog.Logger {
	var lv slog.Level
	switch strings.ToLower(level) {
	case "debug":
		lv = slog.LevelDebug
	case "warn":
		lv = slog.LevelWarn
	case "error":
		lv = slog.LevelError
	default:
		lv = slog.LevelInfo
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: lv}))
}
```

- [ ] **Step 6: 运行测试确认通过 + 拉取依赖**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/config/...
```
Expected: PASS（3 个测试）。

- [ ] **Step 7: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出（成功），exit code 0。

---

### Task 2: 领域模型与 NMEA 解析

**Files:**
- Create: `ais/internal/model/model.go`
- Create: `ais/internal/nmea/parser.go`
- Create: `ais/internal/nmea/parser_test.go`

**Interfaces:**
- Consumes: 无（仅依赖第三方库）。
- Produces（后续任务依赖的精确类型）：
  - `model.Position{MMSI uint32; Ts time.Time; Lat, Lon float64; SOG, COG float32; Heading, NavStatus, MsgType int16; Source string}`
  - `model.Vessel{MMSI uint32; Name string; IMO *uint32; Callsign string; ShipType int16; LengthM, BeamM float32; UpdatedAt time.Time}`
  - `model.TrackPoint{Ts time.Time; Lat, Lon float64; SOG float32}`
  - `model.Geofence{ID int64; Name string; Area geojson.Geometry; Enabled, EnterAlert, LeaveAlert bool; DebounceCount int; SilenceTimeoutMin int; CreatedAt time.Time}`
  - `model.FenceEvent{ID, FenceID int64; MMSI uint32; EventType int16; Ts time.Time; Lat, Lon float64}`，常量 `model.EventTypeEnter = 1`、`model.EventTypeLeave = 2`
  - `model.User{ID int64; Username, PasswordHash, Role string; CreatedAt time.Time}`
  - `model.BaseStation{ID int64; Name, Host string; Port int; Enabled bool}`
  - `nmea.NewParser() *nmea.Parser`；`(*Parser).Parse(raw string, station string, ts time.Time) (*nmea.Result, error)`；`nmea.Result{Position *model.Position; Vessel *model.Vessel}`。

**说明（go-ais v0.4.0 已核实的 API）**：`aisnmea.NMEACodecNew(ais.CodecNew(false, false))`；`codec.ParseSentence(raw)` 返回 `(*VdmPacket, error)`——多句消息收到中间片段时返回 `(nil, nil)`，完整消息解码后返回非 nil；`VdmPacket.Packet` 为 `ais.Packet`（解码失败时为 nil）。`Field10` 与 `FieldLatLonFine` 解码后**已换算为实际数值/度数**（如 `PositionReport.Sog` 即节，`Latitude` 即度），无需再除以 10 或 600000。

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/nmea/parser_test.go`：
```go
package nmea

import (
	"math"
	"testing"
	"time"
)

// 以下语句来自 go-ais v0.4.0 测试数据（aisnmea/testdata/aistest.nmea）与
// decode_test.go，校验和均有效，解码期望值已交叉验证。
const (
	sentenceType1  = "!AIVDM,1,1,,B,177KQJ5000G?tO`K>RA1wUbN0TKH,0*5C"
	sentenceType5A = "!AIVDM,2,1,6,B,53Jmvl82Bw3CTP7??K5<D5<lThF222222222221:I0oK;4e20L3FH42i,0*5C"
	sentenceType5B = "!AIVDM,2,2,6,B,p88888888888880,2*69"
	sentenceType18 = "!AIVDM,1,1,,B,B52KlJP00=l4bhUItIG?Gwl5WP06,0*03"
	sentenceType24A = "!AIVDM,1,1,,B,H6:iQG@p4q@tpO?K;P000000000,2*4D"
	sentenceNoPosition = "!AIVDM,1,1,,B,177nTc10?w<tSF0l4Q@>43Qv0>`<,0*6C" // lat=91 lon=181 哨兵
	sentenceNonVDM  = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A"
)

func approx(a, b, eps float64) bool { return math.Abs(a-b) < eps }

func TestParse_positionReportType1(t *testing.T) {
	p := NewParser()
	ts := time.Date(2026, 8, 7, 10, 0, 0, 0, time.UTC)
	res, err := p.Parse(sentenceType1, "st1", ts)
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res == nil || res.Position == nil {
		t.Fatal("expected a position result")
	}
	got := res.Position
	if got.MMSI != 477553000 {
		t.Errorf("MMSI = %d, want 477553000", got.MMSI)
	}
	if got.MsgType != 1 {
		t.Errorf("MsgType = %d, want 1", got.MsgType)
	}
	if !approx(got.Lat, 47.582833, 1e-6) {
		t.Errorf("Lat = %v, want ~47.582833", got.Lat)
	}
	if !approx(got.Lon, -122.345833, 1e-6) {
		t.Errorf("Lon = %v, want ~-122.345833", got.Lon)
	}
	if !approx(float64(got.COG), 51.0, 1e-6) {
		t.Errorf("COG = %v, want 51.0", got.COG)
	}
	if got.Heading != 181 {
		t.Errorf("Heading = %d, want 181", got.Heading)
	}
	if got.NavStatus != 5 {
		t.Errorf("NavStatus = %d, want 5", got.NavStatus)
	}
	if got.Source != "st1" {
		t.Errorf("Source = %q, want st1", got.Source)
	}
	if !got.Ts.Equal(ts) {
		t.Errorf("Ts = %v, want %v", got.Ts, ts)
	}
}

func TestParse_classBPositionReportType18(t *testing.T) {
	p := NewParser()
	res, err := p.Parse(sentenceType18, "st2", time.Now())
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res == nil || res.Position == nil {
		t.Fatal("expected a position result")
	}
	if res.Position.MMSI != 338097258 {
		t.Errorf("MMSI = %d, want 338097258", res.Position.MMSI)
	}
	if !approx(res.Position.Lat, 37.786275, 1e-6) || !approx(res.Position.Lon, -122.270132, 1e-6) {
		t.Errorf("position = (%v, %v), want (~37.786275, ~-122.270132)", res.Position.Lat, res.Position.Lon)
	}
}

func TestParse_multiSentenceType5(t *testing.T) {
	p := NewParser()
	ts := time.Now()
	res, err := p.Parse(sentenceType5A, "st3", ts)
	if err != nil {
		t.Fatalf("Parse() fragment error = %v", err)
	}
	if res != nil {
		t.Fatalf("expected nil result for first fragment, got %+v", res)
	}
	res, err = p.Parse(sentenceType5B, "st3", ts)
	if err != nil {
		t.Fatalf("Parse() second fragment error = %v", err)
	}
	if res == nil || res.Vessel == nil {
		t.Fatal("expected a vessel result after reassembly")
	}
	v := res.Vessel
	if v.MMSI != 229474000 {
		t.Errorf("MMSI = %d, want 229474000", v.MMSI)
	}
	if v.Name != "SEASMILE" {
		t.Errorf("Name = %q, want SEASMILE", v.Name)
	}
	if v.Callsign != "9HA3361" {
		t.Errorf("Callsign = %q, want 9HA3361", v.Callsign)
	}
	if v.IMO == nil || *v.IMO != 9632820 {
		t.Errorf("IMO = %v, want 9632820", v.IMO)
	}
	if v.ShipType != 74 {
		t.Errorf("ShipType = %d, want 74", v.ShipType)
	}
}

func TestParse_staticDataReportType24PartA(t *testing.T) {
	p := NewParser()
	res, err := p.Parse(sentenceType24A, "st4", time.Now())
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res == nil || res.Vessel == nil {
		t.Fatal("expected a vessel result")
	}
	if res.Vessel.MMSI != 413950301 {
		t.Errorf("MMSI = %d, want 413950301", res.Vessel.MMSI)
	}
	if res.Vessel.Name != "NANTONG3628" {
		t.Errorf("Name = %q, want NANTONG3628", res.Vessel.Name)
	}
}

func TestParse_invalidPositionReturnsNil(t *testing.T) {
	p := NewParser()
	res, err := p.Parse(sentenceNoPosition, "st5", time.Now())
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res != nil {
		t.Fatalf("expected nil result for invalid position, got %+v", res)
	}
}

func TestParse_nonVDMSentenceReturnsError(t *testing.T) {
	p := NewParser()
	if _, err := p.Parse(sentenceNonVDM, "st6", time.Now()); err == nil {
		t.Fatal("expected error for non-VDM sentence")
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/nmea/...
```
Expected: FAIL（`model.go`/`parser.go` 不存在）。

- [ ] **Step 3: 实现 model 与 parser**

创建 `ais/internal/model/model.go`：
```go
// Package model defines the shared domain types used across all packages.
package model

import (
	"time"

	"github.com/paulmach/orb/geojson"
)

type Position struct {
	MMSI      uint32    `json:"mmsi"`
	Ts        time.Time `json:"ts"`
	Lat       float64   `json:"lat"`
	Lon       float64   `json:"lon"`
	SOG       float32   `json:"sog"`
	COG       float32   `json:"cog"`
	Heading   int16     `json:"heading"`
	NavStatus int16     `json:"nav_status"`
	MsgType   int16     `json:"msg_type"`
	Source    string    `json:"source"`
}

type Vessel struct {
	MMSI      uint32    `json:"mmsi"`
	Name      string    `json:"name"`
	IMO       *uint32   `json:"imo"`
	Callsign  string    `json:"callsign"`
	ShipType  int16     `json:"ship_type"`
	LengthM   float32   `json:"length_m"`
	BeamM     float32   `json:"beam_m"`
	UpdatedAt time.Time `json:"updated_at"`
}

type TrackPoint struct {
	Ts  time.Time `json:"ts"`
	Lat float64   `json:"lat"`
	Lon float64   `json:"lon"`
	SOG float32   `json:"sog"`
}

type Geofence struct {
	ID                int64            `json:"id"`
	Name              string           `json:"name"`
	Area              geojson.Geometry `json:"area"`
	Enabled           bool             `json:"enabled"`
	EnterAlert        bool             `json:"enter_alert"`
	LeaveAlert        bool             `json:"leave_alert"`
	DebounceCount     int              `json:"debounce_count"`
	SilenceTimeoutMin int              `json:"silence_timeout_min"`
	CreatedAt         time.Time        `json:"created_at"`
}

const (
	EventTypeEnter int16 = 1
	EventTypeLeave int16 = 2
)

type FenceEvent struct {
	ID        int64     `json:"id"`
	FenceID   int64     `json:"fence_id"`
	MMSI      uint32    `json:"mmsi"`
	EventType int16     `json:"event_type"`
	Ts        time.Time `json:"ts"`
	Lat       float64   `json:"lat"`
	Lon       float64   `json:"lon"`
}

type User struct {
	ID           int64     `json:"id"`
	Username     string    `json:"username"`
	PasswordHash string    `json:"-"`
	Role         string    `json:"role"`
	CreatedAt    time.Time `json:"created_at"`
}

type BaseStation struct {
	ID      int64  `json:"id"`
	Name    string `json:"name"`
	Host    string `json:"host"`
	Port    int    `json:"port"`
	Enabled bool   `json:"enabled"`
}
```

创建 `ais/internal/nmea/parser.go`：
```go
// Package nmea wraps go-ais to decode NMEA 0183 VDM/VDO sentences into
// domain positions and vessels.
package nmea

import (
	"strings"
	"time"

	ais "github.com/BertoldVdb/go-ais"
	"github.com/BertoldVdb/go-ais/aisnmea"

	"ais/internal/model"
)

type Result struct {
	Position *model.Position
	Vessel   *model.Vessel
}

// Parser wraps the go-ais NMEA codec. Multi-sentence reassembly is
// stateful, so one Parser instance must be used per station connection.
type Parser struct {
	codec *aisnmea.NMEACodec
}

func NewParser() *Parser {
	c := ais.CodecNew(false, false)
	c.DropSpace = true
	return &Parser{codec: aisnmea.NMEACodecNew(c)}
}

// Parse feeds one raw NMEA sentence. It returns (nil, nil) when the
// sentence is only a fragment of a multi-sentence message (reassembly
// continues internally), and an error when the sentence cannot be parsed.
func (p *Parser) Parse(raw string, station string, ts time.Time) (*Result, error) {
	pkt, err := p.codec.ParseSentence(raw)
	if err != nil {
		return nil, err
	}
	if pkt == nil || pkt.Packet == nil {
		return nil, nil
	}
	return mapPacket(pkt.Packet, station, ts), nil
}

func mapPacket(pkt ais.Packet, station string, ts time.Time) *Result {
	hdr := pkt.GetHeader()
	mmsi := hdr.UserID
	switch m := pkt.(type) {
	case ais.PositionReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), m.TrueHeading, uint16(m.NavigationalStatus), station, ts)
	case ais.BaseStationReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude), 0, 0, 0, 0, station, ts)
	case ais.StandardSearchAndRescueAircraftReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), 0, 0, station, ts)
	case ais.StandardClassBPositionReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), m.TrueHeading, 0, station, ts)
	case ais.ExtendedClassBPositionReport:
		r := pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), m.TrueHeading, 0, station, ts)
		if r == nil {
			return nil
		}
		r.Vessel = &model.Vessel{
			MMSI:      mmsi,
			Name:      strings.TrimSpace(m.Name),
			ShipType:  int16(m.Type),
			LengthM:   float32(m.Dimension.A + m.Dimension.B),
			BeamM:     float32(m.Dimension.C + m.Dimension.D),
			UpdatedAt: ts,
		}
		return r
	case ais.AidsToNavigationReport:
		r := pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude), 0, 0, 0, 0, station, ts)
		if r == nil {
			return nil
		}
		r.Vessel = &model.Vessel{
			MMSI:      mmsi,
			Name:      strings.TrimSpace(m.Name),
			ShipType:  30, // AtoN
			UpdatedAt: ts,
		}
		return r
	case ais.LongRangeAisBroadcastMessage:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), 0, uint16(m.NavigationalStatus), station, ts)
	case ais.ShipStaticData:
		v := &model.Vessel{
			MMSI:      mmsi,
			Name:      strings.TrimSpace(m.Name),
			Callsign:  strings.TrimSpace(m.CallSign),
			ShipType:  int16(m.Type),
			LengthM:   float32(m.Dimension.A + m.Dimension.B),
			BeamM:     float32(m.Dimension.C + m.Dimension.D),
			UpdatedAt: ts,
		}
		if m.ImoNumber > 0 {
			imo := m.ImoNumber
			v.IMO = &imo
		}
		return &Result{Vessel: v}
	case ais.StaticDataReport:
		v := &model.Vessel{MMSI: mmsi, UpdatedAt: ts}
		if !m.PartNumber {
			v.Name = strings.TrimSpace(m.ReportA.Name)
		} else {
			v.Callsign = strings.TrimSpace(m.ReportB.CallSign)
			v.ShipType = int16(m.ReportB.ShipType)
			v.LengthM = float32(m.ReportB.Dimension.A + m.ReportB.Dimension.B)
			v.BeamM = float32(m.ReportB.Dimension.C + m.ReportB.Dimension.D)
		}
		return &Result{Vessel: v}
	}
	return nil
}

// pos builds a Position result, rejecting out-of-range coordinates
// (including the AIS "not available" sentinels lat=91 / lon=181).
func pos(mmsi uint32, msgType uint8, lat, lon float64, sog, cog float32, heading, nav uint16, station string, ts time.Time) *Result {
	if lat < -90 || lat > 90 || lon < -180 || lon > 180 {
		return nil
	}
	return &Result{Position: &model.Position{
		MMSI: mmsi, Ts: ts, Lat: lat, Lon: lon,
		SOG: sog, COG: cog,
		Heading:   int16(heading),
		NavStatus: int16(nav),
		MsgType:   int16(msgType),
		Source:    station,
	}}
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/nmea/...
```
Expected: PASS（6 个测试）。若 `TestParse_positionReportType1` 的经纬度断言失败，把期望值改为实际输出的 6 位小数（该语句为公开测试向量，若库版本一致不应变化）。

- [ ] **Step 5: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 3: 内存去重器（30 秒窗口）

**Files:**
- Create: `ais/internal/dedup/dedup.go`
- Create: `ais/internal/dedup/dedup_test.go`

**Interfaces:**
- Consumes: 无。
- Produces: `dedup.New(window time.Duration, maxEntries int) *Dedup`；`(*Dedup).CheckAndAdd(key string, now time.Time) bool`（返回 true 表示 key 在窗口内已出现过，即重复）。key 由管道层构造（MMSI+秒级时间戳+原始语句 FNV 哈希），本包不关心 key 格式。

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/dedup/dedup_test.go`：
```go
package dedup

import (
	"testing"
	"time"
)

func TestCheckAndAdd_duplicateWithinWindow(t *testing.T) {
	d := New(30*time.Second, 1000)
	now := time.Now()
	if d.CheckAndAdd("a", now) {
		t.Fatal("first occurrence should not be a duplicate")
	}
	if !d.CheckAndAdd("a", now.Add(5*time.Second)) {
		t.Fatal("second occurrence within window should be a duplicate")
	}
}

func TestCheckAndAdd_expiredAfterWindow(t *testing.T) {
	d := New(30*time.Second, 1000)
	now := time.Now()
	d.CheckAndAdd("a", now)
	if d.CheckAndAdd("a", now.Add(31*time.Second)) {
		t.Fatal("occurrence after window should not be a duplicate")
	}
}

func TestCheckAndAdd_distinctKeysNotDeduped(t *testing.T) {
	d := New(30*time.Second, 1000)
	now := time.Now()
	if d.CheckAndAdd("a", now) || d.CheckAndAdd("b", now) {
		t.Fatal("distinct keys must not be treated as duplicates")
	}
}

func TestCheckAndAdd_evictsOldestWhenFull(t *testing.T) {
	d := New(30*time.Second, 2)
	now := time.Now()
	d.CheckAndAdd("k1", now)
	d.CheckAndAdd("k2", now)
	// 触发淘汰
	if d.CheckAndAdd("k3", now) {
		t.Fatal("adding a new key should succeed")
	}
	// 被淘汰的 k1 再次出现不算重复
	if d.CheckAndAdd("k1", now.Add(1*time.Second)) {
		t.Fatal("evicted key should be re-insertable")
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/dedup/...
```
Expected: FAIL（`dedup.go` 不存在）。

- [ ] **Step 3: 实现 dedup**

创建 `ais/internal/dedup/dedup.go`：
```go
// Package dedup provides a time-windowed in-memory duplicate detector.
package dedup

import (
	"sync"
	"time"
)

type Dedup struct {
	mu         sync.Mutex
	window     time.Duration
	maxEntries int
	seen       map[string]time.Time
}

func New(window time.Duration, maxEntries int) *Dedup {
	return &Dedup{window: window, maxEntries: maxEntries, seen: make(map[string]time.Time)}
}

// CheckAndAdd reports whether key was already seen within the window and
// records it. Returns true when the message is a duplicate.
func (d *Dedup) CheckAndAdd(key string, now time.Time) bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	cutoff := now.Add(-d.window)
	if first, ok := d.seen[key]; ok && first.After(cutoff) {
		return true
	}
	d.seen[key] = now
	if len(d.seen) > d.maxEntries {
		for k, first := range d.seen {
			if first.Before(cutoff) {
				delete(d.seen, k)
			}
		}
		if len(d.seen) > d.maxEntries {
			var oldestKey string
			var oldest time.Time
			for k, first := range d.seen {
				if oldestKey == "" || first.Before(oldest) {
					oldestKey, oldest = k, first
				}
			}
			delete(d.seen, oldestKey)
		}
	}
	return false
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go test ./internal/dedup/...
```
Expected: PASS（4 个测试）。

- [ ] **Step 5: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。

---

### Task 4: 基站 TCP 连接管理（多连接、心跳、指数退避重连）

**Files:**
- Create: `ais/internal/station/station.go`
- Create: `ais/internal/station/station_test.go`

**Interfaces:**
- Consumes: `config.Station{ID, Name, Host, Port, Enabled}`（Task 1 产物）。
- Produces:
  - `station.Config`（与 `config.Station` 同字段）、`station.Options{ConnectTimeout, ReconnectBase, ReconnectMax, IdleTimeout time.Duration; ReadBufSize int}`
  - `station.Handler` 接口：`OnLine(stationID string, line string)`、`OnStatus(stationID string, connected bool, err error)`
  - `station.New(cfg Config, handler Handler, opts Options, log *slog.Logger) *Station`
  - `(*Station).Run(ctx context.Context)`（阻塞，直至 ctx 取消）
  - `(*Station).Status() Status`；`Status{ID, Name string; Connected bool; LastError string; Lines uint64; Since time.Time}`
  - `station.NewManager(cfgs []Config, handler Handler, opts Options, log *slog.Logger) *Manager`；`(*Manager).Run(ctx)`；`(*Manager).Statuses() []Status`
- 行为约定：按行读取（`bufio.Scanner`）；`IdleTimeout` 内无数据则关闭连接触发重连（AIS 语句天然是保活信号）；重连退避从 `ReconnectBase` 起指数翻倍至 `ReconnectMax`；连接/断开都会回调 `OnStatus`。

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/station/station_test.go`：
```go
package station

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"net"
	"strconv"
	"sync"
	"testing"
	"time"
)

type recorder struct {
	mu     sync.Mutex
	lines  []string
	status []bool
}

func (r *recorder) OnLine(_ string, line string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.lines = append(r.lines, line)
}

func (r *recorder) OnStatus(_ string, connected bool, _ error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.status = append(r.status, connected)
}

func (r *recorder) hasLine(want string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, l := range r.lines {
		if l == want {
			return true
		}
	}
	return false
}

func (r *recorder) lastStatus() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if len(r.status) == 0 {
		return false
	}
	return r.status[len(r.status)-1]
}

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func waitUntil(t *testing.T, timeout time.Duration, cond func() bool, msg string) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal(msg)
}

func TestStation_receivesLinesAndReconnects(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	host, portStr, _ := net.SplitHostPort(ln.Addr().String())
	port, _ := strconv.Atoi(portStr)

	serverErr := make(chan error, 1)
	go func() {
		// 第一次连接：写两行后关闭
		conn, err := ln.Accept()
		if err != nil {
			serverErr <- err
			return
		}
		fmt.Fprintf(conn, "line1\r\nline2\r\n")
		conn.Close()
		// 第二次连接（重连）：持续写 lineA
		conn2, err := ln.Accept()
		if err != nil {
			serverErr <- err
			return
		}
		defer conn2.Close()
		for i := 0; i < 200; i++ {
			fmt.Fprintf(conn2, "lineA\r\n")
			time.Sleep(10 * time.Millisecond)
		}
		serverErr <- nil
	}()

	rec := &recorder{}
	s := New(Config{ID: "st1", Name: "t", Host: host, Port: port, Enabled: true}, rec,
		Options{ConnectTimeout: time.Second, ReconnectBase: 30 * time.Millisecond, ReconnectMax: 100 * time.Millisecond, IdleTimeout: 5 * time.Second},
		discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan struct{})
	go func() {
		defer close(done)
		s.Run(ctx)
	}()

	waitUntil(t, 10*time.Second, func() bool { return rec.hasLine("lineA") }, "timeout: never reconnected")
	waitUntil(t, 5*time.Second, func() bool { return rec.hasLine("line1") }, "timeout: line1 not received")
	waitUntil(t, 5*time.Second, func() bool { return !rec.lastStatus() }, "timeout: expected disconnected status after first close")

	cancel()
	<-done
	select {
	case err := <-serverErr:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("server goroutine did not finish")
	}
}

func TestStation_idleTimeoutClosesConnection(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	host, portStr, _ := net.SplitHostPort(ln.Addr().String())
	port, _ := strconv.Atoi(portStr)

	accepted := make(chan struct{}, 4)
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			accepted <- struct{}{}
			go func(c net.Conn) {
				// 不写任何数据，等待对端超时关闭
				io.Copy(io.Discard, c)
				c.Close()
			}(conn)
		}
	}()

	rec := &recorder{}
	s := New(Config{ID: "st2", Name: "t", Host: host, Port: port, Enabled: true}, rec,
		Options{ConnectTimeout: time.Second, ReconnectBase: 30 * time.Millisecond, ReconnectMax: 100 * time.Millisecond, IdleTimeout: 200 * time.Millisecond},
		discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan struct{})
	go func() {
		defer close(done)
		s.Run(ctx)
	}()

	// 200ms 空闲超时 → 应断开重连，至少出现两次连接
	waitUntil(t, 10*time.Second, func() bool { return len(accepted) >= 2 }, "timeout: expected reconnect after idle timeout")
	cancel()
	<-done
}

func TestManager_statuses(t *testing.T) {
	rec := &recorder{}
	m := NewManager([]Config{
		{ID: "a", Name: "A", Host: "127.0.0.1", Port: 1, Enabled: true},
		{ID: "b", Name: "B", Host: "127.0.0.1", Port: 2, Enabled: false},
	}, rec, Options{}, discardLogger())
	st := m.Statuses()
	if len(st) != 2 {
		t.Fatalf("Statuses() len = %d, want 2", len(st))
	}
	if st[0].ID != "a" || st[0].Connected {
		t.Errorf("station a status = %+v, want not connected", st[0])
	}
	if st[1].ID != "b" || st[1].Connected {
		t.Errorf("station b status = %+v, want not connected", st[1])
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/station/...
```
Expected: FAIL（`station.go` 不存在）。

- [ ] **Step 3: 实现 station**

创建 `ais/internal/station/station.go`：
```go
// Package station manages TCP connections to AIS base stations with
// line reading, idle heartbeat detection and exponential backoff reconnect.
package station

import (
	"bufio"
	"context"
	"fmt"
	"log/slog"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

type Config struct {
	ID      string
	Name    string
	Host    string
	Port    int
	Enabled bool
}

func (c Config) Addr() string {
	return net.JoinHostPort(c.Host, fmt.Sprintf("%d", c.Port))
}

type Options struct {
	ConnectTimeout time.Duration
	ReconnectBase  time.Duration
	ReconnectMax   time.Duration
	IdleTimeout    time.Duration
	ReadBufSize    int
}

type Handler interface {
	OnLine(stationID string, line string)
	OnStatus(stationID string, connected bool, err error)
}

type Status struct {
	ID        string
	Name      string
	Connected bool
	LastError string
	Lines     uint64
	Since     time.Time
}

type Station struct {
	cfg     Config
	handler Handler
	opts    Options
	log     *slog.Logger

	connected atomic.Bool
	lastError atomic.Value
	lines     atomic.Uint64
	since     atomic.Value
}

func New(cfg Config, handler Handler, opts Options, log *slog.Logger) *Station {
	return &Station{cfg: cfg, handler: handler, opts: opts, log: log}
}

func (s *Station) Run(ctx context.Context) {
	if !s.cfg.Enabled {
		s.log.Info("station disabled, skipping", "station", s.cfg.ID)
		return
	}
	backoff := s.opts.ReconnectBase
	for {
		if ctx.Err() != nil {
			return
		}
		err := s.runOnce(ctx)
		s.setConnected(false, err)
		s.handler.OnStatus(s.cfg.ID, false, err)
		if ctx.Err() != nil {
			return
		}
		s.log.Warn("station disconnected", "station", s.cfg.ID, "err", err)
		select {
		case <-ctx.Done():
			return
		case <-time.After(backoff):
		}
		backoff *= 2
		if backoff > s.opts.ReconnectMax {
			backoff = s.opts.ReconnectMax
		}
	}
}

func (s *Station) runOnce(ctx context.Context) error {
	d := net.Dialer{Timeout: s.opts.ConnectTimeout}
	conn, err := d.DialContext(ctx, "tcp", s.cfg.Addr())
	if err != nil {
		return err
	}
	stop := make(chan struct{})
	defer close(stop)
	go func() {
		select {
		case <-ctx.Done():
			_ = conn.Close()
		case <-stop:
		}
	}()
	defer conn.Close()

	s.setConnected(true, nil)
	s.handler.OnStatus(s.cfg.ID, true, nil)
	s.log.Info("station connected", "station", s.cfg.ID, "addr", s.cfg.Addr())

	scanner := bufio.NewScanner(conn)
	if s.opts.ReadBufSize > 0 {
		scanner.Buffer(make([]byte, s.opts.ReadBufSize), s.opts.ReadBufSize)
	}
	for {
		if s.opts.IdleTimeout > 0 {
			_ = conn.SetReadDeadline(time.Now().Add(s.opts.IdleTimeout))
		}
		if !scanner.Scan() {
			if err := scanner.Err(); err != nil {
				return err
			}
			return fmt.Errorf("connection closed by peer")
		}
		s.lines.Add(1)
		s.handler.OnLine(s.cfg.ID, scanner.Text())
		if ctx.Err() != nil {
			return ctx.Err()
		}
	}
}

func (s *Station) setConnected(v bool, err error) {
	s.connected.Store(v)
	if err != nil {
		s.lastError.Store(err.Error())
	} else {
		s.lastError.Store("")
	}
	if v {
		s.since.Store(time.Now())
	} else {
		s.since.Store(time.Time{})
	}
}

func (s *Station) Status() Status {
	st := Status{ID: s.cfg.ID, Name: s.cfg.Name, Connected: s.connected.Load(), Lines: s.lines.Load()}
	if e, ok := s.lastError.Load().(string); ok {
		st.LastError = e
	}
	if t, ok := s.since.Load().(time.Time); ok {
		st.Since = t
	}
	return st
}

type Manager struct {
	stations []*Station
}

func NewManager(cfgs []Config, handler Handler, opts Options, log *slog.Logger) *Manager {
	m := &Manager{}
	for _, c := range cfgs {
		m.stations = append(m.stations, New(c, handler, opts, log))
	}
	return m
}

func (m *Manager) Run(ctx context.Context) {
	var wg sync.WaitGroup
	for _, s := range m.stations {
		wg.Add(1)
		go func(s *Station) {
			defer wg.Done()
			s.Run(ctx)
		}(s)
	}
	wg.Wait()
}

func (m *Manager) Statuses() []Status {
	out := make([]Status, 0, len(m.stations))
	for _, s := range m.stations {
		out = append(out, s.Status())
	}
	return out
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go test ./internal/station/...
```
Expected: PASS（3 个测试）。

- [ ] **Step 5: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 5: PostgreSQL 模式、迁移执行器与分区维护

**Files:**
- Create: `ais/internal/store/store.go`
- Create: `ais/internal/store/pg/pg.go`
- Create: `ais/internal/store/pg/migrate.go`
- Create: `ais/internal/store/pg/migrations/0001_init.sql`
- Create: `ais/internal/store/pg/partman.go`
- Create: `ais/internal/store/pg/partman_test.go`
- Create: `ais/internal/store/pg/pg_test.go`（集成测试，需本地 Docker）

**Interfaces:**
- Consumes: `model.*`（Task 2 产物）。
- Produces:
  - `store.ErrNotFound = errors.New("not found")`
  - 接口：`store.PositionStore{InsertBatch(ctx, []model.Position) error; Track(ctx, mmsi uint32, start, end time.Time, bucketSec, limit int) ([]model.TrackPoint, error); LatestFallback(ctx) ([]model.Position, error); FenceHistoryVessels(ctx, fenceID int64, start, end time.Time) ([]uint32, error)}`
  - 接口：`store.GeofenceStore{List; ListEnabled; Get(ctx, id); Create(ctx, model.Geofence); Update; Delete; Events(ctx, fenceID, start, end, limit); InsertEvent(ctx, model.FenceEvent); DeleteEventsBefore(ctx, before time.Time) (int64, error)}`
  - 接口：`store.VesselStore{Upsert(ctx, model.Vessel) error; List(ctx, page, pageSize int, search string) ([]model.Vessel, int64, error)}`
  - 接口：`store.UserStore{Create(ctx, username, passwordHash, role string) (model.User, error); GetByUsername(ctx, username string) (model.User, error)}`
  - `pg.Connect(ctx, url string) (*pgxpool.Pool, error)`；`pg.Migrate(ctx, pool) error`
  - `pg.PartitionName(t time.Time) string`；`pg.PartitionRange(t) (from, to time.Time)`；`pg.EnsurePartition(ctx, pool, t) error`；`pg.EnsurePartitions(ctx, pool, from, to) error`；`pg.ListPartitions(ctx, pool) ([]string, error)`；`pg.OldPartitions(names []string, before time.Time) []string`；`pg.DropPartitionsBefore(ctx, pool, before) ([]string, error)`
- 环境约定：集成测试需要 `TEST_DATABASE_URL`（未设置则跳过）。本地起库命令见 Step 1。

- [ ] **Step 1: 用 Docker 启动本地 PostgreSQL(+PostGIS) 与 Redis**

```powershell
docker run -d --name ais-postgres -p 5432:5432 `
  -e POSTGRES_USER=ais -e POSTGRES_PASSWORD=ais -e POSTGRES_DB=ais `
  postgis/postgis:16-3.4
docker run -d --name ais-redis -p 6379:6379 redis:7-alpine
```
验证：`docker ps` 中两个容器状态为 healthy/running。

- [ ] **Step 2: 写失败测试（纯函数 + 集成）**

创建 `ais/internal/store/pg/partman_test.go`：
```go
package pg

import (
	"testing"
	"time"
)

func TestPartitionName(t *testing.T) {
	got := PartitionName(time.Date(2026, 8, 7, 15, 30, 0, 0, time.UTC))
	if got != "ais_positions_20260807" {
		t.Errorf("PartitionName = %q, want ais_positions_20260807", got)
	}
}

func TestPartitionRange(t *testing.T) {
	from, to := PartitionRange(time.Date(2026, 8, 7, 15, 30, 0, 0, time.UTC))
	if from != time.Date(2026, 8, 7, 0, 0, 0, 0, time.UTC) {
		t.Errorf("from = %v, want 2026-08-07 00:00:00 UTC", from)
	}
	if to != time.Date(2026, 8, 8, 0, 0, 0, 0, time.UTC) {
		t.Errorf("to = %v, want 2026-08-08 00:00:00 UTC", to)
	}
}

func TestOldPartitions(t *testing.T) {
	before := time.Date(2026, 8, 7, 0, 0, 0, 0, time.UTC)
	names := []string{
		"ais_positions_20260801",
		"ais_positions_20260806",
		"ais_positions_20260807",
		"ais_positions_20260808",
		"not_a_partition",
	}
	old := OldPartitions(names, before)
	if len(old) != 2 {
		t.Fatalf("OldPartitions len = %d, want 2 (%v)", len(old), old)
	}
	if old[0] != "ais_positions_20260801" || old[1] != "ais_positions_20260806" {
		t.Errorf("OldPartitions = %v, want [ais_positions_20260801 ais_positions_20260806]", old)
	}
}
```

创建 `ais/internal/store/pg/pg_test.go`（集成测试）：
```go
package pg

import (
	"context"
	"os"
	"testing"
	"time"
)

func TestMigrateAndPartitions(t *testing.T) {
	url := os.Getenv("TEST_DATABASE_URL")
	if url == "" {
		t.Skip("set TEST_DATABASE_URL (e.g. postgres://ais:ais@localhost:5432/ais?sslmode=disable) to run")
	}
	ctx := context.Background()
	pool, err := Connect(ctx, url)
	if err != nil {
		t.Fatalf("Connect() error = %v", err)
	}
	defer pool.Close()

	if err := Migrate(ctx, pool); err != nil {
		t.Fatalf("Migrate() error = %v", err)
	}
	// 幂等：重复执行不报错
	if err := Migrate(ctx, pool); err != nil {
		t.Fatalf("Migrate() second run error = %v", err)
	}

	now := time.Now().UTC()
	if err := EnsurePartitions(ctx, pool, now.Add(-time.Hour), now.Add(48*time.Hour)); err != nil {
		t.Fatalf("EnsurePartitions() error = %v", err)
	}

	if _, err := pool.Exec(ctx, `
		INSERT INTO ais_positions (mmsi, ts, lat, lon, sog, cog, heading, nav_status, msg_type, source)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
		123456789, now, 22.5, 113.9, 10.0, 90.0, 90, 0, 1, "test"); err != nil {
		t.Fatalf("insert into partition error = %v", err)
	}

	var n int64
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM ais_positions WHERE mmsi=$1`, 123456789).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 1 {
		t.Errorf("count = %d, want 1", n)
	}

	// 空间查询可用
	var intersects bool
	if err := pool.QueryRow(ctx, `
		SELECT ST_Intersects(geom, ST_SetSRID(ST_MakePoint(113.9, 22.5), 4326))
		FROM ais_positions WHERE mmsi=$1`, 123456789).Scan(&intersects); err != nil {
		t.Fatal(err)
	}
	if !intersects {
		t.Error("ST_Intersects = false, want true")
	}

	// 围栏/事件/元数据表可用
	var fenceCount int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM geofences`).Scan(&fenceCount); err != nil {
		t.Fatal(err)
	}
	var userCount int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM users`).Scan(&userCount); err != nil {
		t.Fatal(err)
	}
}
```

- [ ] **Step 3: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/store/pg/...
```
Expected: 纯函数测试 FAIL（文件不存在）；集成测试因无环境变量直接 SKIP。

- [ ] **Step 4: 实现 store 接口、连接池、迁移与分区**

创建 `ais/internal/store/store.go`：
```go
// Package store defines repository interfaces implemented by the pg package.
package store

import (
	"context"
	"errors"
	"time"

	"ais/internal/model"
)

var ErrNotFound = errors.New("not found")

type PositionStore interface {
	InsertBatch(ctx context.Context, rows []model.Position) error
	Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error)
	LatestFallback(ctx context.Context) ([]model.Position, error)
	FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error)
}

type GeofenceStore interface {
	List(ctx context.Context) ([]model.Geofence, error)
	ListEnabled(ctx context.Context) ([]model.Geofence, error)
	Get(ctx context.Context, id int64) (model.Geofence, error)
	Create(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Update(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Delete(ctx context.Context, id int64) error
	Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error)
	InsertEvent(ctx context.Context, e model.FenceEvent) error
	DeleteEventsBefore(ctx context.Context, before time.Time) (int64, error)
}

type VesselStore interface {
	Upsert(ctx context.Context, v model.Vessel) error
	List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error)
}

type UserStore interface {
	Create(ctx context.Context, username, passwordHash, role string) (model.User, error)
	GetByUsername(ctx context.Context, username string) (model.User, error)
}
```

创建 `ais/internal/store/pg/pg.go`：
```go
// Package pg implements the store interfaces on PostgreSQL.
package pg

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

func Connect(ctx context.Context, url string) (*pgxpool.Pool, error) {
	cfg, err := pgxpool.ParseConfig(url)
	if err != nil {
		return nil, fmt.Errorf("parse db url: %w", err)
	}
	cfg.MaxConns = 20
	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, err
	}
	pingCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	if err := pool.Ping(pingCtx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("ping db: %w", err)
	}
	return pool, nil
}
```

创建 `ais/internal/store/pg/migrate.go`：
```go
package pg

import (
	"context"
	"embed"
	"fmt"
	"io/fs"
	"sort"

	"github.com/jackc/pgx/v5/pgxpool"
)

//go:embed migrations/*.sql
var migrationsFS embed.FS

func Migrate(ctx context.Context, pool *pgxpool.Pool) error {
	if _, err := pool.Exec(ctx, `CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`); err != nil {
		return err
	}
	entries, err := fs.Glob(migrationsFS, "migrations/*.sql")
	if err != nil {
		return err
	}
	sort.Strings(entries)
	for _, name := range entries {
		var exists bool
		if err := pool.QueryRow(ctx, `SELECT EXISTS(SELECT 1 FROM schema_migrations WHERE version=$1)`, name).Scan(&exists); err != nil {
			return err
		}
		if exists {
			continue
		}
		sqlBytes, err := migrationsFS.ReadFile(name)
		if err != nil {
			return err
		}
		tx, err := pool.Begin(ctx)
		if err != nil {
			return err
		}
		if _, err := tx.Exec(ctx, string(sqlBytes)); err != nil {
			_ = tx.Rollback(ctx)
			return fmt.Errorf("apply %s: %w", name, err)
		}
		if _, err := tx.Exec(ctx, `INSERT INTO schema_migrations (version) VALUES ($1)`, name); err != nil {
			_ = tx.Rollback(ctx)
			return err
		}
		if err := tx.Commit(ctx); err != nil {
			return err
		}
	}
	return nil
}
```

创建 `ais/internal/store/pg/migrations/0001_init.sql`：
```sql
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE ais_positions (
  mmsi BIGINT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  lat DOUBLE PRECISION NOT NULL,
  lon DOUBLE PRECISION NOT NULL,
  sog REAL NOT NULL DEFAULT 0,
  cog REAL NOT NULL DEFAULT 0,
  heading SMALLINT NOT NULL DEFAULT 511,
  nav_status SMALLINT NOT NULL DEFAULT 0,
  msg_type SMALLINT NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT '',
  geom geometry(Point, 4326) GENERATED ALWAYS AS
    (ST_SetSRID(ST_MakePoint(lon, lat), 4326)) STORED
) PARTITION BY RANGE (ts);

CREATE INDEX idx_ais_positions_mmsi_ts ON ais_positions (mmsi, ts);
CREATE INDEX idx_ais_positions_geom ON ais_positions USING GIST (geom);

CREATE TABLE geofences (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  area geometry(Polygon, 4326) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true,
  enter_alert BOOLEAN NOT NULL DEFAULT true,
  leave_alert BOOLEAN NOT NULL DEFAULT true,
  debounce_count SMALLINT NOT NULL DEFAULT 2,
  silence_timeout_min INT NOT NULL DEFAULT 5,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_geofences_area ON geofences USING GIST (area);
CREATE INDEX idx_geofences_enabled ON geofences (enabled) WHERE enabled;

CREATE TABLE fence_events (
  id BIGSERIAL PRIMARY KEY,
  fence_id BIGINT NOT NULL REFERENCES geofences(id) ON DELETE CASCADE,
  mmsi BIGINT NOT NULL,
  event_type SMALLINT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION
);
CREATE INDEX idx_fence_events_fence_ts ON fence_events (fence_id, ts);
CREATE INDEX idx_fence_events_mmsi_ts ON fence_events (mmsi, ts);

CREATE TABLE vessels (
  mmsi BIGINT PRIMARY KEY,
  name TEXT NOT NULL DEFAULT '',
  imo BIGINT,
  callsign TEXT NOT NULL DEFAULT '',
  ship_type SMALLINT NOT NULL DEFAULT 0,
  length_m REAL NOT NULL DEFAULT 0,
  beam_m REAL NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE base_stations (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  host TEXT NOT NULL,
  port INT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true
);
```

创建 `ais/internal/store/pg/partman.go`：
```go
package pg

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

func PartitionName(t time.Time) string {
	return "ais_positions_" + t.UTC().Format("20060102")
}

func PartitionRange(t time.Time) (from, to time.Time) {
	day := t.UTC().Truncate(24 * time.Hour)
	return day, day.Add(24 * time.Hour)
}

func EnsurePartition(ctx context.Context, pool *pgxpool.Pool, t time.Time) error {
	name := PartitionName(t)
	from, to := PartitionRange(t)
	_, err := pool.Exec(ctx, fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s PARTITION OF ais_positions FOR VALUES FROM ($1) TO ($2)", name,
	), from, to)
	return err
}

func EnsurePartitions(ctx context.Context, pool *pgxpool.Pool, from, to time.Time) error {
	for d := from.UTC().Truncate(24 * time.Hour); d.Before(to); d = d.Add(24 * time.Hour) {
		if err := EnsurePartition(ctx, pool, d); err != nil {
			return fmt.Errorf("ensure partition %s: %w", PartitionName(d), err)
		}
	}
	return nil
}

func ListPartitions(ctx context.Context, pool *pgxpool.Pool) ([]string, error) {
	rows, err := pool.Query(ctx, `
		SELECT child.relname
		FROM pg_inherits
		JOIN pg_class parent ON pg_inherits.inhparent = parent.oid
		JOIN pg_class child  ON pg_inherits.inhrelid = child.oid
		WHERE parent.relname = 'ais_positions' AND child.relkind = 'r'
		ORDER BY child.relname`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return nil, err
		}
		out = append(out, name)
	}
	return out, rows.Err()
}

func OldPartitions(names []string, before time.Time) []string {
	cutoff := before.UTC().Truncate(24 * time.Hour)
	var out []string
	for _, n := range names {
		suffix := strings.TrimPrefix(n, "ais_positions_")
		d, err := time.Parse("20060102", suffix)
		if err != nil {
			continue
		}
		if d.Before(cutoff) {
			out = append(out, n)
		}
	}
	return out
}

func DropPartitionsBefore(ctx context.Context, pool *pgxpool.Pool, before time.Time) ([]string, error) {
	names, err := ListPartitions(ctx, pool)
	if err != nil {
		return nil, err
	}
	old := OldPartitions(names, before)
	for _, n := range old {
		if _, err := pool.Exec(ctx, "DROP TABLE IF EXISTS "+n); err != nil {
			return old, fmt.Errorf("drop partition %s: %w", n, err)
		}
	}
	return old, nil
}
```

- [ ] **Step 5: 运行单元测试 + 集成测试**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/store/pg/...
```
Expected: 纯函数测试 PASS；集成测试 SKIP（未设置 TEST_DATABASE_URL）。

```powershell
$env:TEST_DATABASE_URL = "postgres://ais:ais@localhost:5432/ais?sslmode=disable"
go test ./internal/store/pg/...
```
Expected: 集成测试 PASS（本地 Docker PostGIS 已启动）。注意：该测试会向本地库写入数据，使用专用开发库即可。

- [ ] **Step 6: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 6: 批量写入器与轨迹查询存储实现

**Files:**
- Create: `ais/internal/store/pg/positions.go`
- Create: `ais/internal/store/pg/writer.go`
- Create: `ais/internal/store/pg/writer_test.go`

**Interfaces:**
- Consumes: `store.PositionStore`（Task 5）、`pg.PartitionName/EnsurePartition`（Task 5）。
- Produces:
  - `pg.NewPositions(pool *pgxpool.Pool) *Positions`（实现 `store.PositionStore`）
  - `pg.WriterOptions{FlushInterval time.Duration; BatchSize, QueueSize int}`
  - `pg.NewWriter(inserter Inserter, opts WriterOptions, log *slog.Logger) *Writer`
  - `pg.Inserter` 接口：`InsertBatch(ctx, []model.Position) error`
  - `(*Writer).Enqueue(p model.Position) error`（队列满返回 `pg.ErrQueueFull`）
  - `(*Writer).Run(ctx context.Context)`（1s 或 BatchSize 条触发 flush；ctx 取消时做最后一次尽力 flush）
  - `(*Writer).Stats() (flushed, dropped uint64)`
- 行为约定：`InsertBatch` 先为每条数据的日期确保分区存在（自愈，防例行任务未执行导致写入失败），再批量插入；缓冲上限 `QueueSize`，超出丢弃并告警日志。

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/store/pg/writer_test.go`：
```go
package pg

import (
	"context"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"ais/internal/model"
)

type fakeInserter struct {
	mu    sync.Mutex
	calls [][]model.Position
	fail  bool
}

func (f *fakeInserter) InsertBatch(_ context.Context, rows []model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.fail {
		return io.ErrClosedPipe
	}
	f.calls = append(f.calls, append([]model.Position(nil), rows...))
	return nil
}

func (f *fakeInserter) callCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.calls)
}

func (f *fakeInserter) rowsInCall(i int) int {
	f.mu.Lock()
	defer f.mu.Unlock()
	if i >= len(f.calls) {
		return 0
	}
	return len(f.calls[i])
}

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func pos(mmsi uint32, ts time.Time) model.Position {
	return model.Position{MMSI: mmsi, Ts: ts, Lat: 22.5, Lon: 113.9}
}

func waitFor(t *testing.T, timeout time.Duration, cond func() bool, msg string) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal(msg)
}

func TestWriter_flushOnBatchSize(t *testing.T) {
	ins := &fakeInserter{}
	w := NewWriter(ins, WriterOptions{FlushInterval: time.Hour, BatchSize: 3, QueueSize: 100}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	base := time.Now()
	for i := 0; i < 3; i++ {
		if err := w.Enqueue(pos(uint32(100+i), base)); err != nil {
			t.Fatalf("Enqueue() error = %v", err)
		}
	}
	waitFor(t, 3*time.Second, func() bool { return ins.callCount() == 1 }, "flush by batch size did not happen")
	if got := ins.rowsInCall(0); got != 3 {
		t.Errorf("first flush rows = %d, want 3", got)
	}
}

func TestWriter_flushOnInterval(t *testing.T) {
	ins := &fakeInserter{}
	w := NewWriter(ins, WriterOptions{FlushInterval: 20 * time.Millisecond, BatchSize: 1000, QueueSize: 100}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	if err := w.Enqueue(pos(1, time.Now())); err != nil {
		t.Fatalf("Enqueue() error = %v", err)
	}
	waitFor(t, 3*time.Second, func() bool { return ins.callCount() >= 1 }, "flush by interval did not happen")
}

func TestWriter_queueFullDrops(t *testing.T) {
	ins := &fakeInserter{}
	w := NewWriter(ins, WriterOptions{FlushInterval: time.Hour, BatchSize: 1000, QueueSize: 2}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	base := time.Now()
	if err := w.Enqueue(pos(1, base)); err != nil {
		t.Fatal(err)
	}
	if err := w.Enqueue(pos(2, base)); err != nil {
		t.Fatal(err)
	}
	if err := w.Enqueue(pos(3, base)); err == nil {
		t.Fatal("Enqueue() expected ErrQueueFull when queue is full")
	}
}

func TestWriter_retryOnceThenDropOnFailure(t *testing.T) {
	ins := &fakeInserter{fail: true}
	w := NewWriter(ins, WriterOptions{FlushInterval: 10 * time.Millisecond, BatchSize: 1000, QueueSize: 100}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	if err := w.Enqueue(pos(1, time.Now())); err != nil {
		t.Fatal(err)
	}
	waitFor(t, 3*time.Second, func() bool {
		_, dropped := w.Stats()
		return dropped > 0
	}, "expected dropped counter to increase after failed retry")
	flushed, dropped := w.Stats()
	if flushed != 0 {
		t.Errorf("flushed = %d, want 0 (inserter always fails)", flushed)
	}
	if dropped == 0 {
		t.Errorf("dropped = %d, want > 0", dropped)
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/store/pg/... -run TestWriter
```
Expected: FAIL（`writer.go` 不存在）。

- [ ] **Step 3: 实现 writer 与 positions**

创建 `ais/internal/store/pg/writer.go`：
```go
package pg

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"ais/internal/model"
)

var ErrQueueFull = errors.New("writer queue full")

type Inserter interface {
	InsertBatch(ctx context.Context, rows []model.Position) error
}

type WriterOptions struct {
	FlushInterval time.Duration
	BatchSize     int
	QueueSize     int
}

type Writer struct {
	inserter Inserter
	opts     WriterOptions
	log      *slog.Logger

	ch      chan model.Position
	buf     []model.Position
	flushed uint64
	dropped uint64
}

func NewWriter(inserter Inserter, opts WriterOptions, log *slog.Logger) *Writer {
	if opts.FlushInterval <= 0 {
		opts.FlushInterval = time.Second
	}
	if opts.BatchSize <= 0 {
		opts.BatchSize = 1000
	}
	if opts.QueueSize <= 0 {
		opts.QueueSize = 100000
	}
	return &Writer{
		inserter: inserter,
		opts:     opts,
		log:      log,
		ch:       make(chan model.Position, opts.QueueSize),
	}
}

// Enqueue adds a position to the write queue. Returns ErrQueueFull when the
// queue is full (the message is dropped and counted).
func (w *Writer) Enqueue(p model.Position) error {
	select {
	case w.ch <- p:
		return nil
	default:
		w.dropped++
		w.log.Error("writer queue full, dropping position",
			"mmsi", p.MMSI, "dropped_total", w.dropped)
		return ErrQueueFull
	}
}

func (w *Writer) Run(ctx context.Context) {
	ticker := time.NewTicker(w.opts.FlushInterval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			w.finalFlush()
			return
		case p := <-w.ch:
			w.buf = append(w.buf, p)
			if len(w.buf) >= w.opts.BatchSize {
				w.flush(context.Background())
			}
		case <-ticker.C:
			w.flush(context.Background())
		}
	}
}

func (w *Writer) flush(ctx context.Context) {
	if len(w.buf) == 0 {
		return
	}
	rows := w.buf
	w.buf = nil
	if err := w.inserter.InsertBatch(ctx, rows); err != nil {
		w.log.Error("flush positions failed", "err", err, "rows", len(rows))
		time.Sleep(time.Second)
		if err2 := w.inserter.InsertBatch(context.Background(), rows); err2 != nil {
			w.log.Error("flush positions retry failed, dropping batch", "err", err2, "rows", len(rows))
			w.dropped += uint64(len(rows))
			return
		}
	}
	w.flushed += uint64(len(rows))
}

// finalFlush runs at shutdown with a bounded timeout so queued rows are not
// silently lost when the database is healthy.
func (w *Writer) finalFlush() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	w.flush(ctx)
}

func (w *Writer) Stats() (flushed, dropped uint64) {
	return w.flushed, w.dropped
}
```

创建 `ais/internal/store/pg/positions.go`：
```go
package pg

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Positions struct {
	pool *pgxpool.Pool
}

func NewPositions(pool *pgxpool.Pool) *Positions {
	return &Positions{pool: pool}
}

var _ store.PositionStore = (*Positions)(nil)

func (p *Positions) InsertBatch(ctx context.Context, rows []model.Position) error {
	if len(rows) == 0 {
		return nil
	}
	days := map[string]struct{}{}
	for _, r := range rows {
		days[PartitionName(r.Ts)] = struct{}{}
	}
	for day := range days {
		t, err := time.Parse("20060102", day)
		if err != nil {
			return err
		}
		if err := EnsurePartition(ctx, p.pool, t); err != nil {
			return err
		}
	}
	batch := &pgx.Batch{}
	for _, r := range rows {
		batch.Queue(`INSERT INTO ais_positions (mmsi, ts, lat, lon, sog, cog, heading, nav_status, msg_type, source)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
			r.MMSI, r.Ts, r.Lat, r.Lon, r.SOG, r.COG, r.Heading, r.NavStatus, r.MsgType, r.Source)
	}
	br := p.pool.SendBatch(ctx, batch)
	defer br.Close()
	for range rows {
		if _, err := br.Exec(); err != nil {
			return fmt.Errorf("insert position: %w", err)
		}
	}
	return nil
}

func (p *Positions) Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error) {
	var rows pgx.Rows
	var err error
	if bucketSec > 1 {
		rows, err = p.pool.Query(ctx, `
			SELECT to_timestamp(floor(extract(epoch FROM ts) / $4) * $4) AS bucket,
			       avg(lat)::float8, avg(lon)::float8, max(sog)::float4
			FROM ais_positions
			WHERE mmsi = $1 AND ts >= $2 AND ts <= $3
			GROUP BY 1 ORDER BY 1 LIMIT $5`,
			mmsi, start, end, bucketSec, limit)
	} else {
		rows, err = p.pool.Query(ctx, `
			SELECT ts, lat, lon, sog
			FROM ais_positions
			WHERE mmsi = $1 AND ts >= $2 AND ts <= $3
			ORDER BY ts LIMIT $4`,
			mmsi, start, end, limit)
	}
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	pts := []model.TrackPoint{}
	for rows.Next() {
		var tp model.TrackPoint
		if err := rows.Scan(&tp.Ts, &tp.Lat, &tp.Lon, &tp.SOG); err != nil {
			return nil, err
		}
		pts = append(pts, tp)
	}
	return pts, rows.Err()
}

func (p *Positions) LatestFallback(ctx context.Context) ([]model.Position, error) {
	rows, err := p.pool.Query(ctx, `
		SELECT DISTINCT ON (mmsi) mmsi, ts, lat, lon, sog, cog, heading, nav_status, msg_type, source
		FROM ais_positions
		ORDER BY mmsi, ts DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []model.Position{}
	for rows.Next() {
		var pos model.Position
		if err := rows.Scan(&pos.MMSI, &pos.Ts, &pos.Lat, &pos.Lon, &pos.SOG, &pos.COG,
			&pos.Heading, &pos.NavStatus, &pos.MsgType, &pos.Source); err != nil {
			return nil, err
		}
		out = append(out, pos)
	}
	return out, rows.Err()
}

func (p *Positions) FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error) {
	rows, err := p.pool.Query(ctx, `
		SELECT DISTINCT mmsi
		FROM ais_positions
		WHERE ts >= $2 AND ts < $3
		  AND ST_Intersects(geom, (SELECT area FROM geofences WHERE id = $1))
		ORDER BY mmsi`,
		fenceID, start, end)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []uint32{}
	for rows.Next() {
		var mmsi uint32
		if err := rows.Scan(&mmsi); err != nil {
			return nil, err
		}
		out = append(out, mmsi)
	}
	return out, rows.Err()
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/store/pg/...
```
Expected: writer 4 个测试 PASS + Task 5 测试 PASS（集成测试需 TEST_DATABASE_URL 才跑）。

- [ ] **Step 5: 集成验证（可选但建议）**

```powershell
$env:TEST_DATABASE_URL = "postgres://ais:ais@localhost:5432/ais?sslmode=disable"
go test ./internal/store/pg/... -run "TestMigrateAndPartitions|TestWriter" -v
```
Expected: 全部 PASS。

- [ ] **Step 6: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 7: Redis 缓存层（最新船位、围栏集合、pub/sub）

**Files:**
- Create: `ais/internal/cache/redis.go`
- Create: `ais/internal/cache/redis_test.go`

**Interfaces:**
- Consumes: `model.Position`、`model.FenceEvent`（Task 2 产物）。
- Produces:
  - `cache.Cache` 接口（方法见下）
  - `cache.New(addr, password string) *Client`（实现 `cache.Cache`）
  - `(*Client).Ping(ctx) error`；`(*Client).Close() error`
- Redis key 约定：最新船位哈希 `ais:latest`（field=mmsi 十进制字符串，value=Position JSON）；围栏集合 `ais:fence:{fenceID}`（成员为 mmsi 十进制字符串）；pub/sub 频道 `ais:positions`、`ais:fence-events`。
- `Cache` 接口全量方法：
```go
type Cache interface {
	SetLatest(ctx context.Context, p model.Position) error
	AllLatest(ctx context.Context) ([]model.Position, error)
	FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceMembers(ctx context.Context, fenceID int64) ([]uint32, error)
	ClearFence(ctx context.Context, fenceID int64) error
	PublishPosition(ctx context.Context, p model.Position) error
	SubscribePositions(ctx context.Context) (<-chan model.Position, <-chan error)
	PublishFenceEvent(ctx context.Context, e model.FenceEvent) error
	SubscribeFenceEvents(ctx context.Context) (<-chan model.FenceEvent, <-chan error)
	Close() error
}
```

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/cache/redis_test.go`：
```go
package cache

import (
	"context"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"

	"ais/internal/model"
)

func newTestClient(t *testing.T) (*Client, *miniredis.Miniredis) {
	t.Helper()
	s := miniredis.RunT(t)
	return New(s.Addr(), ""), s
}

func TestSetAndAllLatest(t *testing.T) {
	c, _ := newTestClient(t)
	ctx := context.Background()
	p := model.Position{MMSI: 413123456, Ts: time.Now(), Lat: 22.5, Lon: 113.9, SOG: 10, COG: 90, Heading: 95, MsgType: 1, Source: "st1"}
	if err := c.SetLatest(ctx, p); err != nil {
		t.Fatalf("SetLatest() error = %v", err)
	}
	items, err := c.AllLatest(ctx)
	if err != nil {
		t.Fatalf("AllLatest() error = %v", err)
	}
	if len(items) != 1 {
		t.Fatalf("AllLatest() len = %d, want 1", len(items))
	}
	got := items[0]
	if got.MMSI != p.MMSI || got.Lat != p.Lat || got.Lon != p.Lon {
		t.Errorf("got %+v, want %+v", got, p)
	}
}

func TestFenceSet(t *testing.T) {
	c, _ := newTestClient(t)
	ctx := context.Background()
	if err := c.FenceAdd(ctx, 7, 111); err != nil {
		t.Fatal(err)
	}
	if err := c.FenceAdd(ctx, 7, 222); err != nil {
		t.Fatal(err)
	}
	members, err := c.FenceMembers(ctx, 7)
	if err != nil {
		t.Fatal(err)
	}
	if len(members) != 2 {
		t.Fatalf("FenceMembers() len = %d, want 2", len(members))
	}
	if err := c.FenceRemove(ctx, 7, 111); err != nil {
		t.Fatal(err)
	}
	members, _ = c.FenceMembers(ctx, 7)
	if len(members) != 1 || members[0] != 222 {
		t.Errorf("FenceMembers() after remove = %v, want [222]", members)
	}
	if err := c.ClearFence(ctx, 7); err != nil {
		t.Fatal(err)
	}
	members, _ = c.FenceMembers(ctx, 7)
	if len(members) != 0 {
		t.Errorf("FenceMembers() after clear = %v, want empty", members)
	}
}

func TestPublishSubscribePositions(t *testing.T) {
	c, _ := newTestClient(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	ch, errc := c.SubscribePositions(ctx)

	time.Sleep(50 * time.Millisecond) // 等待订阅就绪
	p := model.Position{MMSI: 999, Ts: time.Now(), Lat: 1, Lon: 2}
	if err := c.PublishPosition(ctx, p); err != nil {
		t.Fatalf("PublishPosition() error = %v", err)
	}
	select {
	case got := <-ch:
		if got.MMSI != 999 {
			t.Errorf("received MMSI = %d, want 999", got.MMSI)
		}
	case err := <-errc:
		t.Fatalf("subscription error: %v", err)
	case <-time.After(3 * time.Second):
		t.Fatal("timeout waiting for published position")
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/cache/...
```
Expected: FAIL（`redis.go` 不存在）。

- [ ] **Step 3: 实现 cache**

创建 `ais/internal/cache/redis.go`：
```go
// Package cache provides the Redis-backed latest-position snapshot,
// fence membership sets and pub/sub channels.
package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/redis/go-redis/v9"

	"ais/internal/model"
)

const (
	latestKey    = "ais:latest"
	channelPos   = "ais:positions"
	channelEvent = "ais:fence-events"
)

func fenceSetKey(id int64) string {
	return fmt.Sprintf("ais:fence:%d", id)
}

type Cache interface {
	SetLatest(ctx context.Context, p model.Position) error
	AllLatest(ctx context.Context) ([]model.Position, error)
	FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceMembers(ctx context.Context, fenceID int64) ([]uint32, error)
	ClearFence(ctx context.Context, fenceID int64) error
	PublishPosition(ctx context.Context, p model.Position) error
	SubscribePositions(ctx context.Context) (<-chan model.Position, <-chan error)
	PublishFenceEvent(ctx context.Context, e model.FenceEvent) error
	SubscribeFenceEvents(ctx context.Context) (<-chan model.FenceEvent, <-chan error)
	Close() error
}

type Client struct {
	rdb *redis.Client
}

func New(addr, password string) *Client {
	return &Client{rdb: redis.NewClient(&redis.Options{Addr: addr, Password: password})}
}

func (c *Client) Ping(ctx context.Context) error {
	return c.rdb.Ping(ctx).Err()
}

func (c *Client) Close() error {
	return c.rdb.Close()
}

func (c *Client) SetLatest(ctx context.Context, p model.Position) error {
	b, err := json.Marshal(p)
	if err != nil {
		return err
	}
	return c.rdb.HSet(ctx, latestKey, strconv.FormatUint(uint64(p.MMSI), 10), b).Err()
}

func (c *Client) AllLatest(ctx context.Context) ([]model.Position, error) {
	m, err := c.rdb.HGetAll(ctx, latestKey).Result()
	if err != nil {
		return nil, err
	}
	out := make([]model.Position, 0, len(m))
	for _, v := range m {
		var p model.Position
		if err := json.Unmarshal([]byte(v), &p); err != nil {
			continue
		}
		out = append(out, p)
	}
	return out, nil
}

func (c *Client) FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error {
	return c.rdb.SAdd(ctx, fenceSetKey(fenceID), strconv.FormatUint(uint64(mmsi), 10)).Err()
}

func (c *Client) FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error {
	return c.rdb.SRem(ctx, fenceSetKey(fenceID), strconv.FormatUint(uint64(mmsi), 10)).Err()
}

func (c *Client) FenceMembers(ctx context.Context, fenceID int64) ([]uint32, error) {
	raw, err := c.rdb.SMembers(ctx, fenceSetKey(fenceID)).Result()
	if err != nil {
		return nil, err
	}
	out := make([]uint32, 0, len(raw))
	for _, s := range raw {
		v, err := strconv.ParseUint(s, 10, 32)
		if err != nil {
			continue
		}
		out = append(out, uint32(v))
	}
	return out, nil
}

func (c *Client) ClearFence(ctx context.Context, fenceID int64) error {
	return c.rdb.Del(ctx, fenceSetKey(fenceID)).Err()
}

func (c *Client) PublishPosition(ctx context.Context, p model.Position) error {
	b, err := json.Marshal(p)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channelPos, b).Err()
}

func (c *Client) SubscribePositions(ctx context.Context) (<-chan model.Position, <-chan error) {
	ch := make(chan model.Position, 256)
	errc := make(chan error, 1)
	sub := c.rdb.Subscribe(ctx, channelPos)
	go func() {
		defer sub.Close()
		for {
			msg, err := sub.ReceiveMessage(ctx)
			if err != nil {
				errc <- err
				return
			}
			var p model.Position
			if err := json.Unmarshal([]byte(msg.Payload), &p); err != nil {
				continue
			}
			ch <- p
		}
	}()
	return ch, errc
}

func (c *Client) PublishFenceEvent(ctx context.Context, e model.FenceEvent) error {
	b, err := json.Marshal(e)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channelEvent, b).Err()
}

func (c *Client) SubscribeFenceEvents(ctx context.Context) (<-chan model.FenceEvent, <-chan error) {
	ch := make(chan model.FenceEvent, 256)
	errc := make(chan error, 1)
	sub := c.rdb.Subscribe(ctx, channelEvent)
	go func() {
		defer sub.Close()
		for {
			msg, err := sub.ReceiveMessage(ctx)
			if err != nil {
				errc <- err
				return
			}
			var e model.FenceEvent
			if err := json.Unmarshal([]byte(msg.Payload), &e); err != nil {
				continue
			}
			ch <- e
		}
	}()
	return ch, errc
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/cache/...
```
Expected: PASS（3 个测试，miniredis 无需真实 Redis）。

- [ ] **Step 5: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。

---

### Task 8: WebSocket Hub（实时推送）

**Files:**
- Create: `ais/internal/wshub/hub.go`
- Create: `ais/internal/wshub/hub_test.go`

**Interfaces:**
- Consumes: 无。
- Produces:
  - `wshub.NewHub() *Hub`
  - `(*Hub).Run(ctx context.Context)`（阻塞处理注册/注销/广播）
  - `(*Hub).Broadcast(msg []byte)`
  - `(*Hub).Connections() int64`
  - `(*Hub).ServeWS(w http.ResponseWriter, r *http.Request)`（升级连接并启动读写泵）
- 行为约定：每个客户端 send 缓冲 256 条，慢客户端被断开；`Broadcast` 非阻塞（channel 满则丢弃该条消息并继续）。

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/wshub/hub_test.go`：
```go
package wshub

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

func TestHub_broadcastToClient(t *testing.T) {
	hub := NewHub()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go hub.Run(ctx)

	ts := httptest.NewServer(http.HandlerFunc(hub.ServeWS))
	defer ts.Close()

	wsURL := "ws" + strings.TrimPrefix(ts.URL, "http") + "/ws"
	conn, _, err := websocket.DefaultDialer.Dial(wsURL, nil)
	if err != nil {
		t.Fatalf("dial error = %v", err)
	}
	defer conn.Close()

	waitUntil(t, 3*time.Second, func() bool { return hub.Connections() == 1 }, "client did not register")

	hub.Broadcast([]byte(`{"type":"position"}`))
	_ = conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	_, data, err := conn.ReadMessage()
	if err != nil {
		t.Fatalf("ReadMessage() error = %v", err)
	}
	if string(data) != `{"type":"position"}` {
		t.Errorf("got %s, want {\"type\":\"position\"}", data)
	}
}

func TestHub_broadcastToMultipleClients(t *testing.T) {
	hub := NewHub()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go hub.Run(ctx)

	ts := httptest.NewServer(http.HandlerFunc(hub.ServeWS))
	defer ts.Close()
	wsURL := "ws" + strings.TrimPrefix(ts.URL, "http") + "/ws"

	conns := make([]*websocket.Conn, 3)
	for i := range conns {
		c, _, err := websocket.DefaultDialer.Dial(wsURL, nil)
		if err != nil {
			t.Fatalf("dial %d error = %v", i, err)
		}
		defer c.Close()
		conns[i] = c
	}
	waitUntil(t, 3*time.Second, func() bool { return hub.Connections() == 3 }, "clients did not register")

	hub.Broadcast([]byte("hello"))
	for _, c := range conns {
		_ = c.SetReadDeadline(time.Now().Add(3 * time.Second))
		if _, data, err := c.ReadMessage(); err != nil || string(data) != "hello" {
			t.Errorf("client got %q, err %v; want hello", data, err)
		}
	}
}

func waitUntil(t *testing.T, timeout time.Duration, cond func() bool, msg string) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal(msg)
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/wshub/...
```
Expected: FAIL（`hub.go` 不存在）。

- [ ] **Step 3: 实现 hub**

创建 `ais/internal/wshub/hub.go`：
```go
// Package wshub implements a fan-out WebSocket hub with slow-client eviction.
package wshub

import (
	"context"
	"net/http"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
)

const (
	writeWait      = 10 * time.Second
	pongWait       = 60 * time.Second
	pingPeriod     = 30 * time.Second
	maxMessageSize = 1024
	sendBuffer     = 256
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 4096,
	// 鉴权在升级前由 API 层完成；跨域限制由 Nginx 层处理。
	CheckOrigin: func(r *http.Request) bool { return true },
}

type client struct {
	hub  *Hub
	conn *websocket.Conn
	send chan []byte
}

type Hub struct {
	register   chan *client
	unregister chan *client
	clients    map[*client]struct{}
	broadcast  chan []byte
	conns      atomic.Int64
}

func NewHub() *Hub {
	return &Hub{
		register:   make(chan *client),
		unregister: make(chan *client),
		clients:    make(map[*client]struct{}),
		broadcast:  make(chan []byte, 256),
	}
}

func (h *Hub) Run(ctx context.Context) {
	for {
		select {
		case c := <-h.register:
			h.clients[c] = struct{}{}
			h.conns.Add(1)
		case c := <-h.unregister:
			if _, ok := h.clients[c]; ok {
				delete(h.clients, c)
				close(c.send)
				h.conns.Add(-1)
			}
		case msg := <-h.broadcast:
			for c := range h.clients {
				select {
				case c.send <- msg:
				default:
					// 慢客户端：关闭并移除
					close(c.send)
					delete(h.clients, c)
					h.conns.Add(-1)
				}
			}
		case <-ctx.Done():
			for c := range h.clients {
				close(c.send)
				delete(h.clients, c)
			}
			h.conns.Store(0)
			return
		}
	}
}

func (h *Hub) Broadcast(msg []byte) {
	select {
	case h.broadcast <- msg:
	default:
		// broadcast 队列满时丢弃该条，保证不阻塞调用方
	}
}

func (h *Hub) Connections() int64 {
	return h.conns.Load()
}

func (h *Hub) ServeWS(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	c := &client{hub: h, conn: conn, send: make(chan []byte, sendBuffer)}
	h.register <- c
	go c.writePump()
	go c.readPump()
}

func (c *client) readPump() {
	defer func() {
		c.hub.unregister <- c
		_ = c.conn.Close()
	}()
	c.conn.SetReadLimit(maxMessageSize)
	_ = c.conn.SetReadDeadline(time.Now().Add(pongWait))
	c.conn.SetPongHandler(func(string) error {
		return c.conn.SetReadDeadline(time.Now().Add(pongWait))
	})
	for {
		if _, _, err := c.conn.ReadMessage(); err != nil {
			return
		}
	}
}

func (c *client) writePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		_ = c.conn.Close()
	}()
	for {
		select {
		case msg, ok := <-c.send:
			_ = c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if !ok {
				_ = c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			if err := c.conn.WriteMessage(websocket.TextMessage, msg); err != nil {
				return
			}
		case <-ticker.C:
			_ = c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/wshub/...
```
Expected: PASS（2 个测试）。

- [ ] **Step 5: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 9: 鉴权与查询 API（login / 轨迹 / 最新船位 / 船舶 / 基站）

**Files:**
- Create: `ais/internal/store/pg/vessels.go`
- Create: `ais/internal/store/pg/users.go`
- Create: `ais/internal/api/response.go`
- Create: `ais/internal/api/auth.go`
- Create: `ais/internal/api/auth_test.go`
- Create: `ais/internal/api/server.go`
- Create: `ais/internal/api/handlers.go`
- Create: `ais/internal/api/handlers_test.go`

**Interfaces:**
- Consumes: `store.PositionStore/VesselStore/UserStore`、`pg.Positions`（Task 5/6）、`cache.Cache`（Task 7）、`wshub.Hub`（Task 8）、`station.Manager`（Task 4）。
- Produces:
  - `api.ServerConfig{JWTSecret string; JWTTTL time.Duration}`
  - `api.Server` 结构体（导出字段，供 main 装配）：`Cfg ServerConfig; Positions PositionRepo; Latest LatestCache; Vessels VesselRepo; Users UserRepo; Geofences GeofenceRepo; PosHub, EventHub *wshub.Hub; StationMgr *station.Manager; Log *slog.Logger`
  - `api.PositionRepo{Track(...); LatestFallback(...)}`；`api.LatestCache{AllLatest(ctx) ([]model.Position, error)}`；`api.VesselRepo{List(ctx, page, pageSize int, search string) ([]model.Vessel, int64, error)}`；`api.UserRepo{GetByUsername(ctx, username string) (model.User, error)}`；`api.GeofenceRepo`（Task 10 使用，本任务先声明占位）
  - `api.GenerateToken(secret string, user model.User, ttl time.Duration) (string, error)`；`api.ParseToken(secret, token string) (*api.Claims, error)`；`api.AuthMiddleware(secret string, next http.Handler) http.Handler`；`api.WSQueryAuth(secret string, r *http.Request) bool`
  - `(*Server).Handler() http.Handler`（Go 1.22 方法路由 mux）
- 路由（本任务实现部分）：
  - `GET /api/v1/healthz`（无鉴权）
  - `POST /api/v1/auth/login`（无鉴权，返回 JWT）
  - `GET /api/v1/positions/latest`（Bearer 鉴权，Redis 兜底 DB）
  - `GET /api/v1/vessels/{mmsi}/track?start=ISO8601&end=ISO8601[&bucket=60][&limit=10000]`
  - `GET /api/v1/vessels?page=1&page_size=50&search=`
  - `GET /api/v1/base-stations`（来自 station.Manager 运行时状态）
  - `GET /ws/positions`、`GET /ws/fence-events`（?token= 查询参数鉴权后升级）
- 响应约定：成功 `{"...":"..."}` 结构见 handler 实现；错误统一 `{"error":"..."}`；轨迹接口参数校验失败返回 400；未找到返回 404；内部错误返回 500。

- [ ] **Step 1: 写失败测试（auth 单测）**

创建 `ais/internal/api/auth_test.go`：
```go
package api

import (
	"testing"
	"time"

	"ais/internal/model"
)

func TestGenerateAndParseToken(t *testing.T) {
	user := model.User{ID: 7, Username: "admin", Role: "admin"}
	token, err := GenerateToken("secret-1", user, time.Hour)
	if err != nil {
		t.Fatalf("GenerateToken() error = %v", err)
	}
	claims, err := ParseToken("secret-1", token)
	if err != nil {
		t.Fatalf("ParseToken() error = %v", err)
	}
	if claims.UserID != 7 || claims.Username != "admin" || claims.Role != "admin" {
		t.Errorf("claims = %+v, want user 7 admin", claims)
	}
}

func TestParseToken_wrongSecret(t *testing.T) {
	user := model.User{ID: 1, Username: "u", Role: "user"}
	token, err := GenerateToken("secret-1", user, time.Hour)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := ParseToken("secret-2", token); err == nil {
		t.Fatal("ParseToken() expected error for wrong secret")
	}
}

func TestParseToken_expired(t *testing.T) {
	user := model.User{ID: 1, Username: "u", Role: "user"}
	token, err := GenerateToken("secret-1", user, -time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := ParseToken("secret-1", token); err == nil {
		t.Fatal("ParseToken() expected error for expired token")
	}
}
```

- [ ] **Step 2: 写失败测试（handlers 单测）**

创建 `ais/internal/api/handlers_test.go`：
```go
package api

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"ais/internal/model"
	"ais/internal/store"
)

var (
	errNotFoundSentinel = store.ErrNotFound
	errRedisDown        = errors.New("redis down")
)

type fakePositions struct {
	track    []model.TrackPoint
	fallback []model.Position
	err      error
}

func (f *fakePositions) Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error) {
	return f.track, f.err
}

func (f *fakePositions) LatestFallback(ctx context.Context) ([]model.Position, error) {
	return f.fallback, f.err
}

type fakeLatest struct {
	items []model.Position
	err   error
}

func (f *fakeLatest) AllLatest(ctx context.Context) ([]model.Position, error) {
	return f.items, f.err
}

type fakeVessels struct {
	items []model.Vessel
	total int64
}

func (f *fakeVessels) List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error) {
	return f.items, f.total, nil
}

type fakeUsers struct {
	user model.User
	err  error
}

func (f *fakeUsers) GetByUsername(ctx context.Context, username string) (model.User, error) {
	return f.user, f.err
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func newTestServer(t *testing.T, s *Server) *httptest.Server {
	t.Helper()
	ts := httptest.NewServer(s.Handler())
	t.Cleanup(ts.Close)
	return ts
}


func getJSON(t *testing.T, url, token string) (int, map[string]any) {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatal(err)
	}
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var m map[string]any
	_ = json.NewDecoder(resp.Body).Decode(&m)
	return resp.StatusCode, m
}

func TestHealthz(t *testing.T) {
	s := &Server{Cfg: ServerConfig{JWTSecret: "s", JWTTTL: time.Hour}, Log: testLogger()}
	ts := newTestServer(t, s)
	status, m := getJSON(t, ts.URL+"/api/v1/healthz", "")
	if status != http.StatusOK {
		t.Fatalf("healthz status = %d, want 200", status)
	}
	if m["status"] != "ok" {
		t.Errorf("healthz body = %v, want status ok", m)
	}
}

func TestLogin_requiresValidUser(t *testing.T) {
	s := &Server{
		Cfg:   ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Users: &fakeUsers{err: errNotFoundSentinel},
		Log:   testLogger(),
	}
	ts := newTestServer(t, s)
	resp, err := http.Post(ts.URL+"/api/v1/auth/login", "application/json",
		strings.NewReader(`{"username":"admin","password":"wrong"}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Errorf("login status = %d, want 401", resp.StatusCode)
	}
}

func TestTrack_requiresAuthAndValidatesParams(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Positions: &fakePositions{track: []model.TrackPoint{{Ts: time.Now(), Lat: 1, Lon: 2}}},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)

	// 无 token → 401
	status, _ := getJSON(t, ts.URL+"/api/v1/vessels/477553000/track?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", "")
	if status != http.StatusUnauthorized {
		t.Errorf("track without token status = %d, want 401", status)
	}

	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	// 缺少 start → 400
	status, _ = getJSON(t, ts.URL+"/api/v1/vessels/477553000/track?end=2026-08-07T01:00:00Z", token)
	if status != http.StatusBadRequest {
		t.Errorf("track missing start status = %d, want 400", status)
	}

	// 合法请求 → 200 且返回 items
	status, m := getJSON(t, ts.URL+"/api/v1/vessels/477553000/track?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", token)
	if status != http.StatusOK {
		t.Errorf("track status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Errorf("track items = %v, want 1 item", m["items"])
	}
}

func TestLatestPositions_fallsBackToDB(t *testing.T) {
	s := &Server{
		Cfg:    ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Latest: &fakeLatest{err: errRedisDown},
		Positions: &fakePositions{
			fallback: []model.Position{{MMSI: 1, Lat: 1, Lon: 1, Ts: time.Now()}},
		},
		Log: testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)
	status, m := getJSON(t, ts.URL+"/api/v1/positions/latest", token)
	if status != http.StatusOK {
		t.Fatalf("latest status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Errorf("latest items = %v, want fallback row", m["items"])
	}
}
```

- [ ] **Step 3: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/api/...
```
Expected: FAIL（文件不存在）。

- [ ] **Step 4: 实现 vessels/users 仓储**

创建 `ais/internal/store/pg/vessels.go`：
```go
package pg

import (
	"context"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Vessels struct {
	pool *pgxpool.Pool
}

func NewVessels(pool *pgxpool.Pool) *Vessels {
	return &Vessels{pool: pool}
}

var _ store.VesselStore = (*Vessels)(nil)

func (s *Vessels) Upsert(ctx context.Context, v model.Vessel) error {
	_, err := s.pool.Exec(ctx, `
		INSERT INTO vessels (mmsi, name, imo, callsign, ship_type, length_m, beam_m, updated_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
		ON CONFLICT (mmsi) DO UPDATE SET
			name      = COALESCE(NULLIF(EXCLUDED.name, ''), vessels.name),
			imo       = COALESCE(EXCLUDED.imo, vessels.imo),
			callsign  = COALESCE(NULLIF(EXCLUDED.callsign, ''), vessels.callsign),
			ship_type = CASE WHEN EXCLUDED.ship_type <> 0 THEN EXCLUDED.ship_type ELSE vessels.ship_type END,
			length_m  = CASE WHEN EXCLUDED.length_m > 0 THEN EXCLUDED.length_m ELSE vessels.length_m END,
			beam_m    = CASE WHEN EXCLUDED.beam_m > 0 THEN EXCLUDED.beam_m ELSE vessels.beam_m END,
			updated_at = EXCLUDED.updated_at`,
		v.MMSI, v.Name, v.IMO, v.Callsign, v.ShipType, v.LengthM, v.BeamM, v.UpdatedAt)
	return err
}

func (s *Vessels) List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error) {
	var total int64
	if search != "" {
		like := "%" + search + "%"
		if err := s.pool.QueryRow(ctx,
			`SELECT count(*) FROM vessels WHERE name ILIKE $1 OR callsign ILIKE $1`, like).Scan(&total); err != nil {
			return nil, 0, err
		}
		rows, err := s.pool.Query(ctx, `
			SELECT mmsi, name, imo, callsign, ship_type, length_m, beam_m, updated_at
			FROM vessels WHERE name ILIKE $1 OR callsign ILIKE $1
			ORDER BY mmsi LIMIT $2 OFFSET $3`, like, pageSize, (page-1)*pageSize)
		if err != nil {
			return nil, 0, err
		}
		out, _, err := scanVessels(rows)
		return out, total, err
	}
	if err := s.pool.QueryRow(ctx, `SELECT count(*) FROM vessels`).Scan(&total); err != nil {
		return nil, 0, err
	}
	rows, err := s.pool.Query(ctx, `
		SELECT mmsi, name, imo, callsign, ship_type, length_m, beam_m, updated_at
		FROM vessels ORDER BY mmsi LIMIT $1 OFFSET $2`, pageSize, (page-1)*pageSize)
	if err != nil {
		return nil, 0, err
	}
	out, _, err := scanVessels(rows)
	return out, total, err
}

func scanVessels(rows pgx.Rows) ([]model.Vessel, int64, error) {
	defer rows.Close()
	var out []model.Vessel
	for rows.Next() {
		var v model.Vessel
		if err := rows.Scan(&v.MMSI, &v.Name, &v.IMO, &v.Callsign, &v.ShipType, &v.LengthM, &v.BeamM, &v.UpdatedAt); err != nil {
			return nil, 0, err
		}
		out = append(out, v)
	}
	return out, 0, rows.Err()
}
```

创建 `ais/internal/store/pg/users.go`：
```go
package pg

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Users struct {
	pool *pgxpool.Pool
}

func NewUsers(pool *pgxpool.Pool) *Users {
	return &Users{pool: pool}
}

var _ store.UserStore = (*Users)(nil)

func (s *Users) Create(ctx context.Context, username, passwordHash, role string) (model.User, error) {
	var u model.User
	err := s.pool.QueryRow(ctx, `
		INSERT INTO users (username, password_hash, role)
		VALUES ($1,$2,$3)
		RETURNING id, username, password_hash, role, created_at`,
		username, passwordHash, role).Scan(&u.ID, &u.Username, &u.PasswordHash, &u.Role, &u.CreatedAt)
	return u, err
}

func (s *Users) GetByUsername(ctx context.Context, username string) (model.User, error) {
	var u model.User
	err := s.pool.QueryRow(ctx, `
		SELECT id, username, password_hash, role, created_at
		FROM users WHERE username = $1`, username).Scan(&u.ID, &u.Username, &u.PasswordHash, &u.Role, &u.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return u, store.ErrNotFound
	}
	return u, err
}
```

- [ ] **Step 5: 实现 api 包（response / auth / server / handlers）**

创建 `ais/internal/api/response.go`：
```go
package api

import (
	"encoding/json"
	"log/slog"
	"net/http"
)

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(v); err != nil {
		slog.Error("write json response", "err", err)
	}
}

func writeErr(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}
```

创建 `ais/internal/api/auth.go`：
```go
package api

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"ais/internal/model"
)

type Claims struct {
	UserID   int64  `json:"uid"`
	Username string `json:"username"`
	Role     string `json:"role"`
	jwt.RegisteredClaims
}

func GenerateToken(secret string, user model.User, ttl time.Duration) (string, error) {
	now := time.Now()
	claims := Claims{
		UserID:   user.ID,
		Username: user.Username,
		Role:     user.Role,
		RegisteredClaims: jwt.RegisteredClaims{
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
			Issuer:    "ais",
		},
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString([]byte(secret))
}

func ParseToken(secret, tokenStr string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(tokenStr, &Claims{}, func(t *jwt.Token) (any, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.New("unexpected signing method")
		}
		return []byte(secret), nil
	})
	if err != nil {
		return nil, err
	}
	claims, ok := token.Claims.(*Claims)
	if !ok || !token.Valid {
		return nil, errors.New("invalid token")
	}
	return claims, nil
}

func AuthMiddleware(secret string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := r.Header.Get("Authorization")
		if !strings.HasPrefix(h, "Bearer ") {
			writeErr(w, http.StatusUnauthorized, "missing bearer token")
			return
		}
		claims, err := ParseToken(secret, strings.TrimPrefix(h, "Bearer "))
		if err != nil {
			writeErr(w, http.StatusUnauthorized, "invalid token")
			return
		}
		ctx := context.WithValue(r.Context(), claimsKey{}, claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// WSQueryAuth validates the token passed as the ?token= query parameter,
// which is how browsers authenticate WebSocket connections.
func WSQueryAuth(secret string, r *http.Request) bool {
	token := r.URL.Query().Get("token")
	if token == "" {
		return false
	}
	_, err := ParseToken(secret, token)
	return err == nil
}

type claimsKey struct{}

func ClaimsFrom(r *http.Request) *Claims {
	if c, ok := r.Context().Value(claimsKey{}).(*Claims); ok {
		return c
	}
	return nil
}
```

创建 `ais/internal/api/server.go`：
```go
// Package api implements the REST + WebSocket HTTP layer.
package api

import (
	"context"
	"log/slog"
	"net/http"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"

	"ais/internal/model"
	"ais/internal/station"
	"ais/internal/wshub"
)

type PositionRepo interface {
	Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error)
	LatestFallback(ctx context.Context) ([]model.Position, error)
}

type LatestCache interface {
	AllLatest(ctx context.Context) ([]model.Position, error)
}

type VesselRepo interface {
	List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error)
}

type UserRepo interface {
	GetByUsername(ctx context.Context, username string) (model.User, error)
}

type GeofenceRepo interface {
	List(ctx context.Context) ([]model.Geofence, error)
	Get(ctx context.Context, id int64) (model.Geofence, error)
	Create(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Update(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Delete(ctx context.Context, id int64) error
	Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error)
}

type ServerConfig struct {
	JWTSecret string
	JWTTTL    time.Duration
}

type Server struct {
	Cfg         ServerConfig
	Positions   PositionRepo
	Latest      LatestCache
	Vessels     VesselRepo
	Users       UserRepo
	Geofences   GeofenceRepo
	PosHub      *wshub.Hub
	EventHub    *wshub.Hub
	StationMgr  *station.Manager
	Log         *slog.Logger
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/v1/healthz", s.handleHealthz)
	mux.HandleFunc("POST /api/v1/auth/login", s.handleLogin)
	mux.Handle("GET /api/v1/positions/latest", s.auth(s.handleLatestPositions))
	mux.Handle("GET /api/v1/vessels/{mmsi}/track", s.auth(s.handleTrack))
	mux.Handle("GET /api/v1/vessels", s.auth(s.handleListVessels))
	mux.Handle("GET /api/v1/base-stations", s.auth(s.handleBaseStations))
	mux.Handle("GET /ws/positions", s.handleWS(s.PosHub))
	mux.Handle("GET /ws/fence-events", s.handleWS(s.EventHub))
	mux.Handle("GET /metrics", promhttp.Handler())
	return s.withMetrics(mux)
}

func (s *Server) auth(next http.HandlerFunc) http.Handler {
	return AuthMiddleware(s.Cfg.JWTSecret, http.HandlerFunc(next))
}

func (s *Server) handleWS(hub *wshub.Hub) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if hub == nil {
			writeErr(w, http.StatusServiceUnavailable, "websocket disabled")
			return
		}
		if !WSQueryAuth(s.Cfg.JWTSecret, r) {
			writeErr(w, http.StatusUnauthorized, "invalid token")
			return
		}
		hub.ServeWS(w, r)
	}
}

func (s *Server) withMetrics(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		next.ServeHTTP(w, r)
	})
}
```

创建 `ais/internal/api/handlers.go`：
```go
package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	"golang.org/x/crypto/bcrypt"

	"ais/internal/model"
	"ais/internal/store"
)

func (s *Server) handleHealthz(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid json body")
		return
	}
	if req.Username == "" || req.Password == "" {
		writeErr(w, http.StatusBadRequest, "username and password required")
		return
	}
	user, err := s.Users.GetByUsername(r.Context(), req.Username)
	if err != nil {
		if errors.Is(err, store.ErrNotFound) {
			writeErr(w, http.StatusUnauthorized, "invalid credentials")
			return
		}
		s.Log.Error("login lookup failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)) != nil {
		writeErr(w, http.StatusUnauthorized, "invalid credentials")
		return
	}
	token, err := GenerateToken(s.Cfg.JWTSecret, user, s.Cfg.JWTTTL)
	if err != nil {
		s.Log.Error("generate token failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"token": token, "username": user.Username, "role": user.Role,
	})
}

func (s *Server) handleLatestPositions(w http.ResponseWriter, r *http.Request) {
	items, err := s.Latest.AllLatest(r.Context())
	if err != nil {
		s.Log.Warn("redis latest failed, falling back to db", "err", err)
		items, err = s.Positions.LatestFallback(r.Context())
		if err != nil {
			s.Log.Error("latest fallback failed", "err", err)
			writeErr(w, http.StatusInternalServerError, "internal error")
			return
		}
	}
	if items == nil {
		items = []model.Position{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (s *Server) handleTrack(w http.ResponseWriter, r *http.Request) {
	mmsi, err := strconv.ParseUint(r.PathValue("mmsi"), 10, 32)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid mmsi")
		return
	}
	start, err := time.Parse(time.RFC3339, r.URL.Query().Get("start"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "start must be RFC3339")
		return
	}
	end, err := time.Parse(time.RFC3339, r.URL.Query().Get("end"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "end must be RFC3339")
		return
	}
	if !end.After(start) {
		writeErr(w, http.StatusBadRequest, "end must be after start")
		return
	}
	if end.Sub(start) > 31*24*time.Hour {
		writeErr(w, http.StatusBadRequest, "range limited to 31 days")
		return
	}
	bucket := 0
	if v := r.URL.Query().Get("bucket"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 86400 {
			writeErr(w, http.StatusBadRequest, "bucket must be 1..86400 seconds")
			return
		}
		bucket = n
	}
	limit := 10000
	if v := r.URL.Query().Get("limit"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 50000 {
			writeErr(w, http.StatusBadRequest, "limit must be 1..50000")
			return
		}
		limit = n
	}
	pts, err := s.Positions.Track(r.Context(), uint32(mmsi), start, end, bucket, limit)
	if err != nil {
		s.Log.Error("track query failed", "err", err, "mmsi", mmsi)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if pts == nil {
		pts = []model.TrackPoint{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"mmsi": mmsi, "items": pts})
}

func (s *Server) handleListVessels(w http.ResponseWriter, r *http.Request) {
	page := 1
	pageSize := 50
	if v := r.URL.Query().Get("page"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			page = n
		}
	}
	if v := r.URL.Query().Get("page_size"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 200 {
			pageSize = n
		}
	}
	items, total, err := s.Vessels.List(r.Context(), page, pageSize, r.URL.Query().Get("search"))
	if err != nil {
		s.Log.Error("vessels list failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if items == nil {
		items = []model.Vessel{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"total": total, "items": items})
}

func (s *Server) handleBaseStations(w http.ResponseWriter, r *http.Request) {
	if s.StationMgr == nil {
		writeJSON(w, http.StatusOK, map[string]any{"items": []any{}})
		return
	}
	statuses := s.StationMgr.Statuses()
	items := make([]map[string]any, 0, len(statuses))
	for _, st := range statuses {
		items = append(items, map[string]any{
			"id": st.ID, "name": st.Name, "connected": st.Connected,
			"last_error": st.LastError, "lines": st.Lines, "since": st.Since,
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}
```

- [ ] **Step 6: 运行 handlers 测试**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/api/...
```
Expected: PASS（auth 3 个 + handlers 5 个）。若 `TestLatestPositions_fallsBackToDB` 失败，确认 fakeLatest 的 `err` 非 nil 且 handlers.go 中 Redis 出错后确实走 fallback 分支。

- [ ] **Step 7: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 10: 围栏 CRUD 与查询 API + 点-多边形判断

**Files:**
- Create: `ais/internal/store/pg/geofences.go`
- Create: `ais/internal/fence/geo.go`
- Create: `ais/internal/fence/geo_test.go`
- Create: `ais/internal/api/handlers_geofences.go`
- Create: `ais/internal/api/handlers_geofences_test.go`
- Modify: `ais/internal/api/server.go`（在 `Handler()` 中追加围栏路由，并给 `PositionRepo` 增加 `FenceHistoryVessels` 方法）

**Interfaces:**
- Consumes: `store.GeofenceStore`（Task 5）、`store.PositionStore.FenceHistoryVessels`（Task 6）、`api.GeofenceRepo`（Task 9 已声明）、`fence.PointInPolygon`（本任务产出）。
- Produces:
  - `pg.NewGeofences(pool *pgxpool.Pool) *Geofences`（实现 `store.GeofenceStore`）
  - `fence.PointInPolygon(p orb.Point, poly orb.Polygon) bool`（射线法；`orb.Polygon[0]` 为外环，其余为洞；坐标顺序 [lon, lat]）
  - 路由（追加到 `Handler()`）：
    - `GET /api/v1/geofences`（列表）
    - `POST /api/v1/geofences`（创建，GeoJSON Polygon）
    - `GET /api/v1/geofences/{id}`、`PUT /api/v1/geofences/{id}`、`DELETE /api/v1/geofences/{id}`
    - `GET /api/v1/geofences/{id}/vessels/current`（Redis 最新船位 + 应用侧点-多边形过滤）
    - `GET /api/v1/geofences/{id}/vessels/history?start=&end=`（PostGIS 去重列表）
    - `GET /api/v1/geofences/{id}/events?start=&end=&limit=`
- 行为约定：创建/更新围栏必须校验 name 非空、area 为闭合 Polygon（≥4 点，首尾相同）；`POST` 成功返回 201；`GET {id}` 不存在返回 404；`history` 必须提供 start/end 且跨度 ≤ 31 天。

- [ ] **Step 1: 写失败测试（geo 纯函数）**

创建 `ais/internal/fence/geo_test.go`：
```go
package fence

import (
	"testing"

	"github.com/paulmach/orb"
)

func square() orb.Polygon {
	return orb.Polygon{orb.Ring{
		{0, 0}, {10, 0}, {10, 10}, {0, 10}, {0, 0},
	}}
}

func TestPointInPolygon_inside(t *testing.T) {
	if !PointInPolygon(orb.Point{5, 5}, square()) {
		t.Error("point (5,5) should be inside")
	}
}

func TestPointInPolygon_outside(t *testing.T) {
	if PointInPolygon(orb.Point{15, 5}, square()) {
		t.Error("point (15,5) should be outside")
	}
	if PointInPolygon(orb.Point{-1, 5}, square()) {
		t.Error("point (-1,5) should be outside")
	}
}

func TestPointInPolygon_holeExcludes(t *testing.T) {
	poly := orb.Polygon{
		orb.Ring{{0, 0}, {10, 0}, {10, 10}, {0, 10}, {0, 0}},
		orb.Ring{{2, 2}, {8, 2}, {8, 8}, {2, 8}, {2, 2}},
	}
	if PointInPolygon(orb.Point{5, 5}, poly) {
		t.Error("point in hole should be outside")
	}
	if !PointInPolygon(orb.Point{9, 9}, poly) {
		t.Error("point between outer ring and hole should be inside")
	}
}

func TestPointInPolygon_emptyPolygon(t *testing.T) {
	if PointInPolygon(orb.Point{5, 5}, orb.Polygon{}) {
		t.Error("empty polygon should contain nothing")
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/fence/...
```
Expected: FAIL（`geo.go` 不存在）。

- [ ] **Step 3: 实现 geo**

创建 `ais/internal/fence/geo.go`：
```go
// Package fence provides point-in-polygon logic and the geofence state machine.
package fence

import "github.com/paulmach/orb"

// PointInPolygon reports whether p is inside the polygon (ray casting).
// Rings after the first are holes and exclude the point.
func PointInPolygon(p orb.Point, poly orb.Polygon) bool {
	if len(poly) == 0 {
		return false
	}
	if !inRing(p, poly[0]) {
		return false
	}
	for _, hole := range poly[1:] {
		if inRing(p, hole) {
			return false
		}
	}
	return true
}

func inRing(p orb.Point, ring orb.Ring) bool {
	inside := false
	n := len(ring)
	for i, j := 0, n-1; i < n; j, i = i, i+1 {
		a, b := ring[i], ring[j]
		if (a[1] > p[1]) != (b[1] > p[1]) &&
			p[0] < (b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0] {
			inside = !inside
		}
	}
	return inside
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go test ./internal/fence/...
```
Expected: PASS（4 个测试）。

- [ ] **Step 5: 实现 geofences 仓储**

创建 `ais/internal/store/pg/geofences.go`：
```go
package pg

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Geofences struct {
	pool *pgxpool.Pool
}

func NewGeofences(pool *pgxpool.Pool) *Geofences {
	return &Geofences{pool: pool}
}

var _ store.GeofenceStore = (*Geofences)(nil)

const geofenceCols = `id, name, ST_AsGeoJSON(area), enabled, enter_alert, leave_alert, debounce_count, silence_timeout_min, created_at`

func scanGeofence(row pgx.Row) (model.Geofence, error) {
	var g model.Geofence
	var areaJSON []byte
	err := row.Scan(&g.ID, &g.Name, &areaJSON, &g.Enabled, &g.EnterAlert, &g.LeaveAlert,
		&g.DebounceCount, &g.SilenceTimeoutMin, &g.CreatedAt)
	if err != nil {
		return g, err
	}
	if err := json.Unmarshal(areaJSON, &g.Area); err != nil {
		return g, err
	}
	return g, nil
}

func (s *Geofences) List(ctx context.Context) ([]model.Geofence, error) {
	rows, err := s.pool.Query(ctx, `SELECT `+geofenceCols+` FROM geofences ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return collectGeofences(rows)
}

func (s *Geofences) ListEnabled(ctx context.Context) ([]model.Geofence, error) {
	rows, err := s.pool.Query(ctx, `SELECT `+geofenceCols+` FROM geofences WHERE enabled ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return collectGeofences(rows)
}

func collectGeofences(rows pgx.Rows) ([]model.Geofence, error) {
	var out []model.Geofence
	for rows.Next() {
		var g model.Geofence
		var areaJSON []byte
		if err := rows.Scan(&g.ID, &g.Name, &areaJSON, &g.Enabled, &g.EnterAlert, &g.LeaveAlert,
			&g.DebounceCount, &g.SilenceTimeoutMin, &g.CreatedAt); err != nil {
			return nil, err
		}
		if err := json.Unmarshal(areaJSON, &g.Area); err != nil {
			return nil, err
		}
		out = append(out, g)
	}
	return out, rows.Err()
}

func (s *Geofences) Get(ctx context.Context, id int64) (model.Geofence, error) {
	g, err := scanGeofence(s.pool.QueryRow(ctx,
		`SELECT `+geofenceCols+` FROM geofences WHERE id = $1`, id))
	if errors.Is(err, pgx.ErrNoRows) {
		return g, store.ErrNotFound
	}
	return g, err
}

func (s *Geofences) Create(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	areaJSON, err := g.Area.MarshalJSON()
	if err != nil {
		return g, err
	}
	return scanGeofence(s.pool.QueryRow(ctx, `
		INSERT INTO geofences (name, area, enabled, enter_alert, leave_alert, debounce_count, silence_timeout_min)
		VALUES ($1, ST_GeomFromGeoJSON($2), $3, $4, $5, $6, $7)
		RETURNING `+geofenceCols,
		g.Name, string(areaJSON), g.Enabled, g.EnterAlert, g.LeaveAlert, g.DebounceCount, g.SilenceTimeoutMin))
}

func (s *Geofences) Update(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	areaJSON, err := g.Area.MarshalJSON()
	if err != nil {
		return g, err
	}
	updated, err := scanGeofence(s.pool.QueryRow(ctx, `
		UPDATE geofences SET
			name = $2, area = ST_GeomFromGeoJSON($3), enabled = $4,
			enter_alert = $5, leave_alert = $6, debounce_count = $7, silence_timeout_min = $8
		WHERE id = $1
		RETURNING `+geofenceCols,
		g.ID, g.Name, string(areaJSON), g.Enabled, g.EnterAlert, g.LeaveAlert, g.DebounceCount, g.SilenceTimeoutMin))
	if errors.Is(err, pgx.ErrNoRows) {
		return updated, store.ErrNotFound
	}
	return updated, err
}

func (s *Geofences) Delete(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM geofences WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return store.ErrNotFound
	}
	return nil
}

func (s *Geofences) Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT id, fence_id, mmsi, event_type, ts, COALESCE(lat, 0), COALESCE(lon, 0)
		FROM fence_events
		WHERE fence_id = $1 AND ts >= $2 AND ts < $3
		ORDER BY ts DESC LIMIT $4`,
		fenceID, start, end, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []model.FenceEvent
	for rows.Next() {
		var e model.FenceEvent
		if err := rows.Scan(&e.ID, &e.FenceID, &e.MMSI, &e.EventType, &e.Ts, &e.Lat, &e.Lon); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

func (s *Geofences) InsertEvent(ctx context.Context, e model.FenceEvent) error {
	_, err := s.pool.Exec(ctx, `
		INSERT INTO fence_events (fence_id, mmsi, event_type, ts, lat, lon)
		VALUES ($1,$2,$3,$4,$5,$6)`,
		e.FenceID, e.MMSI, e.EventType, e.Ts, e.Lat, e.Lon)
	return err
}

func (s *Geofences) DeleteEventsBefore(ctx context.Context, before time.Time) (int64, error) {
	tag, err := s.pool.Exec(ctx, `DELETE FROM fence_events WHERE ts < $1`, before)
	if err != nil {
		return 0, err
	}
	return tag.RowsAffected(), nil
}
```
- [ ] **Step 6: 实现围栏 handlers 并在 server.go 注册路由**

创建 `ais/internal/api/handlers_geofences.go`：
```go
package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"

	"ais/internal/fence"
	"ais/internal/model"
	"ais/internal/store"
)

type fenceRequest struct {
	Name              string           `json:"name"`
	Area              geojson.Geometry `json:"area"`
	Enabled           *bool            `json:"enabled"`
	EnterAlert        *bool            `json:"enter_alert"`
	LeaveAlert        *bool            `json:"leave_alert"`
	DebounceCount     int              `json:"debounce_count"`
	SilenceTimeoutMin int              `json:"silence_timeout_min"`
}

func validatePolygon(g geojson.Geometry) error {
	poly, ok := g.Geometry().(orb.Polygon)
	if !ok {
		return errors.New("area must be a GeoJSON Polygon")
	}
	if len(poly) == 0 || len(poly[0]) < 4 {
		return errors.New("polygon needs at least 4 points")
	}
	first, last := poly[0][0], poly[0][len(poly[0])-1]
	if first[0] != last[0] || first[1] != last[1] {
		return errors.New("polygon ring must be closed")
	}
	return nil
}

func (s *Server) handleListGeofences(w http.ResponseWriter, r *http.Request) {
	items, err := s.Geofences.List(r.Context())
	if err != nil {
		s.Log.Error("geofences list failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if items == nil {
		items = []model.Geofence{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (s *Server) handleGetGeofence(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	g, err := s.Geofences.Get(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence get failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, g)
}

func (s *Server) handleCreateGeofence(w http.ResponseWriter, r *http.Request) {
	var req fenceRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid json body")
		return
	}
	if req.Name == "" {
		writeErr(w, http.StatusBadRequest, "name is required")
		return
	}
	if err := validatePolygon(req.Area); err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	g := model.Geofence{
		Name:              req.Name,
		Area:              req.Area,
		Enabled:           true,
		EnterAlert:        true,
		LeaveAlert:        true,
		DebounceCount:     2,
		SilenceTimeoutMin: 5,
	}
	if req.Enabled != nil {
		g.Enabled = *req.Enabled
	}
	if req.EnterAlert != nil {
		g.EnterAlert = *req.EnterAlert
	}
	if req.LeaveAlert != nil {
		g.LeaveAlert = *req.LeaveAlert
	}
	if req.DebounceCount > 0 {
		g.DebounceCount = req.DebounceCount
	}
	if req.SilenceTimeoutMin > 0 {
		g.SilenceTimeoutMin = req.SilenceTimeoutMin
	}
	created, err := s.Geofences.Create(r.Context(), g)
	if err != nil {
		s.Log.Error("geofence create failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusCreated, created)
}

func (s *Server) handleUpdateGeofence(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	var req fenceRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid json body")
		return
	}
	existing, err := s.Geofences.Get(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence get failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if req.Name != "" {
		existing.Name = req.Name
	}
	if req.Area.Geometry() != nil {
		if err := validatePolygon(req.Area); err != nil {
			writeErr(w, http.StatusBadRequest, err.Error())
			return
		}
		existing.Area = req.Area
	}
	if req.Enabled != nil {
		existing.Enabled = *req.Enabled
	}
	if req.EnterAlert != nil {
		existing.EnterAlert = *req.EnterAlert
	}
	if req.LeaveAlert != nil {
		existing.LeaveAlert = *req.LeaveAlert
	}
	if req.DebounceCount > 0 {
		existing.DebounceCount = req.DebounceCount
	}
	if req.SilenceTimeoutMin > 0 {
		existing.SilenceTimeoutMin = req.SilenceTimeoutMin
	}
	updated, err := s.Geofences.Update(r.Context(), existing)
	if err != nil {
		s.Log.Error("geofence update failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, updated)
}

func (s *Server) handleDeleteGeofence(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	err = s.Geofences.Delete(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence delete failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "deleted"})
}

func (s *Server) handleFenceCurrent(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	g, err := s.Geofences.Get(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence get failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	poly, ok := g.Area.Geometry().(orb.Polygon)
	if !ok {
		writeErr(w, http.StatusInternalServerError, "geofence area is not a polygon")
		return
	}
	latest, err := s.Latest.AllLatest(r.Context())
	if err != nil {
		s.Log.Error("latest failed for fence current", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	items := []model.Position{}
	for _, p := range latest {
		if fence.PointInPolygon(orb.Point{p.Lon, p.Lat}, poly) {
			items = append(items, p)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (s *Server) handleFenceHistory(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	start, end, ok := parseTimeRange(w, r)
	if !ok {
		return
	}
	mmsis, err := s.Positions.FenceHistoryVessels(r.Context(), id, start, end)
	if err != nil {
		s.Log.Error("fence history failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if mmsis == nil {
		mmsis = []uint32{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": mmsis})
}

func (s *Server) handleFenceEvents(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	start, end, ok := parseTimeRange(w, r)
	if !ok {
		return
	}
	limit := 1000
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 5000 {
			limit = n
		}
	}
	items, err := s.Geofences.Events(r.Context(), id, start, end, limit)
	if err != nil {
		s.Log.Error("fence events failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if items == nil {
		items = []model.FenceEvent{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func parseTimeRange(w http.ResponseWriter, r *http.Request) (time.Time, time.Time, bool) {
	start, err := time.Parse(time.RFC3339, r.URL.Query().Get("start"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "start must be RFC3339")
		return time.Time{}, time.Time{}, false
	}
	end, err := time.Parse(time.RFC3339, r.URL.Query().Get("end"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "end must be RFC3339")
		return time.Time{}, time.Time{}, false
	}
	if !end.After(start) {
		writeErr(w, http.StatusBadRequest, "end must be after start")
		return time.Time{}, time.Time{}, false
	}
	if end.Sub(start) > 31*24*time.Hour {
		writeErr(w, http.StatusBadRequest, "range limited to 31 days")
		return time.Time{}, time.Time{}, false
	}
	return start, end, true
}
```

在 `ais/internal/api/server.go` 的 `Handler()` 中，`mux.Handle("GET /api/v1/base-stations", ...)` 之后追加：
```go
	mux.Handle("GET /api/v1/geofences", s.auth(s.handleListGeofences))
	mux.Handle("POST /api/v1/geofences", s.auth(s.handleCreateGeofence))
	mux.Handle("GET /api/v1/geofences/{id}", s.auth(s.handleGetGeofence))
	mux.Handle("PUT /api/v1/geofences/{id}", s.auth(s.handleUpdateGeofence))
	mux.Handle("DELETE /api/v1/geofences/{id}", s.auth(s.handleDeleteGeofence))
	mux.Handle("GET /api/v1/geofences/{id}/vessels/current", s.auth(s.handleFenceCurrent))
	mux.Handle("GET /api/v1/geofences/{id}/vessels/history", s.auth(s.handleFenceHistory))
	mux.Handle("GET /api/v1/geofences/{id}/events", s.auth(s.handleFenceEvents))
```
并把 `api.PositionRepo` 接口追加方法：
```go
	FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error)
```
（Task 9 的 `fakePositions` 需要同步补该方法，见 Step 7。）

- [ ] **Step 7: 写围栏 handlers 测试并补齐 fake**

创建 `ais/internal/api/handlers_geofences_test.go`：
```go
package api

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"

	"ais/internal/model"
	"ais/internal/store"
)

// 补充 fakePositions 的 FenceHistoryVessels 实现（Task 9 的 fake 缺该方法）。
func (f *fakePositions) FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error) {
	return []uint32{111, 222}, f.err
}

type fakeGeofences struct {
	items []model.Geofence
	get   model.Geofence
	err   error
}

func (f *fakeGeofences) List(ctx context.Context) ([]model.Geofence, error) {
	return f.items, f.err
}
func (f *fakeGeofences) ListEnabled(ctx context.Context) ([]model.Geofence, error) {
	return f.items, f.err
}
func (f *fakeGeofences) Get(ctx context.Context, id int64) (model.Geofence, error) {
	if f.err != nil {
		return model.Geofence{}, f.err
	}
	if f.get.ID == 0 {
		return model.Geofence{}, store.ErrNotFound
	}
	return f.get, nil
}
func (f *fakeGeofences) Create(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	g.ID = 1
	return g, nil
}
func (f *fakeGeofences) Update(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	return g, nil
}
func (f *fakeGeofences) Delete(ctx context.Context, id int64) error {
	return nil
}
func (f *fakeGeofences) Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error) {
	return []model.FenceEvent{{ID: 1, FenceID: fenceID, MMSI: 111, EventType: model.EventTypeEnter, Ts: time.Now()}}, nil
}

func testFence() model.Geofence {
	return model.Geofence{
		ID:   9,
		Name: "港区",
		Area: geojson.Geometry{Coordinates: orb.Polygon{orb.Ring{
			{113.8, 22.4}, {114.0, 22.4}, {114.0, 22.6}, {113.8, 22.6}, {113.8, 22.4},
		}}},
		Enabled: true, EnterAlert: true, LeaveAlert: true,
		DebounceCount: 2, SilenceTimeoutMin: 5,
	}
}

func TestCreateGeofence_valid(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	body := `{"name":"港区","area":{"type":"Polygon","coordinates":[[[113.8,22.4],[114.0,22.4],[114.0,22.6],[113.8,22.6],[113.8,22.4]]]}}`
	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/api/v1/geofences", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("create status = %d, want 201", resp.StatusCode)
	}
	var g model.Geofence
	if err := json.NewDecoder(resp.Body).Decode(&g); err != nil {
		t.Fatal(err)
	}
	if g.ID != 1 || g.Name != "港区" || !g.Enabled {
		t.Errorf("created = %+v, want id 1, enabled", g)
	}
}

func TestCreateGeofence_invalidPolygon(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	// 未闭合多边形
	body := `{"name":"bad","area":{"type":"Polygon","coordinates":[[[0,0],[1,0],[1,1]]]}}`
	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/api/v1/geofences", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("invalid polygon status = %d, want 400", resp.StatusCode)
	}
}

func TestFenceCurrent_vesselsInside(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{get: testFence()},
		Latest: &fakeLatest{items: []model.Position{
			{MMSI: 1, Lat: 22.5, Lon: 113.9, Ts: time.Now()}, // 内部
			{MMSI: 2, Lat: 30.0, Lon: 120.0, Ts: time.Now()}, // 外部
		}},
		Log: testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	status, m := getJSON(t, ts.URL+"/api/v1/geofences/9/vessels/current", token)
	if status != http.StatusOK {
		t.Fatalf("fence current status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Fatalf("fence current items = %v, want 1 vessel inside", m["items"])
	}
}

func TestFenceHistory(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Positions: &fakePositions{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	status, m := getJSON(t, ts.URL+"/api/v1/geofences/9/vessels/history?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", token)
	if status != http.StatusOK {
		t.Fatalf("fence history status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 2 {
		t.Errorf("fence history items = %v, want 2 mmsi", m["items"])
	}
}

func TestFenceEvents(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	status, m := getJSON(t, ts.URL+"/api/v1/geofences/9/events?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", token)
	if status != http.StatusOK {
		t.Fatalf("fence events status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Errorf("fence events items = %v, want 1 event", m["items"])
	}
}
```

- [ ] **Step 8: 运行全部 api/fence 测试**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/fence/...
go test ./internal/api/...
```
Expected: 全部 PASS。若 `handlers_test.go` 中的 `fakePositions` 因新增 `FenceHistoryVessels` 编译报错，在 Task 9 的 `fakePositions` 上补该方法（与 Step 7 相同实现）。

- [ ] **Step 9: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 11: 围栏状态机（进出判断、去抖、静默超时、事件落库与推送）

**Files:**
- Create: `ais/internal/fence/engine.go`
- Create: `ais/internal/fence/engine_test.go`

**Interfaces:**
- Consumes: `model.Geofence/FenceEvent/Position`（Task 2）、`fence.PointInPolygon`（Task 10）、`store.GeofenceStore.ListEnabled/InsertEvent`（Task 10）。
- Produces:
  - `fence.Options{ReloadInterval time.Duration; SilenceTimeout time.Duration; DebounceCount int}`
  - `fence.GeofenceLister` 接口：`ListEnabled(ctx) ([]model.Geofence, error)`
  - `fence.EventSink` 接口：`InsertEvent(ctx, model.FenceEvent) error`
  - `fence.FenceCache` 接口：`FenceAdd/FenceRemove/ClearFence(ctx, fenceID, mmsi)`、`PublishFenceEvent(ctx, model.FenceEvent) error`
  - `fence.NewEngine(repo GeofenceLister, cacheClient FenceCache, sink EventSink, opts Options, log *slog.Logger) *Engine`
  - `(*Engine).Run(ctx)`；`(*Engine).Reload(ctx) error`；`(*Engine).OnPosition(ctx, p model.Position)`；`(*Engine).SetNow(func() time.Time)`（测试用时钟）
- 行为约定：进入判定需连续 `debounceCount` 条位置在围栏内才触发"进入"事件（去抖）；围栏内船舶静默超过 `silenceTimeout`（默认 5 分钟）判定离开；每次 Reload 时新增围栏清空对应 Redis 集合（防脏状态）；删除围栏时清空集合与内存状态。事件同时：落库（sink）、发布 pub/sub（cache）、更新 Redis 集合（FenceAdd/FenceRemove）。

- [ ] **Step 1: 写失败测试**

创建 `ais/internal/fence/engine_test.go`：
```go
package fence

import (
	"context"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"

	"ais/internal/model"
)

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func squareFence(id int64) model.Geofence {
	return model.Geofence{
		ID:                id,
		Name:              "square",
		Area:              geojson.Geometry{Coordinates: orb.Polygon{orb.Ring{{0, 0}, {10, 0}, {10, 10}, {0, 10}, {0, 0}}}},
		Enabled:           true,
		EnterAlert:        true,
		LeaveAlert:        true,
		DebounceCount:     2,
		SilenceTimeoutMin: 5,
	}
}

func insidePos(mmsi uint32) model.Position {
	return model.Position{MMSI: mmsi, Lat: 5, Lon: 5, Ts: time.Now()}
}

func outsidePos(mmsi uint32) model.Position {
	return model.Position{MMSI: mmsi, Lat: 50, Lon: 50, Ts: time.Now()}
}

type fakeLister struct {
	items []model.Geofence
	err   error
}

func (f *fakeLister) ListEnabled(ctx context.Context) ([]model.Geofence, error) {
	return f.items, f.err
}

type fakeSink struct {
	mu     sync.Mutex
	events []model.FenceEvent
}

func (f *fakeSink) InsertEvent(ctx context.Context, e model.FenceEvent) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.events = append(f.events, e)
	return nil
}

func (f *fakeSink) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.events)
}

type fakeFenceCache struct {
	mu        sync.Mutex
	sets      map[int64]map[uint32]bool
	published []model.FenceEvent
	cleared   map[int64]bool
}

func newFakeCache() *fakeFenceCache {
	return &fakeFenceCache{sets: map[int64]map[uint32]bool{}, cleared: map[int64]bool{}}
}

func (f *fakeFenceCache) FenceAdd(_ context.Context, fenceID int64, mmsi uint32) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.sets[fenceID] == nil {
		f.sets[fenceID] = map[uint32]bool{}
	}
	f.sets[fenceID][mmsi] = true
	return nil
}
func (f *fakeFenceCache) FenceRemove(_ context.Context, fenceID int64, mmsi uint32) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.sets[fenceID], mmsi)
	return nil
}
func (f *fakeFenceCache) FenceMembers(_ context.Context, fenceID int64) ([]uint32, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []uint32
	for m := range f.sets[fenceID] {
		out = append(out, m)
	}
	return out, nil
}
func (f *fakeFenceCache) ClearFence(_ context.Context, fenceID int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.cleared[fenceID] = true
	delete(f.sets, fenceID)
	return nil
}
func (f *fakeFenceCache) PublishFenceEvent(_ context.Context, e model.FenceEvent) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.published = append(f.published, e)
	return nil
}
func (f *fakeFenceCache) inSet(fenceID int64, mmsi uint32) bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.sets[fenceID][mmsi]
}
func (f *fakeFenceCache) publishCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.published)
}

func newEngine(t *testing.T, lister GeofenceLister, cache FenceCache, sink EventSink) *Engine {
	t.Helper()
	return NewEngine(lister, cache, sink, Options{
		ReloadInterval: time.Hour, SilenceTimeout: 5 * time.Minute, DebounceCount: 2,
	}, discardLogger())
}

func TestEngine_enterAfterDebounce(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	if err := e.Reload(ctx); err != nil {
		t.Fatal(err)
	}

	e.OnPosition(ctx, insidePos(100))
	if sink.count() != 0 {
		t.Fatal("first inside point must not emit enter (debounce)")
	}
	e.OnPosition(ctx, insidePos(100))
	if sink.count() != 1 {
		t.Fatalf("sink events = %d, want 1 enter", sink.count())
	}
	if cache.publishCount() != 1 {
		t.Fatalf("published = %d, want 1", cache.publishCount())
	}
	if !cache.inSet(1, 100) {
		t.Error("vessel 100 should be in fence 1 set after enter")
	}
	// 重复的围栏内点不再产生事件
	e.OnPosition(ctx, insidePos(100))
	if sink.count() != 1 {
		t.Errorf("sink events = %d, want still 1", sink.count())
	}
}

func TestEngine_leave(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	_ = e.Reload(ctx)

	e.OnPosition(ctx, insidePos(100))
	e.OnPosition(ctx, insidePos(100)) // enter
	e.OnPosition(ctx, outsidePos(100))
	if sink.count() != 2 {
		t.Fatalf("sink events = %d, want 2 (enter+leave)", sink.count())
	}
	if cache.inSet(1, 100) {
		t.Error("vessel 100 should be removed from fence 1 set after leave")
	}
}

func TestEngine_silenceTimeout(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	_ = e.Reload(ctx)

	now := time.Date(2026, 8, 7, 10, 0, 0, 0, time.UTC)
	e.SetNow(func() time.Time { return now })
	e.OnPosition(ctx, insidePos(100))
	now = now.Add(time.Minute)
	e.OnPosition(ctx, insidePos(100)) // enter
	if sink.count() != 1 {
		t.Fatalf("sink events = %d, want 1 enter", sink.count())
	}
	now = now.Add(10 * time.Minute) // 超过 5 分钟静默
	e.checkSilence(ctx)
	if sink.count() != 2 {
		t.Fatalf("sink events = %d, want 2 after silence leave", sink.count())
	}
	if e.state[1][100].inside {
		t.Error("vessel should be marked outside after silence leave")
	}
	if cache.inSet(1, 100) {
		t.Error("vessel should be removed from fence set after silence leave")
	}
}

func TestEngine_reloadRemovedFenceClearsState(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	_ = e.Reload(ctx)

	e.OnPosition(ctx, insidePos(100))
	e.OnPosition(ctx, insidePos(100)) // enter

	lister.items = nil // 围栏被删除
	if err := e.Reload(ctx); err != nil {
		t.Fatal(err)
	}
	if !cache.cleared[1] {
		t.Error("fence 1 set should be cleared when fence removed")
	}
	if _, ok := e.fences[1]; ok {
		t.Error("fence 1 should be removed from engine state")
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/fence/...
```
Expected: FAIL（`engine.go` 不存在）。

- [ ] **Step 3: 实现 engine**

创建 `ais/internal/fence/engine.go`：
```go
package fence

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/paulmach/orb"

	"ais/internal/model"
)

type GeofenceLister interface {
	ListEnabled(ctx context.Context) ([]model.Geofence, error)
}

type EventSink interface {
	InsertEvent(ctx context.Context, e model.FenceEvent) error
}

type FenceCache interface {
	FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error
	ClearFence(ctx context.Context, fenceID int64) error
	PublishFenceEvent(ctx context.Context, e model.FenceEvent) error
}

type Options struct {
	ReloadInterval time.Duration
	SilenceTimeout time.Duration
	DebounceCount  int
}

type loadedFence struct {
	id             int64
	poly           orb.Polygon
	enterAlert     bool
	leaveAlert     bool
	debounceCount  int
	silenceTimeout time.Duration
}

type vesselState struct {
	inside   bool
	countIn  int
	lastSeen time.Time
	lastLat  float64
	lastLon  float64
}

type Engine struct {
	repo  GeofenceLister
	cache FenceCache
	sink  EventSink
	opts  Options
	log   *slog.Logger
	now   func() time.Time

	mu     sync.RWMutex
	fences map[int64]*loadedFence
	state  map[int64]map[uint32]*vesselState
}

func NewEngine(repo GeofenceLister, cacheClient FenceCache, sink EventSink, opts Options, log *slog.Logger) *Engine {
	if opts.ReloadInterval <= 0 {
		opts.ReloadInterval = time.Minute
	}
	if opts.SilenceTimeout <= 0 {
		opts.SilenceTimeout = 5 * time.Minute
	}
	if opts.DebounceCount <= 0 {
		opts.DebounceCount = 2
	}
	return &Engine{
		repo: repo, cache: cacheClient, sink: sink, opts: opts, log: log,
		now:    time.Now,
		fences: map[int64]*loadedFence{},
		state:  map[int64]map[uint32]*vesselState{},
	}
}

func (e *Engine) SetNow(f func() time.Time) { e.now = f }

func (e *Engine) Run(ctx context.Context) {
	reloadTicker := time.NewTicker(e.opts.ReloadInterval)
	defer reloadTicker.Stop()
	silenceTicker := time.NewTicker(30 * time.Second)
	defer silenceTicker.Stop()
	if err := e.Reload(ctx); err != nil {
		e.log.Error("fence reload failed", "err", err)
	}
	for {
		select {
		case <-ctx.Done():
			return
		case <-reloadTicker.C:
			if err := e.Reload(ctx); err != nil {
				e.log.Error("fence reload failed", "err", err)
			}
		case <-silenceTicker.C:
			e.checkSilence(ctx)
		}
	}
}

func (e *Engine) Reload(ctx context.Context) error {
	enabled, err := e.repo.ListEnabled(ctx)
	if err != nil {
		return err
	}
	next := map[int64]*loadedFence{}
	for _, g := range enabled {
		poly, ok := g.Area.Geometry().(orb.Polygon)
		if !ok {
			continue
		}
		debounce := g.DebounceCount
		if debounce <= 0 {
			debounce = e.opts.DebounceCount
		}
		silence := time.Duration(g.SilenceTimeoutMin) * time.Minute
		if silence <= 0 {
			silence = e.opts.SilenceTimeout
		}
		next[g.ID] = &loadedFence{
			id: g.ID, poly: poly,
			enterAlert: g.EnterAlert, leaveAlert: g.LeaveAlert,
			debounceCount: debounce, silenceTimeout: silence,
		}
	}
	e.mu.Lock()
	for id, f := range next {
		if _, ok := e.fences[id]; !ok {
			// 新围栏：清空旧集合，防止脏成员导致状态错乱
			if err := e.cache.ClearFence(ctx, id); err != nil {
				e.log.Warn("clear fence set failed", "fence_id", id, "err", err)
			}
		}
		e.fences[id] = f
	}
	for id := range e.fences {
		if _, ok := next[id]; !ok {
			delete(e.fences, id)
			delete(e.state, id)
			if err := e.cache.ClearFence(ctx, id); err != nil {
				e.log.Warn("clear removed fence set failed", "fence_id", id, "err", err)
			}
		}
	}
	e.mu.Unlock()
	return nil
}

func (e *Engine) OnPosition(ctx context.Context, p model.Position) {
	e.mu.RLock()
	defer e.mu.RUnlock()
	pt := orb.Point{p.Lon, p.Lat}
	for id, f := range e.fences {
		st := e.stateFor(id, p.MMSI)
		inside := PointInPolygon(pt, f.poly)
		if inside {
			st.lastLat, st.lastLon = p.Lat, p.Lon
			if !st.inside {
				st.countIn++
				if st.countIn >= f.debounceCount {
					st.inside = true
					st.countIn = 0
					st.lastSeen = e.now()
					e.emit(ctx, f, p, model.EventTypeEnter)
				}
			} else {
				st.lastSeen = e.now()
			}
		} else if st.inside {
			st.inside = false
			st.countIn = 0
			e.emit(ctx, f, p, model.EventTypeLeave)
		}
	}
}

func (e *Engine) checkSilence(ctx context.Context) {
	e.mu.Lock()
	defer e.mu.Unlock()
	now := e.now()
	for id, m := range e.state {
		f := e.fences[id]
		if f == nil {
			continue
		}
		for mmsi, st := range m {
			if st.inside && now.Sub(st.lastSeen) > f.silenceTimeout {
				st.inside = false
				st.countIn = 0
				p := model.Position{MMSI: mmsi, Lat: st.lastLat, Lon: st.lastLon}
				e.emit(ctx, f, p, model.EventTypeLeave)
			}
		}
	}
}

func (e *Engine) stateFor(fenceID int64, mmsi uint32) *vesselState {
	m := e.state[fenceID]
	if m == nil {
		m = map[uint32]*vesselState{}
		e.state[fenceID] = m
	}
	s := m[mmsi]
	if s == nil {
		s = &vesselState{}
		m[mmsi] = s
	}
	return s
}

func (e *Engine) emit(ctx context.Context, f *loadedFence, p model.Position, eventType int16) {
	if eventType == model.EventTypeEnter && !f.enterAlert {
		return
	}
	if eventType == model.EventTypeLeave && !f.leaveAlert {
		return
	}
	ev := model.FenceEvent{
		FenceID: f.id, MMSI: p.MMSI, EventType: eventType,
		Ts: e.now(), Lat: p.Lat, Lon: p.Lon,
	}
	if err := e.sink.InsertEvent(ctx, ev); err != nil {
		e.log.Error("insert fence event failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
	}
	if err := e.cache.PublishFenceEvent(ctx, ev); err != nil {
		e.log.Error("publish fence event failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
	}
	switch eventType {
	case model.EventTypeEnter:
		if err := e.cache.FenceAdd(ctx, f.id, p.MMSI); err != nil {
			e.log.Error("fence add failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
		}
	case model.EventTypeLeave:
		if err := e.cache.FenceRemove(ctx, f.id, p.MMSI); err != nil {
			e.log.Error("fence remove failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
		}
	}
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/fence/...
```
Expected: PASS（4 个 geo 测试 + 4 个 engine 测试）。

- [ ] **Step 5: 本地验收**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
---

### Task 12: 指标、数据管道与主程序组装

**Files:**
- Create: `ais/internal/metrics/metrics.go`
- Create: `ais/internal/pipeline/pipeline.go`
- Create: `ais/internal/pipeline/pipeline_test.go`
- Create: `ais/cmd/ais/main.go`

**Interfaces:**
- Consumes: `nmea.Parser`（Task 2）、`dedup.Dedup`（Task 3）、`station.Handler`（Task 4）、`pg.Writer`（Task 6）、`cache.Cache`（Task 7）、`wshub.Hub`（Task 8）、`fence.Engine`（Task 11）、`store.VesselStore`（Task 9）。
- Produces:
  - `metrics` 包：`MsgsParsed`、`ParseErrors`、`Deduped`（`promauto.Counter`）、`FenceEvents`（`CounterVec`，label `type`）、`WSConnections`（`Gauge`）、`FlushFailures`（`Counter`）
  - `pipeline.New(opts PipelineOptions, log *slog.Logger) *Pipeline`；`PipelineOptions{Writer Writer; Latest LatestSetter; Publisher PositionPublisher; VesselUpserter; Engine PositionConsumer; Dedup *dedup.Dedup}`
  - `pipeline.Pipeline` 实现 `station.Handler`：`OnLine(stationID, line string)`、`OnStatus(stationID string, connected bool, err error)`
  - `cmd/ais/main.go`：子命令 `run` / `user-create` / `maintenance`
- 管道行为约定（OnLine）：每基站一个 `nmea.Parser`（多句重组状态隔离）→ 解析失败计 `ParseErrors` 并继续 → 位置消息构造去重 key（`mmsi:秒级时间戳:原始语句FNV哈希`）→ 重复计 `Deduped` 并丢弃 → 否则依次 `Writer.Enqueue`、`Latest.SetLatest`、`Publisher.PublishPosition`、`Engine.OnPosition`，计 `MsgsParsed`；静态消息走 `VesselUpserter.Upsert`。WebSocket 广播由主程序订阅 Redis pub/sub 后调用 `Hub.Broadcast`（保证多实例时单一扇出源）。

- [ ] **Step 1: 写失败测试（pipeline）**

创建 `ais/internal/pipeline/pipeline_test.go`：
```go
package pipeline

import (
	"context"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"ais/internal/dedup"
	"ais/internal/model"
)

const (
	sentenceType1  = "!AIVDM,1,1,,B,177KQJ5000G?tO`K>RA1wUbN0TKH,0*5C"
	sentenceType5A = "!AIVDM,2,1,6,B,53Jmvl82Bw3CTP7??K5<D5<lThF222222222221:I0oK;4e20L3FH42i,0*5C"
	sentenceType5B = "!AIVDM,2,2,6,B,p88888888888880,2*69"
)

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

type fakeWriter struct {
	mu    sync.Mutex
	items []model.Position
	err   error
}

func (f *fakeWriter) Enqueue(p model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.err != nil {
		return f.err
	}
	f.items = append(f.items, p)
	return nil
}

func (f *fakeWriter) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

type fakeLatest struct {
	mu    sync.Mutex
	items []model.Position
}

func (f *fakeLatest) SetLatest(_ context.Context, p model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, p)
	return nil
}

type fakePublisher struct {
	mu    sync.Mutex
	items []model.Position
}

func (f *fakePublisher) PublishPosition(_ context.Context, p model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, p)
	return nil
}

func (f *fakePublisher) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

type fakeEngine struct {
	mu    sync.Mutex
	items []model.Position
}

func (f *fakeEngine) OnPosition(_ context.Context, p model.Position) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, p)
}

func (f *fakeEngine) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

type fakeVessels struct {
	mu    sync.Mutex
	items []model.Vessel
}

func (f *fakeVessels) Upsert(_ context.Context, v model.Vessel) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, v)
	return nil
}

func (f *fakeVessels) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

func newTestPipeline() (*Pipeline, *fakeWriter, *fakePublisher, *fakeEngine, *fakeVessels) {
	w := &fakeWriter{}
	pub := &fakePublisher{}
	eng := &fakeEngine{}
	ves := &fakeVessels{}
	pipe := New(PipelineOptions{
		Writer:      w,
		Latest:      &fakeLatest{},
		Publisher:   pub,
		Engine:      eng,
		VesselStore: ves,
		Dedup:       dedup.New(30*time.Second, 100000),
	}, discardLogger())
	return pipe, w, pub, eng, ves
}

func TestPipeline_positionMessageFansOut(t *testing.T) {
	pipe, w, pub, eng, _ := newTestPipeline()
	pipe.OnLine("st1", sentenceType1)
	if w.count() != 1 {
		t.Errorf("writer received %d, want 1", w.count())
	}
	if pub.count() != 1 {
		t.Errorf("publisher received %d, want 1", pub.count())
	}
	if eng.count() != 1 {
		t.Errorf("engine received %d, want 1", eng.count())
	}
	w.mu.Lock()
	got := w.items[0]
	w.mu.Unlock()
	if got.MMSI != 477553000 {
		t.Errorf("MMSI = %d, want 477553000", got.MMSI)
	}
}

func TestPipeline_duplicateDropped(t *testing.T) {
	pipe, w, _, _, _ := newTestPipeline()
	pipe.OnLine("st1", sentenceType1)
	pipe.OnLine("st1", sentenceType1)
	if w.count() != 1 {
		t.Errorf("writer received %d, want 1 (duplicate dropped)", w.count())
	}
}

func TestPipeline_vesselMessageUpserts(t *testing.T) {
	pipe, w, _, _, ves := newTestPipeline()
	pipe.OnLine("st1", sentenceType5A)
	pipe.OnLine("st1", sentenceType5B)
	if w.count() != 0 {
		t.Errorf("writer received %d, want 0 (static message)", w.count())
	}
	if ves.count() != 1 {
		t.Errorf("vessel upserts = %d, want 1", ves.count())
	}
}
```

- [ ] **Step 2: 运行测试确认失败**

```powershell
cd E:\Codes\dev\ais
go test ./internal/pipeline/...
```
Expected: FAIL（`pipeline.go` 不存在）。

- [ ] **Step 3: 实现 metrics 与 pipeline**

创建 `ais/internal/metrics/metrics.go`：
```go
// Package metrics registers Prometheus metrics used by the whole service.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	MsgsParsed = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_messages_parsed_total",
		Help: "Total AIS messages decoded into positions.",
	})
	ParseErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_messages_parse_errors_total",
		Help: "Total NMEA sentences that failed to parse.",
	})
	Deduped = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_messages_deduped_total",
		Help: "Total duplicate messages dropped by the dedup window.",
	})
	FenceEvents = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "ais_fence_events_total",
		Help: "Fence events emitted, by type.",
	}, []string{"type"})
	WSConnections = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "ais_ws_connections",
		Help: "Current number of connected WebSocket clients.",
	})
	FlushFailures = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_writer_flush_failures_total",
		Help: "Total batches dropped after failed retry in the position writer.",
	})
)
```

创建 `ais/internal/pipeline/pipeline.go`：
```go
// Package pipeline wires a station NMEA line into the dedup / persistence /
// snapshot / broadcast / geofence stages.
package pipeline

import (
	"context"
	"fmt"
	"hash/fnv"
	"log/slog"
	"sync"
	"time"

	"ais/internal/dedup"
	"ais/internal/metrics"
	"ais/internal/model"
	"ais/internal/nmea"
)

type Writer interface {
	Enqueue(p model.Position) error
}

type LatestSetter interface {
	SetLatest(ctx context.Context, p model.Position) error
}

type PositionPublisher interface {
	PublishPosition(ctx context.Context, p model.Position) error
}

type PositionConsumer interface {
	OnPosition(ctx context.Context, p model.Position)
}

type VesselUpserter interface {
	Upsert(ctx context.Context, v model.Vessel) error
}

type PipelineOptions struct {
	Writer      Writer
	Latest      LatestSetter
	Publisher   PositionPublisher
	Engine      PositionConsumer
	VesselStore VesselUpserter
	Dedup       *dedup.Dedup
}

type Pipeline struct {
	mu      sync.Mutex
	parsers map[string]*nmea.Parser
	opts    PipelineOptions
	log     *slog.Logger
}

func New(opts PipelineOptions, log *slog.Logger) *Pipeline {
	return &Pipeline{parsers: map[string]*nmea.Parser{}, opts: opts, log: log}
}

// OnLine implements station.Handler.
func (p *Pipeline) OnLine(stationID, line string) {
	p.mu.Lock()
	parser := p.parsers[stationID]
	if parser == nil {
		parser = nmea.NewParser()
		p.parsers[stationID] = parser
	}
	p.mu.Unlock()

	now := time.Now()
	res, err := parser.Parse(line, stationID, now)
	if err != nil {
		metrics.ParseErrors.Inc()
		p.log.Warn("nmea parse failed", "station", stationID, "err", err)
		return
	}
	if res == nil {
		return
	}
	ctx := context.Background()
	if res.Position != nil {
		if p.opts.Dedup.CheckAndAdd(positionKey(*res.Position, line), now) {
			metrics.Deduped.Inc()
			return
		}
		metrics.MsgsParsed.Inc()
		pos := *res.Position
		if err := p.opts.Writer.Enqueue(pos); err != nil {
			p.log.Warn("enqueue position failed", "mmsi", pos.MMSI, "err", err)
		}
		_ = p.opts.Latest.SetLatest(ctx, pos)
		_ = p.opts.Publisher.PublishPosition(ctx, pos)
		p.opts.Engine.OnPosition(ctx, pos)
	}
	if res.Vessel != nil {
		if err := p.opts.VesselStore.Upsert(ctx, *res.Vessel); err != nil {
			p.log.Warn("vessel upsert failed", "mmsi", res.Vessel.MMSI, "err", err)
		}
	}
}

// OnStatus implements station.Handler.
func (p *Pipeline) OnStatus(stationID string, connected bool, err error) {
	if connected {
		p.log.Info("station connected", "station", stationID)
	} else {
		p.log.Warn("station disconnected", "station", stationID, "err", err)
	}
}

func positionKey(p model.Position, raw string) string {
	h := fnv.New32a()
	_, _ = h.Write([]byte(raw))
	return fmt.Sprintf("%d:%d:%x", p.MMSI, p.Ts.Unix(), h.Sum32())
}
```

- [ ] **Step 4: 运行测试确认通过**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go test ./internal/pipeline/...
```
Expected: PASS（3 个测试）。

- [ ] **Step 5: 本地验收（pipeline 部分）**

```powershell
cd E:\Codes\dev\ais
go build ./...
go vet ./...
```
Expected: 无输出，exit code 0。
- [ ] **Step 6: 实现 main（子命令 run / user-create / maintenance）**

创建 `ais/cmd/ais/main.go`：
```go
// Command ais is the AIS gateway + API binary.
//
// Subcommands:
//
//	ais run           启动 gateway + api（默认）
//	ais user-create -username admin -password x [-role admin]
//	ais maintenance    手动执行分区与事件清理
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"golang.org/x/crypto/bcrypt"

	"ais/internal/api"
	"ais/internal/cache"
	"ais/internal/config"
	"ais/internal/dedup"
	"ais/internal/fence"
	"ais/internal/logging"
	"ais/internal/metrics"
	"ais/internal/model"
	"ais/internal/pipeline"
	"ais/internal/station"
	"ais/internal/store/pg"
	"ais/internal/wshub"
)

func main() {
	sub := "run"
	if len(os.Args) > 1 {
		sub = os.Args[1]
	}
	var err error
	switch sub {
	case "run":
		err = runServer()
	case "user-create":
		err = runUserCreate()
	case "maintenance":
		err = runMaintenance()
	default:
		err = fmt.Errorf("unknown subcommand %q (expected run, user-create, maintenance)", sub)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "fatal:", err)
		os.Exit(1)
	}
}

func loadConfig() (config.Config, *slog.Logger, error) {
	cfg, err := config.Load()
	if err != nil {
		return cfg, nil, err
	}
	return cfg, logging.New(cfg.LogLevel), nil
}

func runServer() error {
	cfg, log, err := loadConfig()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	pool, err := pg.Connect(ctx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect postgres: %w", err)
	}
	defer pool.Close()
	if err := pg.Migrate(ctx, pool); err != nil {
		return fmt.Errorf("migrate: %w", err)
	}

	positions := pg.NewPositions(pool)
	geofences := pg.NewGeofences(pool)
	vessels := pg.NewVessels(pool)
	users := pg.NewUsers(pool)

	writer := pg.NewWriter(positions, pg.WriterOptions{
		FlushInterval: cfg.WriterFlushInterval,
		BatchSize:     cfg.WriterBatchSize,
		QueueSize:     cfg.WriterQueueSize,
	}, log)
	go writer.Run(ctx)

	redisClient := cache.New(cfg.RedisAddr, cfg.RedisPassword)
	if err := redisClient.Ping(ctx); err != nil {
		return fmt.Errorf("connect redis: %w", err)
	}
	defer redisClient.Close()

	posHub := wshub.NewHub()
	eventHub := wshub.NewHub()
	go posHub.Run(ctx)
	go eventHub.Run(ctx)

	engine := fence.NewEngine(geofences, redisClient, geofences, fence.Options{
		ReloadInterval: cfg.FenceReloadInterval,
		SilenceTimeout: cfg.FenceSilenceTimeout,
		DebounceCount:  cfg.FenceDebounceCount,
	}, log)
	go engine.Run(ctx)

	pipe := pipeline.New(pipeline.PipelineOptions{
		Writer:      writer,
		Latest:      redisClient,
		Publisher:   redisClient,
		Engine:      engine,
		VesselStore: vessels,
		Dedup:       dedup.New(30*time.Second, 1_000_000),
	}, log)
	mgr := station.NewManager(stationConfigs(cfg.Stations), pipe, station.Options{
		ConnectTimeout: cfg.StationConnectTimeout,
		ReconnectBase:  cfg.StationReconnectBase,
		ReconnectMax:   cfg.StationReconnectMax,
		IdleTimeout:    cfg.StationIdleTimeout,
		ReadBufSize:    65536,
	}, log)
	go mgr.Run(ctx)

	// 订阅 Redis pub/sub → 本地 WebSocket 扇出（多实例时各实例消费同一频道）
	posCh, posErr := redisClient.SubscribePositions(ctx)
	eventCh, eventErr := redisClient.SubscribeFenceEvents(ctx)
	go func() {
		for {
			select {
			case p, ok := <-posCh:
				if !ok {
					return
				}
				posHub.Broadcast(envelope("position", p))
			case err := <-posErr:
				log.Error("position subscription ended", "err", err)
				return
			case <-ctx.Done():
				return
			}
		}
	}()
	go func() {
		for {
			select {
			case e, ok := <-eventCh:
				if !ok {
					return
				}
				metrics.FenceEvents.WithLabelValues(eventTypeLabel(e.EventType)).Inc()
				eventHub.Broadcast(envelope("fence_event", e))
			case err := <-eventErr:
				log.Error("fence event subscription ended", "err", err)
				return
			case <-ctx.Done():
				return
			}
		}
	}()

	// WS 连接数指标
	go func() {
		ticker := time.NewTicker(10 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				metrics.WSConnections.Set(float64(posHub.Connections() + eventHub.Connections()))
			case <-ctx.Done():
				return
			}
		}
	}()

	// 分区维护（自愈：每小时确保分区存在 + 每日清理超期分区与事件）
	go runMaintenanceLoop(ctx, pool, cfg, log)

	srv := &api.Server{
		Cfg:        api.ServerConfig{JWTSecret: cfg.JWTSecret, JWTTTL: cfg.JWTTTL},
		Positions:  positions,
		Latest:     redisClient,
		Vessels:    vessels,
		Users:      users,
		Geofences:  geofences,
		PosHub:     posHub,
		EventHub:   eventHub,
		StationMgr: mgr,
		Log:        log,
	}
	httpServer := &http.Server{
		Addr:              cfg.HTTPAddr,
		Handler:           srv.Handler(),
		ReadHeaderTimeout: 10 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() { errCh <- httpServer.ListenAndServe() }()
	log.Info("ais server started", "addr", cfg.HTTPAddr)

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		log.Info("shutting down")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		return httpServer.Shutdown(shutdownCtx)
	}
}

func stationConfigs(cfgs []config.Station) []station.Config {
	out := make([]station.Config, 0, len(cfgs))
	for _, c := range cfgs {
		out = append(out, station.Config{ID: c.ID, Name: c.Name, Host: c.Host, Port: c.Port, Enabled: c.Enabled})
	}
	return out
}

func envelope(kind string, data any) []byte {
	b, err := json.Marshal(map[string]any{"type": kind, "data": data})
	if err != nil {
		return nil
	}
	return b
}

func eventTypeLabel(t int16) string {
	if t == model.EventTypeLeave {
		return "leave"
	}
	return "enter"
}

func runUserCreate() error {
	fs := flag.NewFlagSet("user-create", flag.ExitOnError)
	username := fs.String("username", "", "login name")
	password := fs.String("password", "", "password")
	role := fs.String("role", "user", "role (user/admin)")
	_ = fs.Parse(os.Args[2:])
	if *username == "" || *password == "" {
		return errors.New("--username and --password are required")
	}
	cfg, log, err := loadConfig()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	pool, err := pg.Connect(ctx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect postgres: %w", err)
	}
	defer pool.Close()
	hash, err := bcrypt.GenerateFromPassword([]byte(*password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	u, err := pg.NewUsers(pool).Create(ctx, *username, string(hash), *role)
	if err != nil {
		return fmt.Errorf("create user: %w", err)
	}
	log.Info("user created", "id", u.ID, "username", u.Username, "role", u.Role)
	return nil
}

func runMaintenance() error {
	cfg, log, err := loadConfig()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	pool, err := pg.Connect(ctx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect postgres: %w", err)
	}
	defer pool.Close()
	now := time.Now().UTC()
	if err := pg.EnsurePartitions(ctx, pool, now, now.Add(48*time.Hour)); err != nil {
		return fmt.Errorf("ensure partitions: %w", err)
	}
	before := now.AddDate(0, 0, -cfg.RetentionDays)
	dropped, err := pg.DropPartitionsBefore(ctx, pool, before)
	if err != nil {
		return fmt.Errorf("drop partitions: %w", err)
	}
	deleted, err := pg.NewGeofences(pool).DeleteEventsBefore(ctx, before)
	if err != nil {
		return fmt.Errorf("delete events: %w", err)
	}
	log.Info("maintenance done", "dropped_partitions", len(dropped), "deleted_events", deleted)
	return nil
}

func runMaintenanceLoop(ctx context.Context, pool *pgxpool.Pool, cfg config.Config, log *slog.Logger) {
	ticker := time.NewTicker(6 * time.Hour)
	defer ticker.Stop()
	run := func() {
		now := time.Now().UTC()
		if err := pg.EnsurePartitions(ctx, pool, now, now.Add(48*time.Hour)); err != nil {
			log.Error("ensure partitions failed", "err", err)
			return
		}
		dropped, err := pg.DropPartitionsBefore(ctx, pool, now.AddDate(0, 0, -cfg.RetentionDays))
		if err != nil {
			log.Error("drop partitions failed", "err", err)
			return
		}
		if len(dropped) > 0 {
			log.Info("dropped stale partitions", "names", dropped)
		}
		if _, err := pg.NewGeofences(pool).DeleteEventsBefore(ctx, now.AddDate(0, 0, -cfg.RetentionDays)); err != nil {
			log.Error("clean events failed", "err", err)
		}
	}
	run()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			run()
		}
	}
}
```

- [ ] **Step 7: 编译与单元测试**

```powershell
cd E:\Codes\dev\ais
go mod tidy
go build ./...
go vet ./...
go test ./...
```
Expected: 全部 PASS，无编译错误。

- [ ] **Step 8: 冒烟验证（本地 Docker 已就绪时）**

```powershell
cd E:\Codes\dev\ais
# 1) 建管理员
$env:AIS_DB_URL = "postgres://ais:ais@localhost:5432/ais?sslmode=disable"
go run ./cmd/ais user-create -username admin -password admin123 -role admin

# 2) 启动服务（另开终端）
$env:AIS_REDIS_ADDR = "localhost:6379"
$env:AIS_JWT_SECRET = "dev-secret-change-me"
go run ./cmd/ais run

# 3) 健康检查 + 登录 + 建围栏
curl http://localhost:8080/api/v1/healthz
curl -X POST http://localhost:8080/api/v1/auth/login -d '{"username":"admin","password":"admin123"}'
```
Expected: healthz 返回 `{"status":"ok"}`；login 返回含 `token` 的 JSON。

- [ ] **Step 9: 端到端数据流验证（可选）**

在另一个终端用 PowerShell 起一个模拟基站，向 `AIS_STATIONS` 配置的端口持续发送测试语句：
```powershell
# 模拟基站：监听 4010 端口，每秒发送 2 条真实语句
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 4010)
$listener.Start()
while ($true) {
  $client = $listener.AcceptTcpClient()
  $stream = $client.GetStream()
  $writer = [System.IO.StreamWriter]::new($stream)
  while ($true) {
    $writer.WriteLine("!AIVDM,1,1,,B,177KQJ5000G?tO`K>RA1wUbN0TKH,0*5C")
    $writer.Flush()
    Start-Sleep -Milliseconds 500
  }
}
```
然后以 `AIS_STATIONS=[{"id":"sim","name":"sim","host":"127.0.0.1","port":4010,"enabled":true}]` 启动 `go run ./cmd/ais run`，验证：
- `GET /api/v1/positions/latest`（带 token）返回包含 mmsi=477553000 的条目；
- PostgreSQL 中 `SELECT count(*) FROM ais_positions WHERE mmsi=477553000` 持续增长（1 秒/批次 flush）。

---

### Task 13: 容器化部署（Docker Compose / Nginx / 监控 / 备份 / README）

**Files:**
- Create: `ais/Dockerfile`
- Create: `ais/README.md`
- Create: `ais/deployment/docker-compose.yml`
- Create: `ais/deployment/nginx/default.conf`
- Create: `ais/deployment/prometheus/prometheus.yml`
- Create: `ais/deployment/grafana/provisioning/datasources/prometheus.yml`
- Create: `ais/deployment/grafana/provisioning/dashboards/dashboards.yaml`
- Create: `ais/deployment/grafana/provisioning/dashboards/ais.json`
- Create: `ais/deployment/backup/Dockerfile`
- Create: `ais/deployment/backup/backup.sh`

**Interfaces:**
- Consumes: Task 1 的 `ais/.env.example` 环境变量约定；`cmd/ais` 的 `run` / `user-create` / `maintenance` 子命令；应用暴露路由 `GET /api/v1/healthz`、`GET /api/v1/*`、`GET /ws/positions`、`GET /ws/fence-events`、`GET /metrics`。
- Produces:
  - `Dockerfile`：多阶段构建（golang:1.22-alpine 编译 → alpine 最小运行镜像，非 root）。
  - `deployment/docker-compose.yml`：postgis / redis / ais / nginx / prometheus / grafana / backup 七个服务；仅 nginx 对外暴露 80/443，prometheus 与 grafana 仅绑定 127.0.0.1。
  - `deployment/nginx/default.conf`：TLS 终止 + REST/WS 反向代理 + `/ui/` 占位页。
  - `deployment/prometheus/prometheus.yml`：抓取 `ais:8080/metrics`。
  - `deployment/grafana/provisioning/`：自动导入 Prometheus 数据源与 AIS 监控大盘。
  - `deployment/backup/`：定时 `pg_basebackup`（`-Ft -z`）→ 阿里云 OSS，按 `BACKUP_KEEP_DAYS` 保留。
  - `README.md`：本地开发、Docker 部署、阿里云上线与运维手册。

> 说明：本任务无 Go 代码，验收命令为 `docker compose config -q`（语法校验）与 `docker compose up -d --build`（端到端）。本机未装 Docker 时先安装 Docker Desktop（Windows）或 Docker Engine（Linux）；无法运行 Docker 的机器可只做 `config -q` 校验并人工走查。

- [ ] **Step 1: 创建应用 Dockerfile**

创建 `ais/Dockerfile`：
```dockerfile
# syntax=docker/dockerfile:1
# ---- 构建阶段 ----
FROM golang:1.22-alpine AS build
WORKDIR /src
COPY go.mod go.sum ./
RUN go mod download
COPY cmd/ internal/ ./
RUN CGO_ENABLED=0 GOOS=linux go build -trimpath -ldflags="-s -w" -o /out/ais ./cmd/ais

# ---- 运行阶段：最小 alpine 镜像，非 root ----
FROM alpine:3.20
RUN apk add --no-cache ca-certificates tzdata
COPY --from=build /out/ais /usr/local/bin/ais
EXPOSE 8080
USER nobody
ENTRYPOINT ["/usr/local/bin/ais"]
CMD ["run"]
```

说明：应用不写本地文件（配置来自环境变量、迁移 SQL 内嵌于二进制），运行阶段只需 ca-certificates 与 tzdata；以 `nobody` 用户运行降低容器逃逸风险。

- [ ] **Step 2: 创建 docker-compose.yml**

先准备环境文件（若不存在）：
```powershell
cd E:\Codes\dev\ais
Copy-Item .env.example .env   # 至少修改 AIS_JWT_SECRET / AIS_STATIONS / OSS_* 等
```

创建 `ais/deployment/docker-compose.yml`：
```yaml
# AIS 后端一键编排（目标：阿里云 ECS 4C8G / 400G 数据盘）
# 使用：docker compose up -d --build
# 约定：
#   - ${VAR:-default} 插值读取本目录 deployment/.env（可留空不创建，全部使用默认值）
#   - 应用级配置来自 ../.env（由 env_file 注入容器，JSON 值无需转义）
#   - 除 nginx(80/443) 与 prometheus/grafana(仅 127.0.0.1) 外，所有服务不对外暴露端口
services:
  postgis:
    image: postgis/postgis:16-3.4
    container_name: ais-postgis
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-ais}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-ais}
      POSTGRES_DB: ${POSTGRES_DB:-ais}
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-ais} -d ${POSTGRES_DB:-ais}"]
      interval: 10s
      timeout: 5s
      retries: 10
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    container_name: ais-redis
    command: ["sh", "-c", "exec redis-server --appendonly yes --requirepass \"$$AIS_REDIS_PASSWORD\""]
    environment:
      AIS_REDIS_PASSWORD: ${AIS_REDIS_PASSWORD:-}
    volumes:
      - redisdata:/data
    healthcheck:
      test: ["CMD-SHELL", "redis-cli -a \"$$AIS_REDIS_PASSWORD\" ping | grep -q PONG"]
      interval: 10s
      timeout: 3s
      retries: 10
    restart: unless-stopped

  ais:
    build:
      context: ..
      dockerfile: Dockerfile
    container_name: ais
    env_file: ../.env
    environment:
      AIS_HTTP_ADDR: 0.0.0.0:8080
      AIS_DB_URL: postgres://${POSTGRES_USER:-ais}:${POSTGRES_PASSWORD:-ais}@postgis:5432/${POSTGRES_DB:-ais}?sslmode=disable
      AIS_REDIS_ADDR: redis:6379
    depends_on:
      postgis:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "wget", "-q", "-O", "/dev/null", "http://127.0.0.1:8080/api/v1/healthz"]
      interval: 15s
      timeout: 5s
      retries: 10
      start_period: 20s
    restart: unless-stopped

  nginx:
    image: nginx:1.27-alpine
    container_name: ais-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/default.conf:/etc/nginx/conf.d/default.conf:ro
      - ./nginx/certs:/etc/nginx/certs:ro
    depends_on:
      ais:
        condition: service_healthy
    restart: unless-stopped

  prometheus:
    image: prom/prometheus:v2.53.0
    container_name: ais-prometheus
    command:
      - --config.file=/etc/prometheus/prometheus.yml
      - --storage.tsdb.path=/prometheus
      - --storage.tsdb.retention.time=15d
    volumes:
      - ./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - promdata:/prometheus
    ports:
      - "127.0.0.1:9090:9090"
    depends_on:
      ais:
        condition: service_healthy
    restart: unless-stopped

  grafana:
    image: grafana/grafana:11.1.0
    container_name: ais-grafana
    environment:
      GF_SECURITY_ADMIN_USER: admin
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_ADMIN_PASSWORD:-admin}
      GF_USERS_ALLOW_SIGN_UP: "false"
    volumes:
      - ./grafana/provisioning:/etc/grafana/provisioning:ro
      - grafanadata:/var/lib/grafana
    ports:
      - "127.0.0.1:3000:3000"
    depends_on:
      prometheus:
        condition: service_started
    restart: unless-stopped

  backup:
    build: ./backup
    container_name: ais-backup
    env_file: ../.env
    environment:
      PGHOST: postgis
      PGPORT: "5432"
      PGUSER: ${POSTGRES_USER:-ais}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-ais}
      BACKUP_DIR: /backup/data
      BACKUP_KEEP_DAYS: "7"
      BACKUP_INTERVAL_HOURS: "24"
    volumes:
      - backupdata:/backup/data
    depends_on:
      postgis:
        condition: service_healthy
    restart: unless-stopped

volumes:
  pgdata:
  redisdata:
  promdata:
  grafanadata:
  backupdata:
```

注意：
- `AIS_STATIONS` 等含 JSON 的配置写在 `ais/.env`，经 `env_file` 原样注入容器。
- 修改数据库口令：在 `deployment/.env` 设置 `POSTGRES_PASSWORD`，postgis 与 ais 的 DB URL 读取同一插值。
- 生产必须设置强 `AIS_JWT_SECRET`、`AIS_REDIS_PASSWORD`，并修改 Grafana 默认口令。

- [ ] **Step 3: 创建 Nginx 配置与证书**

创建证书目录并生成自签名证书（测试用；生产替换为 CA 签发证书，如阿里云数字证书服务）：
```powershell
cd E:\Codes\dev\ais\deployment
New-Item -ItemType Directory -Force nginx\certs | Out-Null
openssl req -x509 -newkey rsa:2048 -nodes -keyout nginx\certs\server.key -out nginx\certs\server.crt -days 365 -subj "/CN=ais.local"
```

创建 `ais/deployment/nginx/default.conf`：
```nginx
# AIS 反向代理：TLS 终止 + REST/WS 转发
# 证书：deployment/nginx/certs/server.crt / server.key

upstream ais_backend {
    server ais:8080;
    keepalive 32;
}

# HTTP → HTTPS 跳转
server {
    listen 80;
    server_name _;
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    http2 on;
    server_name _;

    ssl_certificate     /etc/nginx/certs/server.crt;
    ssl_certificate_key /etc/nginx/certs/server.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;

    client_max_body_size 2m;

    # REST API
    location /api/ {
        proxy_pass http://ais_backend;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # 指标仅允许本机访问（Prometheus 走 compose 内网直连 ais:8080）
    location = /metrics {
        allow 127.0.0.1;
        deny all;
        proxy_pass http://ais_backend;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
    }

    # WebSocket 实时推送（前端连接 wss://<host>/ws/positions?token=...）
    location /ws/ {
        proxy_pass http://ais_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    # 前端占位页（前端子任务完成后替换为静态目录挂载）
    location /ui/ {
        default_type text/html;
        charset utf-8;
        return 200 '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>AIS 平台</title></head><body style="font-family:sans-serif;padding:2rem"><h1>AIS 实时监控平台</h1><p>前端为独立子任务，此处为占位页。</p><p>健康检查：<code>/api/v1/healthz</code></p></body></html>';
    }

    location / {
        return 404;
    }
}
```

- [ ] **Step 4: 创建 Prometheus 配置**

创建 `ais/deployment/prometheus/prometheus.yml`：
```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: ais
    metrics_path: /metrics
    static_configs:
      - targets: ["ais:8080"]
        labels:
          instance: "ais-gateway"
```

- [ ] **Step 5: 创建 Grafana 数据源与大盘**

创建 `ais/deployment/grafana/provisioning/datasources/prometheus.yml`：
```yaml
apiVersion: 1

datasources:
  - name: Prometheus
    uid: prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: false
```

创建 `ais/deployment/grafana/provisioning/dashboards/dashboards.yaml`（大盘 provider，让 Grafana 自动加载下面的大盘 JSON）：
```yaml
apiVersion: 1

providers:
  - name: "AIS"
    orgId: 1
    folder: "AIS"
    type: file
    disableDeletion: false
    updateIntervalSeconds: 30
    allowUiUpdates: true
    options:
      path: /etc/grafana/provisioning/dashboards
```

创建 `ais/deployment/grafana/provisioning/dashboards/ais.json`（uid 与数据源 uid 对应）：
```json
{
  "annotations": { "list": [] },
  "editable": true,
  "graphTooltip": 1,
  "refresh": "10s",
  "schemaVersion": 39,
  "tags": ["ais"],
  "templating": { "list": [] },
  "time": { "from": "now-6h", "to": "now" },
  "timezone": "browser",
  "title": "AIS 服务监控",
  "uid": "ais-overview",
  "version": 1,
  "panels": [
    {
      "id": 1,
      "type": "timeseries",
      "title": "消息解析速率（条/s）",
      "datasource": { "type": "prometheus", "uid": "prometheus" },
      "gridPos": { "h": 8, "w": 12, "x": 0, "y": 0 },
      "targets": [
        { "refId": "A", "expr": "rate(ais_messages_parsed_total[5m])", "legendFormat": "解析" }
      ],
      "fieldConfig": { "defaults": { "unit": "short" }, "overrides": [] }
    },
    {
      "id": 2,
      "type": "timeseries",
      "title": "解析错误（条/s）",
      "datasource": { "type": "prometheus", "uid": "prometheus" },
      "gridPos": { "h": 8, "w": 12, "x": 12, "y": 0 },
      "targets": [
        { "refId": "A", "expr": "rate(ais_messages_parse_errors_total[5m])", "legendFormat": "错误" }
      ],
      "fieldConfig": { "defaults": { "unit": "short" }, "overrides": [] }
    },
    {
      "id": 3,
      "type": "timeseries",
      "title": "去重消息（条/s）",
      "datasource": { "type": "prometheus", "uid": "prometheus" },
      "gridPos": { "h": 8, "w": 12, "x": 0, "y": 8 },
      "targets": [
        { "refId": "A", "expr": "rate(ais_messages_deduped_total[5m])", "legendFormat": "去重" }
      ],
      "fieldConfig": { "defaults": { "unit": "short" }, "overrides": [] }
    },
    {
      "id": 4,
      "type": "timeseries",
      "title": "围栏事件（条/s）",
      "datasource": { "type": "prometheus", "uid": "prometheus" },
      "gridPos": { "h": 8, "w": 12, "x": 12, "y": 8 },
      "targets": [
        { "refId": "A", "expr": "sum by (type) (rate(ais_fence_events_total[5m]))", "legendFormat": "{{type}}" }
      ],
      "fieldConfig": { "defaults": { "unit": "short" }, "overrides": [] }
    },
    {
      "id": 5,
      "type": "timeseries",
      "title": "WebSocket 连接数",
      "datasource": { "type": "prometheus", "uid": "prometheus" },
      "gridPos": { "h": 8, "w": 12, "x": 0, "y": 16 },
      "targets": [
        { "refId": "A", "expr": "ais_ws_connections", "legendFormat": "连接数" }
      ],
      "fieldConfig": { "defaults": { "unit": "short" }, "overrides": [] }
    },
    {
      "id": 6,
      "type": "timeseries",
      "title": "批量写入失败（累计）",
      "datasource": { "type": "prometheus", "uid": "prometheus" },
      "gridPos": { "h": 8, "w": 12, "x": 12, "y": 16 },
      "targets": [
        { "refId": "A", "expr": "ais_writer_flush_failures_total", "legendFormat": "失败" }
      ],
      "fieldConfig": { "defaults": { "unit": "short" }, "overrides": [] }
    }
  ]
}
```

- [ ] **Step 6: 创建备份服务（pg_basebackup → OSS）**

创建 `ais/deployment/backup/Dockerfile`：
```dockerfile
# 备份容器：每日 pg_basebackup（物理备份）→ 上传阿里云 OSS
FROM alpine:3.20

# postgresql16-client 提供 pg_basebackup；curl/unzip 用于安装 ossutil
RUN apk add --no-cache postgresql16-client curl unzip

ARG OSSUTIL_VERSION=1.7.16
RUN curl -fsSL -o /tmp/ossutil.zip \
        "https://gosspublic.alicdn.com/ossutil/${OSSUTIL_VERSION}/ossutil-v${OSSUTIL_VERSION}-linux-amd64.zip" \
    && unzip -q /tmp/ossutil.zip -d /opt/ossutil \
    && ln -s "/opt/ossutil/ossutil-v${OSSUTIL_VERSION}-linux-amd64/ossutil64" /usr/local/bin/ossutil \
    && rm -f /tmp/ossutil.zip

COPY backup.sh /backup/backup.sh
RUN chmod +x /backup/backup.sh

ENTRYPOINT ["/bin/sh", "/backup/backup.sh"]
```

> 若 ossutil 官方下载地址失效，到阿里云 OSS 文档（https://help.aliyun.com/zh/oss/developer-reference/install-ossutil）获取最新地址并替换 `OSSUTIL_VERSION` / URL。

创建 `ais/deployment/backup/backup.sh`：
```sh
#!/bin/sh
# AIS 数据库备份：pg_basebackup（物理备份，tar+压缩）→ 本地保留 + 上传阿里云 OSS
# 由 compose 的 backup 服务常驻运行，BACKUP_INTERVAL_HOURS 控制间隔。
set -eu

: "${PGHOST:=postgis}"
: "${PGPORT:=5432}"
: "${PGUSER:=ais}"
: "${POSTGRES_PASSWORD:=ais}"
: "${BACKUP_DIR:=/backup/data}"
: "${BACKUP_KEEP_DAYS:=7}"
: "${BACKUP_INTERVAL_HOURS:=24}"

export PGPASSWORD="${POSTGRES_PASSWORD}"

run_backup() {
    ts="$(date -u +%Y%m%dT%H%M%SZ)"
    dest="${BACKUP_DIR}/${ts}"
    mkdir -p "${dest}"

    echo "[backup] start pg_basebackup -> ${dest}"
    pg_basebackup -h "${PGHOST}" -p "${PGPORT}" -U "${PGUSER}" \
        -D "${dest}" -Ft -z -P

    if [ -n "${OSS_BUCKET:-}" ] && [ -n "${OSS_ENDPOINT:-}" ]; then
        echo "[backup] upload to oss://${OSS_BUCKET}/ais-backup/${ts}/"
        for f in "${dest}"/*.tar.gz; do
            [ -e "$f" ] || continue
            ossutil -e "${OSS_ENDPOINT}" -i "${OSS_ACCESS_KEY_ID}" -k "${OSS_ACCESS_KEY_SECRET}" \
                cp "$f" "oss://${OSS_BUCKET}/ais-backup/${ts}/$(basename "$f")" --force >/dev/null
        done
        rm -rf "${dest}"
        echo "[backup] uploaded and removed local copy"
    else
        echo "[backup] OSS not configured, keep local copy"
    fi

    # 清理本地超过 BACKUP_KEEP_DAYS 的备份
    find "${BACKUP_DIR}" -mindepth 1 -maxdepth 1 -mtime "+${BACKUP_KEEP_DAYS}" -exec rm -rf {} +
    echo "[backup] done"
}

echo "[backup] container started, interval=${BACKUP_INTERVAL_HOURS}h"
while :; do
    run_backup || echo "[backup] run failed, will retry next interval"
    sleep "$((BACKUP_INTERVAL_HOURS * 3600))"
done
```

说明：
- `pg_basebackup -Ft -z` 在备份目录生成 `base.tar.gz`（含全部表空间）与可选的 `pg_wal.tar.gz`；恢复时解压回数据目录即可。
- OSS 侧清理推荐用 OSS 生命周期规则：对 `ais-backup/` 前缀设置“删除 N 天前对象”（N = 30 天，与业务保留期一致）。
- 如需定期 WAL 归档（PITR），后续可在此基础上增加 `pg_receivewal` 常驻进程；当前 1 个月轨迹规模每日全量物理备份足够。

- [ ] **Step 7: 编写 README**

创建 `ais/README.md`：

```markdown
# AIS 实时接入与轨迹查询系统

单一 Go 二进制同时承担基站接入网关（NMEA 解析 → 去重 → 落库 / Redis 快照 / WS 推送 / 围栏状态机）与 REST / WebSocket API。PostgreSQL(+PostGIS) 为唯一数据库（轨迹按天分区、保留 1 个月），Redis 承担最新船位快照、围栏船舶集合与 pub/sub 扇出，Nginx 提供 TLS/WSS 反向代理，Prometheus + Grafana 监控，每日物理备份到阿里云 OSS。

┌──────────┐   NMEA/TCP    ┌───────────────────────────────┐
│ 基站 1..N │ ───────────▶ │  ais (Go 单二进制, :8080)      │
└──────────┘              │  gateway: 解析/去重/状态机/写入  │
                          │  api: REST + WS + JWT           │
                          └──────┬─────────┬─────────┬──────┘
                                 │         │         │
                        ┌────────▼──┐ ┌────▼────┐ ┌──▼───────────┐
                        │ PostgreSQL │ │ Redis   │ │ WS 客户端    │
                        │ (+PostGIS) │ │ 快照/pub │ │ (前端地图)   │
                        └────────────┘ └─────────┘ └──────────────┘
Nginx(:443 TLS/WSS) ──▶ ais；Prometheus ◀─ ais/metrics；Grafana ◀─ Prometheus

## 目录结构

    ais/
      cmd/ais/main.go            # 子命令: run / user-create / maintenance
      internal/                  # config/logging/model/nmea/dedup/station/
                                 # store(pg)/cache/wshub/api/fence/pipeline/metrics
      deployment/                # docker-compose / nginx / prometheus / grafana / backup
      Dockerfile  README.md  .env.example

## 本地开发

依赖：Go 1.22+、PostgreSQL 16（含 PostGIS）、Redis 7。

    cd ais
    cp .env.example .env          # 修改 AIS_JWT_SECRET、AIS_STATIONS 等
    go mod tidy
    go build ./... && go vet ./... && go test ./...

    # 建管理员并启动（另开终端）
    go run ./cmd/ais user-create -username admin -password <密码> -role admin
    go run ./cmd/ais run

健康检查：`curl http://localhost:8080/api/v1/healthz`；登录：`POST /api/v1/auth/login`。

## Docker 部署

    cd ais/deployment
    docker compose config -q      # 语法校验
    docker compose up -d --build  # 启动全部服务
    docker compose ps             # 等待 health
    docker compose logs -f ais    # 查看应用日志

- 对外入口：`https://<域名或IP>/api/v1/healthz`、`wss://<域名或IP>/ws/positions?token=...`、`/ui/` 占位页。
- 内部管理：Grafana `http://127.0.0.1:3000`（admin/部署时设置的密码）、Prometheus `http://127.0.0.1:9090`。
- 建管理员 / 手动维护：`docker compose exec ais ais user-create -username admin -password <密码> -role admin`、`docker compose exec ais ais maintenance`。

## 配置（环境变量，前缀 AIS_）

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| AIS_HTTP_ADDR | 0.0.0.0:8080 | HTTP/WS 监听地址 |
| AIS_DB_URL | postgres://ais:ais@localhost:5432/ais?sslmode=disable | PostgreSQL 连接串 |
| AIS_REDIS_ADDR / AIS_REDIS_PASSWORD | localhost:6379 / 空 | Redis 地址与口令 |
| AIS_JWT_SECRET / AIS_JWT_TTL | dev-secret-change-me / 24h | JWT 密钥与有效期 |
| AIS_STATIONS | [] | 基站 JSON 数组：[{"id","name","host","port","enabled"}] |
| AIS_WRITER_* | 1s / 1000 / 100000 | 批量写入间隔/批大小/队列上限 |
| AIS_RETENTION_DAYS | 30 | 轨迹与围栏事件保留天数 |
| AIS_FENCE_* | 60s / 5m / 2 | 围栏重载间隔/静默超时/去抖计数 |
| AIS_STATION_* | 10s / 1s / 60s / 5m | 基站连接超时/重连退避/空闲超时 |
| OSS_* | 空 | 阿里云 OSS 备份（endpoint/bucket/ak/sk） |

## API 摘要

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /api/v1/healthz | 健康检查（无鉴权） |
| POST | /api/v1/auth/login | 登录获取 JWT |
| GET | /api/v1/positions/latest | 最新船位（Redis 快照，失败回退 DB） |
| GET | /api/v1/vessels/{mmsi}/track | 单船历史轨迹 |
| GET | /api/v1/vessels | 船舶列表（分页/搜索） |
| GET | /api/v1/base-stations | 基站在线状态 |
| GET/POST/PUT/DELETE | /api/v1/geofences[/{id}] | 电子围栏 CRUD |
| GET | /api/v1/geofences/{id}/vessels/current | 围栏内当前船舶 |
| GET | /api/v1/geofences/{id}/vessels/history | 围栏历史船舶 |
| GET | /api/v1/geofences/{id}/events | 围栏进出事件 |
| WS | /ws/positions、/ws/fence-events | 实时推送（?token= 鉴权） |
| GET | /metrics | Prometheus 指标 |

## 监控

- 大盘：Grafana 登录后可见自动导入的 “AIS 服务监控” 大盘（解析速率、解析错误、去重、围栏事件、WS 连接数、写入失败）。
- 常用告警项（可接入阿里云 ARMS / Prometheus Alertmanager）：
  - `rate(ais_messages_parse_errors_total[5m]) > 0`：解析异常持续存在；
  - `ais_ws_connections == 0`：无前端连接（长时告警）；
  - `ais_writer_flush_failures_total` 增长：落库失败，检查 PostgreSQL。

## 备份与恢复

备份：`backup` 容器每 24h 执行 `pg_basebackup -Ft -z` 并上传 `oss://<bucket>/ais-backup/<时间戳>/`，OSS 生命周期规则建议删除 30 天前对象。

恢复（新实例）：

    # 1) 下载 base.tar.gz 解压到新 PostgreSQL 数据目录（属主 postgres，权限 700）
    # 2) 启动 postgis 容器后验证
    docker compose exec postgis psql -U ais -d ais -c "select count(*) from ais_positions;"
    docker compose exec postgis psql -U ais -d ais -c "select count(*) from users;"

## 阿里云上线清单

1. 购买 ECS（4C8G，系统盘 40G SSD + 数据盘 360G），Docker 数据目录（`/var/lib/docker`）挂载到数据盘。
2. 安全组放行：22（管理）、80/443（对外）；3000/9090 仅放行办公网 IP。
3. 安装 Docker Engine + Compose 插件；上传项目到 ECS。
4. `cp .env.example .env` 并修改 `AIS_JWT_SECRET`、`AIS_STATIONS`（真实基站）、`OSS_*`；可选创建 `deployment/.env` 覆盖数据库口令与 Grafana 密码。
5. 放置 CA 证书到 `deployment/nginx/certs/`（阿里云数字证书服务签发）。
6. `docker compose up -d --build`，`docker compose ps` 全部 healthy。
7. 建管理员：`docker compose exec ais ais user-create -username admin -password <强密码> -role admin`。
8. DNS A 记录指向 ECS 公网 IP，验证 `https://<域名>/api/v1/healthz`。
9. OSS 控制台为该 bucket 配置生命周期规则（`ais-backup/` 前缀，删除 30 天前对象）。
10. Grafana 配置告警；接入阿里云云监控（CPU/内存/磁盘/带宽）。

## 扩展路径（B 方案：多客户端 / 更大规模）

当前架构单二进制内聚 gateway+api，已通过 Redis pub/sub 与统一扇出为拆分预留：当用户量或基站数上升时——
- 将 `gateway`（接入/解析/写入）与 `api`（REST/WS）拆为两个进程/两份部署，Nginx 按路径分流；
- api 水平扩容多副本（无状态，依赖 Redis 快照与 PostgreSQL）；
- PostgreSQL 主从只读副本承接轨迹查询；Redis 集群化；
- 接入层增加 kafka/pulsar 解耦（当前 0-100 msg/s 规模不需要）。
```
- [ ] **Step 8: 本地验收（Docker 已就绪时）**

```powershell
cd E:\Codes\dev\ais\deployment
# 1) 语法校验（不需要 Docker daemon）
docker compose config -q

# 2) 准备 .env 与证书
cd E:\Codes\dev\ais
Copy-Item .env.example .env
New-Item -ItemType Directory -Force deployment\nginx\certs | Out-Null
openssl req -x509 -newkey rsa:2048 -nodes -keyout deployment\nginx\certs\server.key -out deployment\nginx\certs\server.crt -days 365 -subj "/CN=ais.local"

# 3) 启动并检查
cd E:\Codes\dev\ais\deployment
docker compose up -d --build
docker compose ps
```
Expected：`config -q` 无输出、exit code 0；`docker compose ps` 中 postgis/redis/ais/nginx 为 healthy，prometheus/grafana/backup 为 running。

```powershell
# 4) 冒烟：应用健康 + 经 nginx 的 HTTPS 健康检查
curl http://127.0.0.1:8080/api/v1/healthz
curl -k https://127.0.0.1/api/v1/healthz
```
Expected：两者均返回 `{"status":"ok"}`。

```powershell
# 5) 建管理员并验证登录（容器内执行，使用容器环境变量）
docker compose exec ais ais user-create -username admin -password admin123 -role admin
docker compose exec ais sh -c 'curl -s -X POST http://127.0.0.1:8080/api/v1/auth/login -d "{\"username\":\"admin\",\"password\":\"admin123\"}"'
```
Expected：user-create 日志输出 `user created`；login 返回含 `token` 的 JSON。

- [ ] **Step 9: 阿里云上线检查**

按 `README.md` 的“阿里云上线清单”逐项执行；重点确认：
- 安全组仅放行 22/80/443（3000/9090 仅办公网 IP）；
- `ais/.env` 中 `AIS_JWT_SECRET` 为强随机串、`AIS_STATIONS` 指向真实基站地址；
- `deployment/nginx/certs/` 为 CA 证书（非自签名）；
- `deployment/.env` 设置了 `POSTGRES_PASSWORD` 与 `GRAFANA_ADMIN_PASSWORD`；
- OSS bucket 已配置 `ais-backup/` 生命周期规则（30 天）；
- `docker compose up -d --build` 后全部服务 healthy，`https://<域名>/api/v1/healthz` 返回 ok。

验收标准：Task 13 完成后，`cd E:\Codes\dev\ais && go build ./... && go vet ./... && go test ./...` 全部通过（回归确认代码未受影响），且 `docker compose config -q` 通过。
