﻿# AIS 实时接入与轨迹查询系统 — 设计文档

- 日期：2026-08-07（修订 3：新增海上电子围栏模块，PostGIS 空间查询 + 进出告警）
- 状态：已评审待确认
- 范围：V1 架构设计（含电子围栏模块，不含代码实现）

## 1. 背景与目标

从自建 AIS 基站接收原始 AIS 数据（NMEA 0183/0184 语句），实时转发给前端展示，同时落库保留 1 个月，并支持单船历史轨迹查询与海上电子围栏（实时范围查询、历史经过查询、进出告警）。

## 2. 需求与约束

| 项 | 约束 |
| --- | --- |
| 数据规模 | 数千艘船，每秒 10~100 条消息（中规模） |
| 数据源 | 自建基站，TCP 长连接持续推送原始 NMEA 语句（VDM/VDQ），支持多客户端连接 |
| 实时性 | 秒级转发至浏览器（WebSocket） |
| 存储 | 单一 PostgreSQL 数据库（含 PostGIS 扩展）；轨迹明细保留 1 个月，自动过期 |
| 查询 | 单船历史轨迹查询（时间范围 + 降采样） |
| 电子围栏 | 实时范围内船舶查询 + 历史经过船舶查询 + 进出告警（实时推送） |
| 在线用户 | 当前几十人（A），预留升级到一两百人（B） |
| 部署 | 阿里云 ECS，一般预算 |
| 技术栈 | 从零选型，不受现有工程约束 |

## 3. 总体架构

```text
自建基站 ×N ──TCP/NMEA(VDM)──▶ ais-gateway (Go)
                                 │
        ┌────────────────────────┼────────────────────────┐
        │ 实时链路                 │ 存储链路(异步批量)         │
        ▼                        ▼                         ▼
  WebSocket 扇出            Redis 最新船位快照          PostgreSQL(+PostGIS)
        │                        │                      │  ·ais_positions 按天分区
        │                        │                      │  ·geofences 围栏多边形
        ▼                        ▼                      │  ·fence_events 进出事件
  前端浏览器(地图)         围栏状态机(进出判断/告警) ────────┘
                                 │
                                 ▼
                        ais-api (Go, REST 轨迹/围栏查询)
              ▲                   │
              └── Nginx(反向代理/TLS/WSS) ──┘
```

### 组件清单

| 组件 | 技术 | 职责 |
| --- | --- | --- |
| ais-gateway | Go | 多基站 TCP 接入、NMEA 解析、去重、WebSocket 实时推送、更新 Redis 快照、围栏状态机（进出判断+告警）、异步批量写 PostgreSQL |
| ais-api | Go | 轨迹/围栏/事件查询 REST、最新船位批量查询、元数据与围栏管理、鉴权 |
| Redis | 阿里云或自建 | `ais:latest` 最新船位哈希；`ais:fence:{fenceId}` 围栏内船舶集合；pub/sub 为多实例扇出预留 |
| PostgreSQL | 单实例 | 唯一数据库：轨迹分区表 + 围栏/事件/元数据表（含 PostGIS 扩展） |
| Nginx | ECS 内 | 反向代理、TLS/WSS 终止、前端静态资源 |

V1 中 gateway 与 api 合并在一个二进制/容器内部署（两个逻辑模块，代码分层隔离），为后续拆分与水平扩展预留。

## 4. 数据流

- 实时链路：基站 → gateway 解析 → WebSocket 全量推送 → 前端按需过滤展示；升级到 B 规模时改为按区域/MMSI 订阅。
- 存储链路：gateway 解析后进入内存批量缓冲（1 秒或 1000 条触发 flush）→ 多行 INSERT 写入 PostgreSQL；写入失败重试，数据库不可用时缓冲并告警。
- 快照链路：每条位置消息更新 Redis `ais:latest`（字段 `mmsi → JSON`），地图初始化时一次性拉取。
- 围栏链路：gateway 围栏状态机对启用中的围栏做点-多边形判断，进出状态变化时发布告警事件（Redis pub/sub + WebSocket 推送 + 落 `fence_events` 表）。

## 5. 组件详细设计

### 5.1 ais-gateway（Go）

- 连接管理：多基站 TCP 客户端，可配置；心跳检测（AIS 语句天然是保活信号），指数退避断线重连，基站状态上报。
- 解析：NMEA 0183 VDM/VDO 多句重组（AIS 长消息跨 2~4 句），支持 type 1/2/3/4/5/9/18/19/21/24 等常用消息；解析失败计入指标并告警，不中断链路。
- 去重：内存窗口去重（按 MMSI+时间戳+语句哈希，约 30 秒窗口），防止基站重复转发与重连回放。
- 转发：进程内 WebSocket hub，全量广播解析后的标准消息；同时向 Redis pub/sub 发布（多实例时其他实例消费后转发）。
- 围栏状态机：加载启用中的围栏多边形到内存；每条位置消息做点-多边形判断（数千船 × 数十围栏，开销可忽略）；用 Redis `ais:fence:{id}` 维护围栏内船舶集合，检测进入/离开；事件去抖（连续 N 条在围栏内才判定进入，默认 N=2，可配置）与静默超时（船舶停止上报超过阈值默认 5 分钟视为离开，可配置）；触发时发布告警并落库。
- 写入：独立 writer goroutine 批量插入 PostgreSQL；缓冲上限与丢弃策略明确（见 §8）。

### 5.2 ais-api（Go）

- REST 接口（见 §7）；JWT 鉴权，元数据放 PostgreSQL。
- 轨迹查询直接查 PostgreSQL 分区表；`bucket` 降采样用 `date_trunc` 聚合实现。
- 最新船位列表从 Redis 读取，兜底查 PostgreSQL。
- 围栏实时查询：对 Redis 最新船位做应用侧点-多边形过滤（数千船 O(n)，V1 足够）；历史查询走 PostGIS SQL。

### 5.3 Redis

- `ais:latest`：哈希，字段 `mmsi`，值 `{lat, lon, sog, cog, heading, ts}`。
- `ais:fence:{fenceId}`：集合，存当前围栏内 mmsi（状态机用，可重建）。
- `ais:positions` / `ais:fence-events`：pub/sub 频道，多实例扇出预留。
- 预估内存：数千船 × ~200B + 围栏集合 ≈ 几 MB，1~4GB 实例绰绰有余。

### 5.4 PostgreSQL（含 PostGIS）

- 唯一数据库，单实例即可支撑 V1 与 B 规模（写入 100 msg/s 批量插入毫无压力）。
- 轨迹明细：按天分区表 + 每分区 `(mmsi, ts)` 索引与 `geom` GIST 空间索引，见 §6.1。
- 围栏与事件：`geofences`（多边形）+ `fence_events`（进出事件），见 §6.2。
- 保留策略：每日例行任务创建次日分区、删除超过 30 天的分区，实现精确"保留 1 个月"。
- 备份：每日 `pg_basebackup` 全量备份至阿里云 OSS。

### 5.5 Nginx

- 反向代理 gateway/api、TLS 终止（wss 需要）、前端静态资源、限流基础防护。

### 5.6 前端（概要）

- Leaflet/OpenLayers 地图 + WebSocket 实时船位与围栏告警；轨迹渲染先客户端抽稀（或直接用服务端 `bucket` 聚合结果）。
- 围栏绘制与管理界面属前端子任务，不做详细设计。

## 6. 数据模型

### 6.1 PostgreSQL：ais_positions（按天分区 + 空间列）

```sql
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE ais_positions (
  mmsi BIGINT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  lat DOUBLE PRECISION NOT NULL,
  lon DOUBLE PRECISION NOT NULL,
  sog REAL,                 -- 对地航速 knots
  cog REAL,                 -- 对地航向 deg
  heading SMALLINT,         -- 船首向 deg
  nav_status SMALLINT,      -- 航行状态枚举
  msg_type SMALLINT,        -- AIS 消息类型
  source TEXT,              -- 基站标识
  geom geometry(Point, 4326) GENERATED ALWAYS AS
    (ST_SetSRID(ST_MakePoint(lon, lat), 4326)) STORED
) PARTITION BY RANGE (ts);

-- 示例：每日分区（由例行任务创建）
CREATE TABLE ais_positions_20260807 PARTITION OF ais_positions
  FOR VALUES FROM ('2026-08-07 00:00:00+00') TO ('2026-08-08 00:00:00+00');

CREATE INDEX idx_pos_20260807_mmsi_ts ON ais_positions_20260807 (mmsi, ts);
CREATE INDEX idx_pos_20260807_geom     ON ais_positions_20260807 USING GIST (geom);
```

- 分区维护：cron 每日执行"创建次日分区 + 删除 30 天前的分区"（或 `pg_partman` 自动管理），实现精确 1 个月保留，无人工删数。
- 查询：单船轨迹走 `(mmsi, ts)` 索引；围栏历史查询走时间裁剪 + `geom` GIST 索引。
- 写入：批量多行 INSERT（每 1 秒或 1000 条一次）。
- 存储估算：上限约 260M 行/月 × ~130B/行（含几何列）+ 双索引 ≈ 40~60GB/月，数据盘 400G 起步按实际增长扩容。
- V1 不存原始 NMEA 语句；回放/审计需求明确后再增加 `ais_raw` 表（同样按天分区 + TTL 策略）。

### 6.2 PostgreSQL：围栏与元数据表（示意）

```sql
CREATE TABLE geofences (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  area geometry(Polygon, 4326) NOT NULL,
  enabled BOOLEAN DEFAULT true,
  enter_alert BOOLEAN DEFAULT true,
  leave_alert BOOLEAN DEFAULT true,
  debounce_count SMALLINT DEFAULT 2,   -- 进入判定连续点数
  silence_timeout_min INT DEFAULT 5,   -- 静默视为离开的分钟数
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX idx_geofences_area ON geofences USING GIST (area);

CREATE TABLE fence_events (
  id BIGSERIAL PRIMARY KEY,
  fence_id BIGINT NOT NULL,
  mmsi BIGINT NOT NULL,
  event_type SMALLINT NOT NULL,        -- 1=进入 2=离开
  ts TIMESTAMPTZ NOT NULL,
  lat DOUBLE PRECISION, lon DOUBLE PRECISION
);
CREATE INDEX idx_fence_events_fence_ts ON fence_events (fence_id, ts);

CREATE TABLE vessels (
  mmsi BIGINT PRIMARY KEY,
  name TEXT, imo BIGINT, callsign TEXT,
  ship_type SMALLINT, length_m REAL, beam_m REAL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT UNIQUE, password_hash TEXT, role TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE base_stations (
  id BIGSERIAL PRIMARY KEY,
  name TEXT, host TEXT, port INT, enabled BOOLEAN DEFAULT true
);
```

- `fence_events` 保留策略：保留 30 天；事件量小无需分区，由例行清理任务按 `ts` 删除超期数据。

## 7. API 设计（V1）

```text
GET  /api/v1/vessels/{mmsi}/track?start=ISO8601&end=ISO8601[&bucket=60][&limit=10000]
GET  /api/v1/positions/latest                  # 全部船最新位置（Redis）

GET  /api/v1/geofences                         # 围栏列表
POST /api/v1/geofences                         # 创建围栏（GeoJSON 多边形）
GET  /api/v1/geofences/{id}/vessels/current    # 当前在围栏内的船（实时，Redis+应用侧过滤）
GET  /api/v1/geofences/{id}/vessels/history?start=&end=  # 历史经过的船（去重列表，PostGIS）
GET  /api/v1/geofences/{id}/events?start=&end=            # 进出事件列表

GET  /api/v1/vessels                           # 船舶元数据列表（支持分页/搜索）
GET  /api/v1/base-stations                     # 基站状态
WS   /ws/positions                             # 实时船位推送（鉴权后订阅）
WS   /ws/fence-events                          # 围栏进出告警实时推送
```

- `bucket`：按秒聚合窗口（如 `bucket=60` 每分钟一组），SQL 用 `date_trunc('second', ts)` 分桶 + `avg(lat)`/`avg(lon)`/`max(sog)`，结果直接用于地图轨迹渲染。
- 不带 `bucket` 返回原始点，`ORDER BY ts LIMIT n` 配合 `(mmsi, ts)` 索引，`limit` 保护超大范围查询。
- 历史围栏查询 SQL 形态：`SELECT DISTINCT mmsi FROM ais_positions WHERE ts BETWEEN ... AND ST_Intersects(geom, <围栏>)`，配合时间裁剪与 GIST 索引。

## 8. 可靠性、监控与运维

- 基站断连：指数退避重连 + 状态告警；多基站互为冗余时优先级配置。
- 解析失败：计指标 + 日志（含基站与原始句），不阻塞链路。
- 写入保护：内存批量缓冲上限（如 10 万条），超过后新消息降级丢弃并告警；重试失败持续告警。
- 围栏状态机：重启后可基于 Redis 集合与 `fence_events` 重建状态；去抖与静默超时参数可调，防止边界抖动误报。
- 分区维护：例行任务失败告警，防止分区堆积或过早删除数据。
- 监控：Prometheus 指标（消息速率、解析失败率、去重率、写延迟、WS 连接数、围栏告警数、分区状态）+ Grafana 看板；日志统一输出，按日轮转。
- 备份：PostgreSQL 每日 `pg_basebackup` 至 OSS，恢复演练定期执行。
- 安全：JWT 鉴权、Nginx TLS、WebSocket 握手校验、敏感信息不落日志。

## 9. 服务器配置与成本估算（阿里云，一般预算）

- 推荐：单台 ECS 4C8G（如 `ecs.c7.xlarge`）+ 系统盘 40G ESSD + 数据盘 400G ESSD；Docker Compose 编排 gateway/api、PostgreSQL（`shared_buffers` 2~4G，含 PostGIS）、Redis、Nginx；公网带宽 5~10Mbps。
- 估算成本：约 500~800 元/月（ECS + 数据盘 + 带宽，不含 OSS 备份小额费用）。
- 替代方案（更稳）：应用 2C4G ECS + 云 RDS PostgreSQL（支持 PostGIS）+ 云 Redis 基础版，托管省心，成本略高。

## 10. 升级路径（几十人 → 一两百人）

- 带宽是首要瓶颈：全量推送 200 人约需 30Mbps+ 公网带宽；升级点：按区域/MMSI 订阅过滤 + 带宽升到 20~50Mbps。
- 应用层：gateway 与 api 拆分为独立进程/容器；gateway 多实例时通过 Redis pub/sub 做跨实例扇出；围栏状态机与 gateway 解耦后可独立扩容。
- 数据层：PostgreSQL 单实例支撑 1 个月数据量无需扩展；确认写放大或空间查询变慢后再考虑读副本（只读流量分离）或分库。

## 11. 风险与开放问题

- 基站实际消息率需上线后验证（假设 10~100 msg/s）。
- 原始 NMEA 语句 V1 不保存，回放/审计需求出现时新增 `ais_raw` 表。
- 基站多客户端连接需要对方提供稳定地址/端口，接入参数待定。
- 前端地图库与交互样式未定，独立子任务。
- 围栏历史查询在 30 天大数据量上的性能需上线后实测（时间裁剪 + GIST 索引，必要时限制查询时间跨度）。
- 进出告警的边界抖动（去抖）与 AIS 静默（无信号判定）策略需结合实际数据调参。
- 可选增强（不改变单库选型）：若未来希望免维护分区/压缩/连续聚合，可把实例升级为 TimescaleDB 扩展（仍是 PostgreSQL 生态）。

## 12. 里程碑（实施顺序概览）

1. 环境与骨架：ECS、Docker Compose、Go 服务骨架、PostgreSQL(+PostGIS)/Redis 初始化
2. 接入与解析：TCP 连接管理 + NMEA 解析 + 去重 + 单测
3. 存储链路：分区表 + 批量写入 + 分区维护任务 + 元数据表
4. 实时链路：WebSocket 推送 + Redis 快照 + Nginx/TLS
5. 查询 API：轨迹查询（含 bucket 降采样）+ 最新船位 + 鉴权
6. 电子围栏模块：围栏 CRUD + 状态机进出判断 + 告警推送 + 实时/历史围栏查询接口
7. 监控与备份：指标、告警、OSS 备份
8. 前端（独立任务）：地图实时船位 + 轨迹渲染 + 围栏绘制与告警
9. 上线验证：压测消息速率、带宽与空间查询实测、调优

---


