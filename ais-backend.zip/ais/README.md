# AIS 实时接入与轨迹查询系统

单一 Go 二进制同时承担基站接入网关（NMEA 解析 → 去重 → 落库 / Redis 快照 / WS 推送 / 围栏状态机）与 REST / WebSocket API。PostgreSQL(+PostGIS) 为唯一数据库（轨迹按天分区、保留 1 个月），Redis 承担最新船位快照、围栏船舶集合与 pub/sub 扇出，Nginx 提供 TLS/WSS 反向代理，Prometheus + Grafana 监控，每日物理备份到阿里云 OSS。

┌──────────┐   NMEA/TCP    ┌───────────────────────────────┐
│ 基站 1..N │ ───────────▶ │  ais (Go 单二进制, :8080)      │
└──────────┘              │  gateway: 解析/去重/状态机/写入  │
                          │  api: REST + WS + JWT           │
                          └──────┬─────────┬─────────┬──────┘
                                 │         │         │
                        ┌────────▼──┐ ┌────▼────┐ ┌──▼───────────┐
                        │ PostgreSQL │ │ Redis   │ │ WS 客户端    │
                        │ (+PostGIS) │ │ 快照/pub │ │ (前端地图)   │
                        └────────────┘ └─────────┘ └──────────────┘
Nginx(:443 TLS/WSS) ──▶ ais；Prometheus ◀─ ais/metrics；Grafana ◀─ Prometheus

## 目录结构

    ais/
      cmd/ais/main.go            # 子命令: run / user-create / maintenance
      internal/                  # config/logging/model/nmea/dedup/station/
                                 # store(pg)/cache/wshub/api/fence/pipeline/metrics
      deployment/                # docker-compose / nginx / prometheus / grafana / backup
      Dockerfile  README.md  .env.example

## 本地开发

依赖：Go 1.22+、PostgreSQL 16（含 PostGIS）、Redis 7。

    cd ais
    cp .env.example .env          # 修改 AIS_JWT_SECRET、AIS_STATIONS 等
    go mod tidy
    go build ./... && go vet ./... && go test ./...

    # 建管理员并启动（另开终端）
    go run ./cmd/ais user-create -username admin -password <密码> -role admin
    go run ./cmd/ais run

健康检查：`curl http://localhost:8080/api/v1/healthz`；登录：`POST /api/v1/auth/login`。

## Docker 部署

    cd ais/deployment
    docker compose config -q      # 语法校验
    docker compose up -d --build  # 启动全部服务
    docker compose ps             # 等待 health
    docker compose logs -f ais    # 查看应用日志

- 对外入口：`https://<域名或IP>/api/v1/healthz`、`wss://<域名或IP>/ws/positions?token=...`、`/ui/` 占位页。
- 内部管理：Grafana `http://127.0.0.1:3000`（admin/部署时设置的密码）、Prometheus `http://127.0.0.1:9090`。
- 建管理员 / 手动维护：`docker compose exec ais ais user-create -username admin -password <密码> -role admin`、`docker compose exec ais ais maintenance`。

## 配置（环境变量，前缀 AIS_）

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| AIS_HTTP_ADDR | 0.0.0.0:8080 | HTTP/WS 监听地址 |
| AIS_DB_URL | postgres://ais:ais@localhost:5432/ais?sslmode=disable | PostgreSQL 连接串 |
| AIS_REDIS_ADDR / AIS_REDIS_PASSWORD | localhost:6379 / 空 | Redis 地址与口令 |
| AIS_JWT_SECRET / AIS_JWT_TTL | dev-secret-change-me / 24h | JWT 密钥与有效期 |
| AIS_STATIONS | [] | 基站 JSON 数组：[{"id","name","host","port","enabled"}] |
| AIS_WRITER_* | 1s / 1000 / 100000 | 批量写入间隔/批大小/队列上限 |
| AIS_RETENTION_DAYS | 30 | 轨迹与围栏事件保留天数 |
| AIS_FENCE_* | 60s / 5m / 2 | 围栏重载间隔/静默超时/去抖计数 |
| AIS_STATION_* | 10s / 1s / 60s / 5m | 基站连接超时/重连退避/空闲超时 |
| OSS_* | 空 | 阿里云 OSS 备份（endpoint/bucket/ak/sk） |

## API 摘要

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | /api/v1/healthz | 健康检查（无鉴权） |
| POST | /api/v1/auth/login | 登录获取 JWT |
| GET | /api/v1/positions/latest | 最新船位（Redis 快照，失败回退 DB） |
| GET | /api/v1/vessels/{mmsi}/track | 单船历史轨迹 |
| GET | /api/v1/vessels | 船舶列表（分页/搜索） |
| GET | /api/v1/base-stations | 基站在线状态 |
| GET/POST/PUT/DELETE | /api/v1/geofences[/{id}] | 电子围栏 CRUD |
| GET | /api/v1/geofences/{id}/vessels/current | 围栏内当前船舶 |
| GET | /api/v1/geofences/{id}/vessels/history | 围栏历史船舶 |
| GET | /api/v1/geofences/{id}/events | 围栏进出事件 |
| WS | /ws/positions、/ws/fence-events | 实时推送（?token= 鉴权） |
| GET | /metrics | Prometheus 指标 |

## 监控

- 大盘：Grafana 登录后可见自动导入的 “AIS 服务监控” 大盘（解析速率、解析错误、去重、围栏事件、WS 连接数、写入失败）。
- 常用告警项（可接入阿里云 ARMS / Prometheus Alertmanager）：
  - `rate(ais_messages_parse_errors_total[5m]) > 0`：解析异常持续存在；
  - `ais_ws_connections == 0`：无前端连接（长时告警）；
  - `ais_writer_flush_failures_total` 增长：落库失败，检查 PostgreSQL。

## 备份与恢复

备份：`backup` 容器每 24h 执行 `pg_basebackup -Ft -z` 并上传 `oss://<bucket>/ais-backup/<时间戳>/`，OSS 生命周期规则建议删除 30 天前对象。

恢复（新实例）：

    # 1) 下载 base.tar.gz 解压到新 PostgreSQL 数据目录（属主 postgres，权限 700）
    # 2) 启动 postgis 容器后验证
    docker compose exec postgis psql -U ais -d ais -c "select count(*) from ais_positions;"
    docker compose exec postgis psql -U ais -d ais -c "select count(*) from users;"

## 阿里云上线清单

1. 购买 ECS（4C8G，系统盘 40G SSD + 数据盘 360G），Docker 数据目录（`/var/lib/docker`）挂载到数据盘。
2. 安全组放行：22（管理）、80/443（对外）；3000/9090 仅放行办公网 IP。
3. 安装 Docker Engine + Compose 插件；上传项目到 ECS。
4. `cp .env.example .env` 并修改 `AIS_JWT_SECRET`、`AIS_STATIONS`（真实基站）、`OSS_*`；可选创建 `deployment/.env` 覆盖数据库口令与 Grafana 密码。
5. 放置 CA 证书到 `deployment/nginx/certs/`（阿里云数字证书服务签发）。
6. `docker compose up -d --build`，`docker compose ps` 全部 healthy。
7. 建管理员：`docker compose exec ais ais user-create -username admin -password <强密码> -role admin`。
8. DNS A 记录指向 ECS 公网 IP，验证 `https://<域名>/api/v1/healthz`。
9. OSS 控制台为该 bucket 配置生命周期规则（`ais-backup/` 前缀，删除 30 天前对象）。
10. Grafana 配置告警；接入阿里云云监控（CPU/内存/磁盘/带宽）。

## 扩展路径（B 方案：多客户端 / 更大规模）

当前架构单二进制内聚 gateway+api，已通过 Redis pub/sub 与统一扇出为拆分预留：当用户量或基站数上升时——
- 将 `gateway`（接入/解析/写入）与 `api`（REST/WS）拆为两个进程/两份部署，Nginx 按路径分流；
- api 水平扩容多副本（无状态，依赖 Redis 快照与 PostgreSQL）；
- PostgreSQL 主从只读副本承接轨迹查询；Redis 集群化；
- 接入层增加 kafka/pulsar 解耦（当前 0-100 msg/s 规模不需要）。
