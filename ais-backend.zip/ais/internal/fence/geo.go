// Package fence provides point-in-polygon logic and the geofence state machine.
package fence

import "github.com/paulmach/orb"

// PointInPolygon reports whether p is inside the polygon (ray casting).
// Rings after the first are holes and exclude the point.
func PointInPolygon(p orb.Point, poly orb.Polygon) bool {
	if len(poly) == 0 {
		return false
	}
	if !inRing(p, poly[0]) {
		return false
	}
	for _, hole := range poly[1:] {
		if inRing(p, hole) {
			return false
		}
	}
	return true
}

func inRing(p orb.Point, ring orb.Ring) bool {
	inside := false
	n := len(ring)
	for i, j := 0, n-1; i < n; j, i = i, i+1 {
		a, b := ring[i], ring[j]
		if (a[1] > p[1]) != (b[1] > p[1]) &&
			p[0] < (b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0] {
			inside = !inside
		}
	}
	return inside
}
