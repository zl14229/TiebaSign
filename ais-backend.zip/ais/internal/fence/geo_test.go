package fence

import (
	"testing"

	"github.com/paulmach/orb"
)

func square() orb.Polygon {
	return orb.Polygon{orb.Ring{
		{0, 0}, {10, 0}, {10, 10}, {0, 10}, {0, 0},
	}}
}

func TestPointInPolygon_inside(t *testing.T) {
	if !PointInPolygon(orb.Point{5, 5}, square()) {
		t.Error("point (5,5) should be inside")
	}
}

func TestPointInPolygon_outside(t *testing.T) {
	if PointInPolygon(orb.Point{15, 5}, square()) {
		t.Error("point (15,5) should be outside")
	}
	if PointInPolygon(orb.Point{-1, 5}, square()) {
		t.Error("point (-1,5) should be outside")
	}
}

func TestPointInPolygon_holeExcludes(t *testing.T) {
	poly := orb.Polygon{
		orb.Ring{{0, 0}, {10, 0}, {10, 10}, {0, 10}, {0, 0}},
		orb.Ring{{2, 2}, {8, 2}, {8, 8}, {2, 8}, {2, 2}},
	}
	if PointInPolygon(orb.Point{5, 5}, poly) {
		t.Error("point in hole should be outside")
	}
	if !PointInPolygon(orb.Point{9, 9}, poly) {
		t.Error("point between outer ring and hole should be inside")
	}
}

func TestPointInPolygon_emptyPolygon(t *testing.T) {
	if PointInPolygon(orb.Point{5, 5}, orb.Polygon{}) {
		t.Error("empty polygon should contain nothing")
	}
}
