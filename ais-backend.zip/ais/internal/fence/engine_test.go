package fence

import (
	"context"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"

	"ais/internal/model"
)

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func squareFence(id int64) model.Geofence {
	return model.Geofence{
		ID:                id,
		Name:              "square",
		Area:              geojson.Geometry{Coordinates: orb.Polygon{orb.Ring{{0, 0}, {10, 0}, {10, 10}, {0, 10}, {0, 0}}}},
		Enabled:           true,
		EnterAlert:        true,
		LeaveAlert:        true,
		DebounceCount:     2,
		SilenceTimeoutMin: 5,
	}
}

func insidePos(mmsi uint32) model.Position {
	return model.Position{MMSI: mmsi, Lat: 5, Lon: 5, Ts: time.Now()}
}

func outsidePos(mmsi uint32) model.Position {
	return model.Position{MMSI: mmsi, Lat: 50, Lon: 50, Ts: time.Now()}
}

type fakeLister struct {
	items []model.Geofence
	err   error
}

func (f *fakeLister) ListEnabled(ctx context.Context) ([]model.Geofence, error) {
	return f.items, f.err
}

type fakeSink struct {
	mu     sync.Mutex
	events []model.FenceEvent
}

func (f *fakeSink) InsertEvent(ctx context.Context, e model.FenceEvent) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.events = append(f.events, e)
	return nil
}

func (f *fakeSink) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.events)
}

type fakeFenceCache struct {
	mu        sync.Mutex
	sets      map[int64]map[uint32]bool
	published []model.FenceEvent
	cleared   map[int64]bool
}

func newFakeCache() *fakeFenceCache {
	return &fakeFenceCache{sets: map[int64]map[uint32]bool{}, cleared: map[int64]bool{}}
}

func (f *fakeFenceCache) FenceAdd(_ context.Context, fenceID int64, mmsi uint32) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.sets[fenceID] == nil {
		f.sets[fenceID] = map[uint32]bool{}
	}
	f.sets[fenceID][mmsi] = true
	return nil
}
func (f *fakeFenceCache) FenceRemove(_ context.Context, fenceID int64, mmsi uint32) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.sets[fenceID], mmsi)
	return nil
}
func (f *fakeFenceCache) FenceMembers(_ context.Context, fenceID int64) ([]uint32, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	var out []uint32
	for m := range f.sets[fenceID] {
		out = append(out, m)
	}
	return out, nil
}
func (f *fakeFenceCache) ClearFence(_ context.Context, fenceID int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.cleared[fenceID] = true
	delete(f.sets, fenceID)
	return nil
}
func (f *fakeFenceCache) PublishFenceEvent(_ context.Context, e model.FenceEvent) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.published = append(f.published, e)
	return nil
}
func (f *fakeFenceCache) inSet(fenceID int64, mmsi uint32) bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.sets[fenceID][mmsi]
}
func (f *fakeFenceCache) publishCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.published)
}

func newEngine(t *testing.T, lister GeofenceLister, cache FenceCache, sink EventSink) *Engine {
	t.Helper()
	return NewEngine(lister, cache, sink, Options{
		ReloadInterval: time.Hour, SilenceTimeout: 5 * time.Minute, DebounceCount: 2,
	}, discardLogger())
}

func TestEngine_enterAfterDebounce(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	if err := e.Reload(ctx); err != nil {
		t.Fatal(err)
	}

	e.OnPosition(ctx, insidePos(100))
	if sink.count() != 0 {
		t.Fatal("first inside point must not emit enter (debounce)")
	}
	e.OnPosition(ctx, insidePos(100))
	if sink.count() != 1 {
		t.Fatalf("sink events = %d, want 1 enter", sink.count())
	}
	if cache.publishCount() != 1 {
		t.Fatalf("published = %d, want 1", cache.publishCount())
	}
	if !cache.inSet(1, 100) {
		t.Error("vessel 100 should be in fence 1 set after enter")
	}
	// 重复的围栏内点不再产生事件
	e.OnPosition(ctx, insidePos(100))
	if sink.count() != 1 {
		t.Errorf("sink events = %d, want still 1", sink.count())
	}
}

func TestEngine_leave(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	_ = e.Reload(ctx)

	e.OnPosition(ctx, insidePos(100))
	e.OnPosition(ctx, insidePos(100)) // enter
	e.OnPosition(ctx, outsidePos(100))
	if sink.count() != 2 {
		t.Fatalf("sink events = %d, want 2 (enter+leave)", sink.count())
	}
	if cache.inSet(1, 100) {
		t.Error("vessel 100 should be removed from fence 1 set after leave")
	}
}

func TestEngine_silenceTimeout(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	_ = e.Reload(ctx)

	now := time.Date(2026, 8, 7, 10, 0, 0, 0, time.UTC)
	e.SetNow(func() time.Time { return now })
	e.OnPosition(ctx, insidePos(100))
	now = now.Add(time.Minute)
	e.OnPosition(ctx, insidePos(100)) // enter
	if sink.count() != 1 {
		t.Fatalf("sink events = %d, want 1 enter", sink.count())
	}
	now = now.Add(10 * time.Minute) // 超过 5 分钟静默
	e.checkSilence(ctx)
	if sink.count() != 2 {
		t.Fatalf("sink events = %d, want 2 after silence leave", sink.count())
	}
	if e.state[1][100].inside {
		t.Error("vessel should be marked outside after silence leave")
	}
	if cache.inSet(1, 100) {
		t.Error("vessel should be removed from fence set after silence leave")
	}
}

func TestEngine_reloadRemovedFenceClearsState(t *testing.T) {
	lister := &fakeLister{items: []model.Geofence{squareFence(1)}}
	cache := newFakeCache()
	sink := &fakeSink{}
	e := newEngine(t, lister, cache, sink)
	ctx := context.Background()
	_ = e.Reload(ctx)

	e.OnPosition(ctx, insidePos(100))
	e.OnPosition(ctx, insidePos(100)) // enter

	lister.items = nil // 围栏被删除
	if err := e.Reload(ctx); err != nil {
		t.Fatal(err)
	}
	if !cache.cleared[1] {
		t.Error("fence 1 set should be cleared when fence removed")
	}
	if _, ok := e.fences[1]; ok {
		t.Error("fence 1 should be removed from engine state")
	}
}
