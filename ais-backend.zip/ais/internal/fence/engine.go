package fence

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/paulmach/orb"

	"ais/internal/model"
)

type GeofenceLister interface {
	ListEnabled(ctx context.Context) ([]model.Geofence, error)
}

type EventSink interface {
	InsertEvent(ctx context.Context, e model.FenceEvent) error
}

type FenceCache interface {
	FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error
	ClearFence(ctx context.Context, fenceID int64) error
	PublishFenceEvent(ctx context.Context, e model.FenceEvent) error
}

type Options struct {
	ReloadInterval time.Duration
	SilenceTimeout time.Duration
	DebounceCount  int
}

type loadedFence struct {
	id             int64
	poly           orb.Polygon
	enterAlert     bool
	leaveAlert     bool
	debounceCount  int
	silenceTimeout time.Duration
}

type vesselState struct {
	inside   bool
	countIn  int
	lastSeen time.Time
	lastLat  float64
	lastLon  float64
}

type Engine struct {
	repo  GeofenceLister
	cache FenceCache
	sink  EventSink
	opts  Options
	log   *slog.Logger
	now   func() time.Time

	mu     sync.RWMutex
	fences map[int64]*loadedFence
	state  map[int64]map[uint32]*vesselState
}

func NewEngine(repo GeofenceLister, cacheClient FenceCache, sink EventSink, opts Options, log *slog.Logger) *Engine {
	if opts.ReloadInterval <= 0 {
		opts.ReloadInterval = time.Minute
	}
	if opts.SilenceTimeout <= 0 {
		opts.SilenceTimeout = 5 * time.Minute
	}
	if opts.DebounceCount <= 0 {
		opts.DebounceCount = 2
	}
	return &Engine{
		repo: repo, cache: cacheClient, sink: sink, opts: opts, log: log,
		now:    time.Now,
		fences: map[int64]*loadedFence{},
		state:  map[int64]map[uint32]*vesselState{},
	}
}

func (e *Engine) SetNow(f func() time.Time) { e.now = f }

func (e *Engine) Run(ctx context.Context) {
	reloadTicker := time.NewTicker(e.opts.ReloadInterval)
	defer reloadTicker.Stop()
	silenceTicker := time.NewTicker(30 * time.Second)
	defer silenceTicker.Stop()
	if err := e.Reload(ctx); err != nil {
		e.log.Error("fence reload failed", "err", err)
	}
	for {
		select {
		case <-ctx.Done():
			return
		case <-reloadTicker.C:
			if err := e.Reload(ctx); err != nil {
				e.log.Error("fence reload failed", "err", err)
			}
		case <-silenceTicker.C:
			e.checkSilence(ctx)
		}
	}
}

func (e *Engine) Reload(ctx context.Context) error {
	enabled, err := e.repo.ListEnabled(ctx)
	if err != nil {
		return err
	}
	next := map[int64]*loadedFence{}
	for _, g := range enabled {
		poly, ok := g.Area.Geometry().(orb.Polygon)
		if !ok {
			continue
		}
		debounce := g.DebounceCount
		if debounce <= 0 {
			debounce = e.opts.DebounceCount
		}
		silence := time.Duration(g.SilenceTimeoutMin) * time.Minute
		if silence <= 0 {
			silence = e.opts.SilenceTimeout
		}
		next[g.ID] = &loadedFence{
			id: g.ID, poly: poly,
			enterAlert: g.EnterAlert, leaveAlert: g.LeaveAlert,
			debounceCount: debounce, silenceTimeout: silence,
		}
	}
	e.mu.Lock()
	for id, f := range next {
		if _, ok := e.fences[id]; !ok {
			// 新围栏：清空旧集合，防止脏成员导致状态错乱
			if err := e.cache.ClearFence(ctx, id); err != nil {
				e.log.Warn("clear fence set failed", "fence_id", id, "err", err)
			}
		}
		e.fences[id] = f
	}
	for id := range e.fences {
		if _, ok := next[id]; !ok {
			delete(e.fences, id)
			delete(e.state, id)
			if err := e.cache.ClearFence(ctx, id); err != nil {
				e.log.Warn("clear removed fence set failed", "fence_id", id, "err", err)
			}
		}
	}
	e.mu.Unlock()
	return nil
}

func (e *Engine) OnPosition(ctx context.Context, p model.Position) {
	e.mu.RLock()
	defer e.mu.RUnlock()
	pt := orb.Point{p.Lon, p.Lat}
	for id, f := range e.fences {
		st := e.stateFor(id, p.MMSI)
		inside := PointInPolygon(pt, f.poly)
		if inside {
			st.lastLat, st.lastLon = p.Lat, p.Lon
			if !st.inside {
				st.countIn++
				if st.countIn >= f.debounceCount {
					st.inside = true
					st.countIn = 0
					st.lastSeen = e.now()
					e.emit(ctx, f, p, model.EventTypeEnter)
				}
			} else {
				st.lastSeen = e.now()
			}
		} else if st.inside {
			st.inside = false
			st.countIn = 0
			e.emit(ctx, f, p, model.EventTypeLeave)
		}
	}
}

func (e *Engine) checkSilence(ctx context.Context) {
	e.mu.Lock()
	defer e.mu.Unlock()
	now := e.now()
	for id, m := range e.state {
		f := e.fences[id]
		if f == nil {
			continue
		}
		for mmsi, st := range m {
			if st.inside && now.Sub(st.lastSeen) > f.silenceTimeout {
				st.inside = false
				st.countIn = 0
				p := model.Position{MMSI: mmsi, Lat: st.lastLat, Lon: st.lastLon}
				e.emit(ctx, f, p, model.EventTypeLeave)
			}
		}
	}
}

func (e *Engine) stateFor(fenceID int64, mmsi uint32) *vesselState {
	m := e.state[fenceID]
	if m == nil {
		m = map[uint32]*vesselState{}
		e.state[fenceID] = m
	}
	s := m[mmsi]
	if s == nil {
		s = &vesselState{}
		m[mmsi] = s
	}
	return s
}

func (e *Engine) emit(ctx context.Context, f *loadedFence, p model.Position, eventType int16) {
	if eventType == model.EventTypeEnter && !f.enterAlert {
		return
	}
	if eventType == model.EventTypeLeave && !f.leaveAlert {
		return
	}
	ev := model.FenceEvent{
		FenceID: f.id, MMSI: p.MMSI, EventType: eventType,
		Ts: e.now(), Lat: p.Lat, Lon: p.Lon,
	}
	if err := e.sink.InsertEvent(ctx, ev); err != nil {
		e.log.Error("insert fence event failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
	}
	if err := e.cache.PublishFenceEvent(ctx, ev); err != nil {
		e.log.Error("publish fence event failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
	}
	switch eventType {
	case model.EventTypeEnter:
		if err := e.cache.FenceAdd(ctx, f.id, p.MMSI); err != nil {
			e.log.Error("fence add failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
		}
	case model.EventTypeLeave:
		if err := e.cache.FenceRemove(ctx, f.id, p.MMSI); err != nil {
			e.log.Error("fence remove failed", "err", err, "fence_id", f.id, "mmsi", p.MMSI)
		}
	}
}
