package station

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"net"
	"strconv"
	"sync"
	"testing"
	"time"
)

type recorder struct {
	mu     sync.Mutex
	lines  []string
	status []bool
}

func (r *recorder) OnLine(_ string, line string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.lines = append(r.lines, line)
}

func (r *recorder) OnStatus(_ string, connected bool, _ error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.status = append(r.status, connected)
}

func (r *recorder) hasLine(want string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, l := range r.lines {
		if l == want {
			return true
		}
	}
	return false
}

func (r *recorder) lastStatus() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if len(r.status) == 0 {
		return false
	}
	return r.status[len(r.status)-1]
}

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func waitUntil(t *testing.T, timeout time.Duration, cond func() bool, msg string) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal(msg)
}

func TestStation_receivesLinesAndReconnects(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	host, portStr, _ := net.SplitHostPort(ln.Addr().String())
	port, _ := strconv.Atoi(portStr)

	serverErr := make(chan error, 1)
	go func() {
		// 第一次连接：写两行后关闭
		conn, err := ln.Accept()
		if err != nil {
			serverErr <- err
			return
		}
		fmt.Fprintf(conn, "line1\r\nline2\r\n")
		conn.Close()
		// 第二次连接（重连）：持续写 lineA
		conn2, err := ln.Accept()
		if err != nil {
			serverErr <- err
			return
		}
		defer conn2.Close()
		for i := 0; i < 200; i++ {
			fmt.Fprintf(conn2, "lineA\r\n")
			time.Sleep(10 * time.Millisecond)
		}
		serverErr <- nil
	}()

	rec := &recorder{}
	s := New(Config{ID: "st1", Name: "t", Host: host, Port: port, Enabled: true}, rec,
		Options{ConnectTimeout: time.Second, ReconnectBase: 30 * time.Millisecond, ReconnectMax: 100 * time.Millisecond, IdleTimeout: 5 * time.Second},
		discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan struct{})
	go func() {
		defer close(done)
		s.Run(ctx)
	}()

	waitUntil(t, 10*time.Second, func() bool { return rec.hasLine("lineA") }, "timeout: never reconnected")
	waitUntil(t, 5*time.Second, func() bool { return rec.hasLine("line1") }, "timeout: line1 not received")
	waitUntil(t, 5*time.Second, func() bool { return !rec.lastStatus() }, "timeout: expected disconnected status after first close")

	cancel()
	<-done
	select {
	case err := <-serverErr:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("server goroutine did not finish")
	}
}

func TestStation_idleTimeoutClosesConnection(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	host, portStr, _ := net.SplitHostPort(ln.Addr().String())
	port, _ := strconv.Atoi(portStr)

	accepted := make(chan struct{}, 4)
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			accepted <- struct{}{}
			go func(c net.Conn) {
				// 不写任何数据，等待对端超时关闭
				io.Copy(io.Discard, c)
				c.Close()
			}(conn)
		}
	}()

	rec := &recorder{}
	s := New(Config{ID: "st2", Name: "t", Host: host, Port: port, Enabled: true}, rec,
		Options{ConnectTimeout: time.Second, ReconnectBase: 30 * time.Millisecond, ReconnectMax: 100 * time.Millisecond, IdleTimeout: 200 * time.Millisecond},
		discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	done := make(chan struct{})
	go func() {
		defer close(done)
		s.Run(ctx)
	}()

	// 200ms 空闲超时 → 应断开重连，至少出现两次连接
	waitUntil(t, 10*time.Second, func() bool { return len(accepted) >= 2 }, "timeout: expected reconnect after idle timeout")
	cancel()
	<-done
}

func TestManager_statuses(t *testing.T) {
	rec := &recorder{}
	m := NewManager([]Config{
		{ID: "a", Name: "A", Host: "127.0.0.1", Port: 1, Enabled: true},
		{ID: "b", Name: "B", Host: "127.0.0.1", Port: 2, Enabled: false},
	}, rec, Options{}, discardLogger())
	st := m.Statuses()
	if len(st) != 2 {
		t.Fatalf("Statuses() len = %d, want 2", len(st))
	}
	if st[0].ID != "a" || st[0].Connected {
		t.Errorf("station a status = %+v, want not connected", st[0])
	}
	if st[1].ID != "b" || st[1].Connected {
		t.Errorf("station b status = %+v, want not connected", st[1])
	}
}
