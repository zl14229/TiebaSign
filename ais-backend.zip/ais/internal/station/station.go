// Package station manages TCP connections to AIS base stations with
// line reading, idle heartbeat detection and exponential backoff reconnect.
package station

import (
	"bufio"
	"context"
	"fmt"
	"log/slog"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

type Config struct {
	ID      string
	Name    string
	Host    string
	Port    int
	Enabled bool
}

func (c Config) Addr() string {
	return net.JoinHostPort(c.Host, fmt.Sprintf("%d", c.Port))
}

type Options struct {
	ConnectTimeout time.Duration
	ReconnectBase  time.Duration
	ReconnectMax   time.Duration
	IdleTimeout    time.Duration
	ReadBufSize    int
}

type Handler interface {
	OnLine(stationID string, line string)
	OnStatus(stationID string, connected bool, err error)
}

type Status struct {
	ID        string
	Name      string
	Connected bool
	LastError string
	Lines     uint64
	Since     time.Time
}

type Station struct {
	cfg     Config
	handler Handler
	opts    Options
	log     *slog.Logger

	connected atomic.Bool
	lastError atomic.Value
	lines     atomic.Uint64
	since     atomic.Value
}

func New(cfg Config, handler Handler, opts Options, log *slog.Logger) *Station {
	return &Station{cfg: cfg, handler: handler, opts: opts, log: log}
}

func (s *Station) Run(ctx context.Context) {
	if !s.cfg.Enabled {
		s.log.Info("station disabled, skipping", "station", s.cfg.ID)
		return
	}
	backoff := s.opts.ReconnectBase
	for {
		if ctx.Err() != nil {
			return
		}
		err := s.runOnce(ctx)
		s.setConnected(false, err)
		s.handler.OnStatus(s.cfg.ID, false, err)
		if ctx.Err() != nil {
			return
		}
		s.log.Warn("station disconnected", "station", s.cfg.ID, "err", err)
		select {
		case <-ctx.Done():
			return
		case <-time.After(backoff):
		}
		backoff *= 2
		if backoff > s.opts.ReconnectMax {
			backoff = s.opts.ReconnectMax
		}
	}
}

func (s *Station) runOnce(ctx context.Context) error {
	d := net.Dialer{Timeout: s.opts.ConnectTimeout}
	conn, err := d.DialContext(ctx, "tcp", s.cfg.Addr())
	if err != nil {
		return err
	}
	stop := make(chan struct{})
	defer close(stop)
	go func() {
		select {
		case <-ctx.Done():
			_ = conn.Close()
		case <-stop:
		}
	}()
	defer conn.Close()

	s.setConnected(true, nil)
	s.handler.OnStatus(s.cfg.ID, true, nil)
	s.log.Info("station connected", "station", s.cfg.ID, "addr", s.cfg.Addr())

	scanner := bufio.NewScanner(conn)
	if s.opts.ReadBufSize > 0 {
		scanner.Buffer(make([]byte, s.opts.ReadBufSize), s.opts.ReadBufSize)
	}
	for {
		if s.opts.IdleTimeout > 0 {
			_ = conn.SetReadDeadline(time.Now().Add(s.opts.IdleTimeout))
		}
		if !scanner.Scan() {
			if err := scanner.Err(); err != nil {
				return err
			}
			return fmt.Errorf("connection closed by peer")
		}
		s.lines.Add(1)
		s.handler.OnLine(s.cfg.ID, scanner.Text())
		if ctx.Err() != nil {
			return ctx.Err()
		}
	}
}

func (s *Station) setConnected(v bool, err error) {
	s.connected.Store(v)
	if err != nil {
		s.lastError.Store(err.Error())
	} else {
		s.lastError.Store("")
	}
	if v {
		s.since.Store(time.Now())
	} else {
		s.since.Store(time.Time{})
	}
}

func (s *Station) Status() Status {
	st := Status{ID: s.cfg.ID, Name: s.cfg.Name, Connected: s.connected.Load(), Lines: s.lines.Load()}
	if e, ok := s.lastError.Load().(string); ok {
		st.LastError = e
	}
	if t, ok := s.since.Load().(time.Time); ok {
		st.Since = t
	}
	return st
}

type Manager struct {
	stations []*Station
}

func NewManager(cfgs []Config, handler Handler, opts Options, log *slog.Logger) *Manager {
	m := &Manager{}
	for _, c := range cfgs {
		m.stations = append(m.stations, New(c, handler, opts, log))
	}
	return m
}

func (m *Manager) Run(ctx context.Context) {
	var wg sync.WaitGroup
	for _, s := range m.stations {
		wg.Add(1)
		go func(s *Station) {
			defer wg.Done()
			s.Run(ctx)
		}(s)
	}
	wg.Wait()
}

func (m *Manager) Statuses() []Status {
	out := make([]Status, 0, len(m.stations))
	for _, s := range m.stations {
		out = append(out, s.Status())
	}
	return out
}
