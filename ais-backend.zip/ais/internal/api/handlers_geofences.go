package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"

	"ais/internal/fence"
	"ais/internal/model"
	"ais/internal/store"
)

type fenceRequest struct {
	Name              string           `json:"name"`
	Area              geojson.Geometry `json:"area"`
	Enabled           *bool            `json:"enabled"`
	EnterAlert        *bool            `json:"enter_alert"`
	LeaveAlert        *bool            `json:"leave_alert"`
	DebounceCount     int              `json:"debounce_count"`
	SilenceTimeoutMin int              `json:"silence_timeout_min"`
}

func validatePolygon(g geojson.Geometry) error {
	poly, ok := g.Geometry().(orb.Polygon)
	if !ok {
		return errors.New("area must be a GeoJSON Polygon")
	}
	if len(poly) == 0 || len(poly[0]) < 4 {
		return errors.New("polygon needs at least 4 points")
	}
	first, last := poly[0][0], poly[0][len(poly[0])-1]
	if first[0] != last[0] || first[1] != last[1] {
		return errors.New("polygon ring must be closed")
	}
	return nil
}

func (s *Server) handleListGeofences(w http.ResponseWriter, r *http.Request) {
	items, err := s.Geofences.List(r.Context())
	if err != nil {
		s.Log.Error("geofences list failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if items == nil {
		items = []model.Geofence{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (s *Server) handleGetGeofence(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	g, err := s.Geofences.Get(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence get failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, g)
}

func (s *Server) handleCreateGeofence(w http.ResponseWriter, r *http.Request) {
	var req fenceRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid json body")
		return
	}
	if req.Name == "" {
		writeErr(w, http.StatusBadRequest, "name is required")
		return
	}
	if err := validatePolygon(req.Area); err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	g := model.Geofence{
		Name:              req.Name,
		Area:              req.Area,
		Enabled:           true,
		EnterAlert:        true,
		LeaveAlert:        true,
		DebounceCount:     2,
		SilenceTimeoutMin: 5,
	}
	if req.Enabled != nil {
		g.Enabled = *req.Enabled
	}
	if req.EnterAlert != nil {
		g.EnterAlert = *req.EnterAlert
	}
	if req.LeaveAlert != nil {
		g.LeaveAlert = *req.LeaveAlert
	}
	if req.DebounceCount > 0 {
		g.DebounceCount = req.DebounceCount
	}
	if req.SilenceTimeoutMin > 0 {
		g.SilenceTimeoutMin = req.SilenceTimeoutMin
	}
	created, err := s.Geofences.Create(r.Context(), g)
	if err != nil {
		s.Log.Error("geofence create failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusCreated, created)
}

func (s *Server) handleUpdateGeofence(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	var req fenceRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid json body")
		return
	}
	existing, err := s.Geofences.Get(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence get failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if req.Name != "" {
		existing.Name = req.Name
	}
	if req.Area.Geometry() != nil {
		if err := validatePolygon(req.Area); err != nil {
			writeErr(w, http.StatusBadRequest, err.Error())
			return
		}
		existing.Area = req.Area
	}
	if req.Enabled != nil {
		existing.Enabled = *req.Enabled
	}
	if req.EnterAlert != nil {
		existing.EnterAlert = *req.EnterAlert
	}
	if req.LeaveAlert != nil {
		existing.LeaveAlert = *req.LeaveAlert
	}
	if req.DebounceCount > 0 {
		existing.DebounceCount = req.DebounceCount
	}
	if req.SilenceTimeoutMin > 0 {
		existing.SilenceTimeoutMin = req.SilenceTimeoutMin
	}
	updated, err := s.Geofences.Update(r.Context(), existing)
	if err != nil {
		s.Log.Error("geofence update failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, updated)
}

func (s *Server) handleDeleteGeofence(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	err = s.Geofences.Delete(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence delete failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "deleted"})
}

func (s *Server) handleFenceCurrent(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	g, err := s.Geofences.Get(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "geofence not found")
		return
	}
	if err != nil {
		s.Log.Error("geofence get failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	poly, ok := g.Area.Geometry().(orb.Polygon)
	if !ok {
		writeErr(w, http.StatusInternalServerError, "geofence area is not a polygon")
		return
	}
	latest, err := s.Latest.AllLatest(r.Context())
	if err != nil {
		s.Log.Error("latest failed for fence current", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	items := []model.Position{}
	for _, p := range latest {
		if fence.PointInPolygon(orb.Point{p.Lon, p.Lat}, poly) {
			items = append(items, p)
		}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (s *Server) handleFenceHistory(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	start, end, ok := parseTimeRange(w, r)
	if !ok {
		return
	}
	mmsis, err := s.Positions.FenceHistoryVessels(r.Context(), id, start, end)
	if err != nil {
		s.Log.Error("fence history failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if mmsis == nil {
		mmsis = []uint32{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": mmsis})
}

func (s *Server) handleFenceEvents(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid id")
		return
	}
	start, end, ok := parseTimeRange(w, r)
	if !ok {
		return
	}
	limit := 1000
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 5000 {
			limit = n
		}
	}
	items, err := s.Geofences.Events(r.Context(), id, start, end, limit)
	if err != nil {
		s.Log.Error("fence events failed", "err", err, "id", id)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if items == nil {
		items = []model.FenceEvent{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func parseTimeRange(w http.ResponseWriter, r *http.Request) (time.Time, time.Time, bool) {
	start, err := time.Parse(time.RFC3339, r.URL.Query().Get("start"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "start must be RFC3339")
		return time.Time{}, time.Time{}, false
	}
	end, err := time.Parse(time.RFC3339, r.URL.Query().Get("end"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "end must be RFC3339")
		return time.Time{}, time.Time{}, false
	}
	if !end.After(start) {
		writeErr(w, http.StatusBadRequest, "end must be after start")
		return time.Time{}, time.Time{}, false
	}
	if end.Sub(start) > 31*24*time.Hour {
		writeErr(w, http.StatusBadRequest, "range limited to 31 days")
		return time.Time{}, time.Time{}, false
	}
	return start, end, true
}
