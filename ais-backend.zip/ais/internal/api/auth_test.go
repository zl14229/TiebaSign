package api

import (
	"testing"
	"time"

	"ais/internal/model"
)

func TestGenerateAndParseToken(t *testing.T) {
	user := model.User{ID: 7, Username: "admin", Role: "admin"}
	token, err := GenerateToken("secret-1", user, time.Hour)
	if err != nil {
		t.Fatalf("GenerateToken() error = %v", err)
	}
	claims, err := ParseToken("secret-1", token)
	if err != nil {
		t.Fatalf("ParseToken() error = %v", err)
	}
	if claims.UserID != 7 || claims.Username != "admin" || claims.Role != "admin" {
		t.Errorf("claims = %+v, want user 7 admin", claims)
	}
}

func TestParseToken_wrongSecret(t *testing.T) {
	user := model.User{ID: 1, Username: "u", Role: "user"}
	token, err := GenerateToken("secret-1", user, time.Hour)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := ParseToken("secret-2", token); err == nil {
		t.Fatal("ParseToken() expected error for wrong secret")
	}
}

func TestParseToken_expired(t *testing.T) {
	user := model.User{ID: 1, Username: "u", Role: "user"}
	token, err := GenerateToken("secret-1", user, -time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := ParseToken("secret-1", token); err == nil {
		t.Fatal("ParseToken() expected error for expired token")
	}
}
