package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	"golang.org/x/crypto/bcrypt"

	"ais/internal/model"
	"ais/internal/store"
)

func (s *Server) handleHealthz(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid json body")
		return
	}
	if req.Username == "" || req.Password == "" {
		writeErr(w, http.StatusBadRequest, "username and password required")
		return
	}
	user, err := s.Users.GetByUsername(r.Context(), req.Username)
	if err != nil {
		if errors.Is(err, store.ErrNotFound) {
			writeErr(w, http.StatusUnauthorized, "invalid credentials")
			return
		}
		s.Log.Error("login lookup failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)) != nil {
		writeErr(w, http.StatusUnauthorized, "invalid credentials")
		return
	}
	token, err := GenerateToken(s.Cfg.JWTSecret, user, s.Cfg.JWTTTL)
	if err != nil {
		s.Log.Error("generate token failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"token": token, "username": user.Username, "role": user.Role,
	})
}

func (s *Server) handleLatestPositions(w http.ResponseWriter, r *http.Request) {
	items, err := s.Latest.AllLatest(r.Context())
	if err != nil {
		s.Log.Warn("redis latest failed, falling back to db", "err", err)
		items, err = s.Positions.LatestFallback(r.Context())
		if err != nil {
			s.Log.Error("latest fallback failed", "err", err)
			writeErr(w, http.StatusInternalServerError, "internal error")
			return
		}
	}
	if items == nil {
		items = []model.Position{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}

func (s *Server) handleTrack(w http.ResponseWriter, r *http.Request) {
	mmsi, err := strconv.ParseUint(r.PathValue("mmsi"), 10, 32)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid mmsi")
		return
	}
	start, err := time.Parse(time.RFC3339, r.URL.Query().Get("start"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "start must be RFC3339")
		return
	}
	end, err := time.Parse(time.RFC3339, r.URL.Query().Get("end"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "end must be RFC3339")
		return
	}
	if !end.After(start) {
		writeErr(w, http.StatusBadRequest, "end must be after start")
		return
	}
	if end.Sub(start) > 31*24*time.Hour {
		writeErr(w, http.StatusBadRequest, "range limited to 31 days")
		return
	}
	bucket := 0
	if v := r.URL.Query().Get("bucket"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 86400 {
			writeErr(w, http.StatusBadRequest, "bucket must be 1..86400 seconds")
			return
		}
		bucket = n
	}
	limit := 10000
	if v := r.URL.Query().Get("limit"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 50000 {
			writeErr(w, http.StatusBadRequest, "limit must be 1..50000")
			return
		}
		limit = n
	}
	pts, err := s.Positions.Track(r.Context(), uint32(mmsi), start, end, bucket, limit)
	if err != nil {
		s.Log.Error("track query failed", "err", err, "mmsi", mmsi)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if pts == nil {
		pts = []model.TrackPoint{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"mmsi": mmsi, "items": pts})
}

func (s *Server) handleListVessels(w http.ResponseWriter, r *http.Request) {
	page := 1
	pageSize := 50
	if v := r.URL.Query().Get("page"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			page = n
		}
	}
	if v := r.URL.Query().Get("page_size"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 200 {
			pageSize = n
		}
	}
	items, total, err := s.Vessels.List(r.Context(), page, pageSize, r.URL.Query().Get("search"))
	if err != nil {
		s.Log.Error("vessels list failed", "err", err)
		writeErr(w, http.StatusInternalServerError, "internal error")
		return
	}
	if items == nil {
		items = []model.Vessel{}
	}
	writeJSON(w, http.StatusOK, map[string]any{"total": total, "items": items})
}

func (s *Server) handleBaseStations(w http.ResponseWriter, r *http.Request) {
	if s.StationMgr == nil {
		writeJSON(w, http.StatusOK, map[string]any{"items": []any{}})
		return
	}
	statuses := s.StationMgr.Statuses()
	items := make([]map[string]any, 0, len(statuses))
	for _, st := range statuses {
		items = append(items, map[string]any{
			"id": st.ID, "name": st.Name, "connected": st.Connected,
			"last_error": st.LastError, "lines": st.Lines, "since": st.Since,
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{"items": items})
}
