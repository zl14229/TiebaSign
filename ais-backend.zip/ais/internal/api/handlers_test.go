package api

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"ais/internal/model"
	"ais/internal/store"
)

var (
	errNotFoundSentinel = store.ErrNotFound
	errRedisDown        = errors.New("redis down")
)

type fakePositions struct {
	track    []model.TrackPoint
	fallback []model.Position
	err      error
}

func (f *fakePositions) Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error) {
	return f.track, f.err
}

func (f *fakePositions) LatestFallback(ctx context.Context) ([]model.Position, error) {
	return f.fallback, f.err
}

type fakeLatest struct {
	items []model.Position
	err   error
}

func (f *fakeLatest) AllLatest(ctx context.Context) ([]model.Position, error) {
	return f.items, f.err
}

type fakeVessels struct {
	items []model.Vessel
	total int64
}

func (f *fakeVessels) List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error) {
	return f.items, f.total, nil
}

type fakeUsers struct {
	user model.User
	err  error
}

func (f *fakeUsers) GetByUsername(ctx context.Context, username string) (model.User, error) {
	return f.user, f.err
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func newTestServer(t *testing.T, s *Server) *httptest.Server {
	t.Helper()
	ts := httptest.NewServer(s.Handler())
	t.Cleanup(ts.Close)
	return ts
}

func getJSON(t *testing.T, url, token string) (int, map[string]any) {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatal(err)
	}
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var m map[string]any
	_ = json.NewDecoder(resp.Body).Decode(&m)
	return resp.StatusCode, m
}

func TestHealthz(t *testing.T) {
	s := &Server{Cfg: ServerConfig{JWTSecret: "s", JWTTTL: time.Hour}, Log: testLogger()}
	ts := newTestServer(t, s)
	status, m := getJSON(t, ts.URL+"/api/v1/healthz", "")
	if status != http.StatusOK {
		t.Fatalf("healthz status = %d, want 200", status)
	}
	if m["status"] != "ok" {
		t.Errorf("healthz body = %v, want status ok", m)
	}
}

func TestLogin_requiresValidUser(t *testing.T) {
	s := &Server{
		Cfg:   ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Users: &fakeUsers{err: errNotFoundSentinel},
		Log:   testLogger(),
	}
	ts := newTestServer(t, s)
	resp, err := http.Post(ts.URL+"/api/v1/auth/login", "application/json",
		strings.NewReader(`{"username":"admin","password":"wrong"}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Errorf("login status = %d, want 401", resp.StatusCode)
	}
}

func TestTrack_requiresAuthAndValidatesParams(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Positions: &fakePositions{track: []model.TrackPoint{{Ts: time.Now(), Lat: 1, Lon: 2}}},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)

	// 无 token → 401
	status, _ := getJSON(t, ts.URL+"/api/v1/vessels/477553000/track?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", "")
	if status != http.StatusUnauthorized {
		t.Errorf("track without token status = %d, want 401", status)
	}

	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	// 缺少 start → 400
	status, _ = getJSON(t, ts.URL+"/api/v1/vessels/477553000/track?end=2026-08-07T01:00:00Z", token)
	if status != http.StatusBadRequest {
		t.Errorf("track missing start status = %d, want 400", status)
	}

	// 合法请求 → 200 且返回 items
	status, m := getJSON(t, ts.URL+"/api/v1/vessels/477553000/track?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", token)
	if status != http.StatusOK {
		t.Errorf("track status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Errorf("track items = %v, want 1 item", m["items"])
	}
}

func TestLatestPositions_fallsBackToDB(t *testing.T) {
	s := &Server{
		Cfg:    ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Latest: &fakeLatest{err: errRedisDown},
		Positions: &fakePositions{
			fallback: []model.Position{{MMSI: 1, Lat: 1, Lon: 1, Ts: time.Now()}},
		},
		Log: testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)
	status, m := getJSON(t, ts.URL+"/api/v1/positions/latest", token)
	if status != http.StatusOK {
		t.Fatalf("latest status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Errorf("latest items = %v, want fallback row", m["items"])
	}
}
