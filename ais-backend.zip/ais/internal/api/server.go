// Package api implements the REST + WebSocket HTTP layer.
package api

import (
	"context"
	"log/slog"
	"net/http"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"

	"ais/internal/model"
	"ais/internal/station"
	"ais/internal/wshub"
)

type PositionRepo interface {
	Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error)
	LatestFallback(ctx context.Context) ([]model.Position, error)
	FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error)
}

type LatestCache interface {
	AllLatest(ctx context.Context) ([]model.Position, error)
}

type VesselRepo interface {
	List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error)
}

type UserRepo interface {
	GetByUsername(ctx context.Context, username string) (model.User, error)
}

type GeofenceRepo interface {
	List(ctx context.Context) ([]model.Geofence, error)
	Get(ctx context.Context, id int64) (model.Geofence, error)
	Create(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Update(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Delete(ctx context.Context, id int64) error
	Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error)
}

type ServerConfig struct {
	JWTSecret string
	JWTTTL    time.Duration
}

type Server struct {
	Cfg        ServerConfig
	Positions  PositionRepo
	Latest     LatestCache
	Vessels    VesselRepo
	Users      UserRepo
	Geofences  GeofenceRepo
	PosHub     *wshub.Hub
	EventHub   *wshub.Hub
	StationMgr *station.Manager
	Log        *slog.Logger
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/v1/healthz", s.handleHealthz)
	mux.HandleFunc("POST /api/v1/auth/login", s.handleLogin)
	mux.Handle("GET /api/v1/positions/latest", s.auth(s.handleLatestPositions))
	mux.Handle("GET /api/v1/vessels/{mmsi}/track", s.auth(s.handleTrack))
	mux.Handle("GET /api/v1/vessels", s.auth(s.handleListVessels))
	mux.Handle("GET /api/v1/base-stations", s.auth(s.handleBaseStations))
	mux.Handle("GET /api/v1/geofences", s.auth(s.handleListGeofences))
	mux.Handle("POST /api/v1/geofences", s.auth(s.handleCreateGeofence))
	mux.Handle("GET /api/v1/geofences/{id}", s.auth(s.handleGetGeofence))
	mux.Handle("PUT /api/v1/geofences/{id}", s.auth(s.handleUpdateGeofence))
	mux.Handle("DELETE /api/v1/geofences/{id}", s.auth(s.handleDeleteGeofence))
	mux.Handle("GET /api/v1/geofences/{id}/vessels/current", s.auth(s.handleFenceCurrent))
	mux.Handle("GET /api/v1/geofences/{id}/vessels/history", s.auth(s.handleFenceHistory))
	mux.Handle("GET /api/v1/geofences/{id}/events", s.auth(s.handleFenceEvents))
	mux.Handle("GET /ws/positions", s.handleWS(s.PosHub))
	mux.Handle("GET /ws/fence-events", s.handleWS(s.EventHub))
	mux.Handle("GET /metrics", promhttp.Handler())
	return s.withMetrics(mux)
}

func (s *Server) auth(next http.HandlerFunc) http.Handler {
	return AuthMiddleware(s.Cfg.JWTSecret, http.HandlerFunc(next))
}

func (s *Server) handleWS(hub *wshub.Hub) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if hub == nil {
			writeErr(w, http.StatusServiceUnavailable, "websocket disabled")
			return
		}
		if !WSQueryAuth(s.Cfg.JWTSecret, r) {
			writeErr(w, http.StatusUnauthorized, "invalid token")
			return
		}
		hub.ServeWS(w, r)
	}
}

func (s *Server) withMetrics(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		next.ServeHTTP(w, r)
	})
}
