package api

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/paulmach/orb"
	"github.com/paulmach/orb/geojson"

	"ais/internal/model"
	"ais/internal/store"
)

// 补充 fakePositions 的 FenceHistoryVessels 实现（Task 9 的 fake 缺该方法）。
func (f *fakePositions) FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error) {
	return []uint32{111, 222}, f.err
}

type fakeGeofences struct {
	items []model.Geofence
	get   model.Geofence
	err   error
}

func (f *fakeGeofences) List(ctx context.Context) ([]model.Geofence, error) {
	return f.items, f.err
}
func (f *fakeGeofences) ListEnabled(ctx context.Context) ([]model.Geofence, error) {
	return f.items, f.err
}
func (f *fakeGeofences) Get(ctx context.Context, id int64) (model.Geofence, error) {
	if f.err != nil {
		return model.Geofence{}, f.err
	}
	if f.get.ID == 0 {
		return model.Geofence{}, store.ErrNotFound
	}
	return f.get, nil
}
func (f *fakeGeofences) Create(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	g.ID = 1
	return g, nil
}
func (f *fakeGeofences) Update(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	return g, nil
}
func (f *fakeGeofences) Delete(ctx context.Context, id int64) error {
	return nil
}
func (f *fakeGeofences) Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error) {
	return []model.FenceEvent{{ID: 1, FenceID: fenceID, MMSI: 111, EventType: model.EventTypeEnter, Ts: time.Now()}}, nil
}

func testFence() model.Geofence {
	return model.Geofence{
		ID:   9,
		Name: "港区",
		Area: geojson.Geometry{Coordinates: orb.Polygon{orb.Ring{
			{113.8, 22.4}, {114.0, 22.4}, {114.0, 22.6}, {113.8, 22.6}, {113.8, 22.4},
		}}},
		Enabled: true, EnterAlert: true, LeaveAlert: true,
		DebounceCount: 2, SilenceTimeoutMin: 5,
	}
}

func TestCreateGeofence_valid(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	body := `{"name":"港区","area":{"type":"Polygon","coordinates":[[[113.8,22.4],[114.0,22.4],[114.0,22.6],[113.8,22.6],[113.8,22.4]]]}}`
	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/api/v1/geofences", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("create status = %d, want 201", resp.StatusCode)
	}
	var g model.Geofence
	if err := json.NewDecoder(resp.Body).Decode(&g); err != nil {
		t.Fatal(err)
	}
	if g.ID != 1 || g.Name != "港区" || !g.Enabled {
		t.Errorf("created = %+v, want id 1, enabled", g)
	}
}

func TestCreateGeofence_invalidPolygon(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	// 未闭合多边形
	body := `{"name":"bad","area":{"type":"Polygon","coordinates":[[[0,0],[1,0],[1,1]]]}}`
	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/api/v1/geofences", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("invalid polygon status = %d, want 400", resp.StatusCode)
	}
}

func TestFenceCurrent_vesselsInside(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{get: testFence()},
		Latest: &fakeLatest{items: []model.Position{
			{MMSI: 1, Lat: 22.5, Lon: 113.9, Ts: time.Now()}, // 内部
			{MMSI: 2, Lat: 30.0, Lon: 120.0, Ts: time.Now()}, // 外部
		}},
		Log: testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	status, m := getJSON(t, ts.URL+"/api/v1/geofences/9/vessels/current", token)
	if status != http.StatusOK {
		t.Fatalf("fence current status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Fatalf("fence current items = %v, want 1 vessel inside", m["items"])
	}
}

func TestFenceHistory(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Positions: &fakePositions{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	status, m := getJSON(t, ts.URL+"/api/v1/geofences/9/vessels/history?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", token)
	if status != http.StatusOK {
		t.Fatalf("fence history status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 2 {
		t.Errorf("fence history items = %v, want 2 mmsi", m["items"])
	}
}

func TestFenceEvents(t *testing.T) {
	s := &Server{
		Cfg:       ServerConfig{JWTSecret: "s", JWTTTL: time.Hour},
		Geofences: &fakeGeofences{},
		Log:       testLogger(),
	}
	ts := newTestServer(t, s)
	token, _ := GenerateToken("s", model.User{ID: 1, Username: "u", Role: "user"}, time.Hour)

	status, m := getJSON(t, ts.URL+"/api/v1/geofences/9/events?start=2026-08-07T00:00:00Z&end=2026-08-07T01:00:00Z", token)
	if status != http.StatusOK {
		t.Fatalf("fence events status = %d, want 200", status)
	}
	items, ok := m["items"].([]any)
	if !ok || len(items) != 1 {
		t.Errorf("fence events items = %v, want 1 event", m["items"])
	}
}
