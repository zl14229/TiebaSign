package cache

import (
	"context"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"

	"ais/internal/model"
)

func newTestClient(t *testing.T) (*Client, *miniredis.Miniredis) {
	t.Helper()
	s := miniredis.RunT(t)
	return New(s.Addr(), ""), s
}

func TestSetAndAllLatest(t *testing.T) {
	c, _ := newTestClient(t)
	ctx := context.Background()
	p := model.Position{MMSI: 413123456, Ts: time.Now(), Lat: 22.5, Lon: 113.9, SOG: 10, COG: 90, Heading: 95, MsgType: 1, Source: "st1"}
	if err := c.SetLatest(ctx, p); err != nil {
		t.Fatalf("SetLatest() error = %v", err)
	}
	items, err := c.AllLatest(ctx)
	if err != nil {
		t.Fatalf("AllLatest() error = %v", err)
	}
	if len(items) != 1 {
		t.Fatalf("AllLatest() len = %d, want 1", len(items))
	}
	got := items[0]
	if got.MMSI != p.MMSI || got.Lat != p.Lat || got.Lon != p.Lon {
		t.Errorf("got %+v, want %+v", got, p)
	}
}

func TestFenceSet(t *testing.T) {
	c, _ := newTestClient(t)
	ctx := context.Background()
	if err := c.FenceAdd(ctx, 7, 111); err != nil {
		t.Fatal(err)
	}
	if err := c.FenceAdd(ctx, 7, 222); err != nil {
		t.Fatal(err)
	}
	members, err := c.FenceMembers(ctx, 7)
	if err != nil {
		t.Fatal(err)
	}
	if len(members) != 2 {
		t.Fatalf("FenceMembers() len = %d, want 2", len(members))
	}
	if err := c.FenceRemove(ctx, 7, 111); err != nil {
		t.Fatal(err)
	}
	members, _ = c.FenceMembers(ctx, 7)
	if len(members) != 1 || members[0] != 222 {
		t.Errorf("FenceMembers() after remove = %v, want [222]", members)
	}
	if err := c.ClearFence(ctx, 7); err != nil {
		t.Fatal(err)
	}
	members, _ = c.FenceMembers(ctx, 7)
	if len(members) != 0 {
		t.Errorf("FenceMembers() after clear = %v, want empty", members)
	}
}

func TestPublishSubscribePositions(t *testing.T) {
	c, _ := newTestClient(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	ch, errc := c.SubscribePositions(ctx)

	time.Sleep(50 * time.Millisecond) // 等待订阅就绪
	p := model.Position{MMSI: 999, Ts: time.Now(), Lat: 1, Lon: 2}
	if err := c.PublishPosition(ctx, p); err != nil {
		t.Fatalf("PublishPosition() error = %v", err)
	}
	select {
	case got := <-ch:
		if got.MMSI != 999 {
			t.Errorf("received MMSI = %d, want 999", got.MMSI)
		}
	case err := <-errc:
		t.Fatalf("subscription error: %v", err)
	case <-time.After(3 * time.Second):
		t.Fatal("timeout waiting for published position")
	}
}
