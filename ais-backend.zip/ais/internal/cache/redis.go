// Package cache provides the Redis-backed latest-position snapshot,
// fence membership sets and pub/sub channels.
package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/redis/go-redis/v9"

	"ais/internal/model"
)

const (
	latestKey    = "ais:latest"
	channelPos   = "ais:positions"
	channelEvent = "ais:fence-events"
)

func fenceSetKey(id int64) string {
	return fmt.Sprintf("ais:fence:%d", id)
}

type Cache interface {
	SetLatest(ctx context.Context, p model.Position) error
	AllLatest(ctx context.Context) ([]model.Position, error)
	FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error
	FenceMembers(ctx context.Context, fenceID int64) ([]uint32, error)
	ClearFence(ctx context.Context, fenceID int64) error
	PublishPosition(ctx context.Context, p model.Position) error
	SubscribePositions(ctx context.Context) (<-chan model.Position, <-chan error)
	PublishFenceEvent(ctx context.Context, e model.FenceEvent) error
	SubscribeFenceEvents(ctx context.Context) (<-chan model.FenceEvent, <-chan error)
	Close() error
}

type Client struct {
	rdb *redis.Client
}

func New(addr, password string) *Client {
	return &Client{rdb: redis.NewClient(&redis.Options{Addr: addr, Password: password})}
}

func (c *Client) Ping(ctx context.Context) error {
	return c.rdb.Ping(ctx).Err()
}

func (c *Client) Close() error {
	return c.rdb.Close()
}

func (c *Client) SetLatest(ctx context.Context, p model.Position) error {
	b, err := json.Marshal(p)
	if err != nil {
		return err
	}
	return c.rdb.HSet(ctx, latestKey, strconv.FormatUint(uint64(p.MMSI), 10), b).Err()
}

func (c *Client) AllLatest(ctx context.Context) ([]model.Position, error) {
	m, err := c.rdb.HGetAll(ctx, latestKey).Result()
	if err != nil {
		return nil, err
	}
	out := make([]model.Position, 0, len(m))
	for _, v := range m {
		var p model.Position
		if err := json.Unmarshal([]byte(v), &p); err != nil {
			continue
		}
		out = append(out, p)
	}
	return out, nil
}

func (c *Client) FenceAdd(ctx context.Context, fenceID int64, mmsi uint32) error {
	return c.rdb.SAdd(ctx, fenceSetKey(fenceID), strconv.FormatUint(uint64(mmsi), 10)).Err()
}

func (c *Client) FenceRemove(ctx context.Context, fenceID int64, mmsi uint32) error {
	return c.rdb.SRem(ctx, fenceSetKey(fenceID), strconv.FormatUint(uint64(mmsi), 10)).Err()
}

func (c *Client) FenceMembers(ctx context.Context, fenceID int64) ([]uint32, error) {
	raw, err := c.rdb.SMembers(ctx, fenceSetKey(fenceID)).Result()
	if err != nil {
		return nil, err
	}
	out := make([]uint32, 0, len(raw))
	for _, s := range raw {
		v, err := strconv.ParseUint(s, 10, 32)
		if err != nil {
			continue
		}
		out = append(out, uint32(v))
	}
	return out, nil
}

func (c *Client) ClearFence(ctx context.Context, fenceID int64) error {
	return c.rdb.Del(ctx, fenceSetKey(fenceID)).Err()
}

func (c *Client) PublishPosition(ctx context.Context, p model.Position) error {
	b, err := json.Marshal(p)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channelPos, b).Err()
}

func (c *Client) SubscribePositions(ctx context.Context) (<-chan model.Position, <-chan error) {
	ch := make(chan model.Position, 256)
	errc := make(chan error, 1)
	sub := c.rdb.Subscribe(ctx, channelPos)
	go func() {
		defer sub.Close()
		for {
			msg, err := sub.ReceiveMessage(ctx)
			if err != nil {
				errc <- err
				return
			}
			var p model.Position
			if err := json.Unmarshal([]byte(msg.Payload), &p); err != nil {
				continue
			}
			ch <- p
		}
	}()
	return ch, errc
}

func (c *Client) PublishFenceEvent(ctx context.Context, e model.FenceEvent) error {
	b, err := json.Marshal(e)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channelEvent, b).Err()
}

func (c *Client) SubscribeFenceEvents(ctx context.Context) (<-chan model.FenceEvent, <-chan error) {
	ch := make(chan model.FenceEvent, 256)
	errc := make(chan error, 1)
	sub := c.rdb.Subscribe(ctx, channelEvent)
	go func() {
		defer sub.Close()
		for {
			msg, err := sub.ReceiveMessage(ctx)
			if err != nil {
				errc <- err
				return
			}
			var e model.FenceEvent
			if err := json.Unmarshal([]byte(msg.Payload), &e); err != nil {
				continue
			}
			ch <- e
		}
	}()
	return ch, errc
}
