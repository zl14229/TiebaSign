// Package model defines the shared domain types used across all packages.
package model

import (
	"time"

	"github.com/paulmach/orb/geojson"
)

type Position struct {
	MMSI      uint32    `json:"mmsi"`
	Ts        time.Time `json:"ts"`
	Lat       float64   `json:"lat"`
	Lon       float64   `json:"lon"`
	SOG       float32   `json:"sog"`
	COG       float32   `json:"cog"`
	Heading   int16     `json:"heading"`
	NavStatus int16     `json:"nav_status"`
	MsgType   int16     `json:"msg_type"`
	Source    string    `json:"source"`
}

type Vessel struct {
	MMSI      uint32    `json:"mmsi"`
	Name      string    `json:"name"`
	IMO       *uint32   `json:"imo"`
	Callsign  string    `json:"callsign"`
	ShipType  int16     `json:"ship_type"`
	LengthM   float32   `json:"length_m"`
	BeamM     float32   `json:"beam_m"`
	UpdatedAt time.Time `json:"updated_at"`
}

type TrackPoint struct {
	Ts  time.Time `json:"ts"`
	Lat float64   `json:"lat"`
	Lon float64   `json:"lon"`
	SOG float32   `json:"sog"`
}

type Geofence struct {
	ID                int64            `json:"id"`
	Name              string           `json:"name"`
	Area              geojson.Geometry `json:"area"`
	Enabled           bool             `json:"enabled"`
	EnterAlert        bool             `json:"enter_alert"`
	LeaveAlert        bool             `json:"leave_alert"`
	DebounceCount     int              `json:"debounce_count"`
	SilenceTimeoutMin int              `json:"silence_timeout_min"`
	CreatedAt         time.Time        `json:"created_at"`
}

const (
	EventTypeEnter int16 = 1
	EventTypeLeave int16 = 2
)

type FenceEvent struct {
	ID        int64     `json:"id"`
	FenceID   int64     `json:"fence_id"`
	MMSI      uint32    `json:"mmsi"`
	EventType int16     `json:"event_type"`
	Ts        time.Time `json:"ts"`
	Lat       float64   `json:"lat"`
	Lon       float64   `json:"lon"`
}

type User struct {
	ID           int64     `json:"id"`
	Username     string    `json:"username"`
	PasswordHash string    `json:"-"`
	Role         string    `json:"role"`
	CreatedAt    time.Time `json:"created_at"`
}

type BaseStation struct {
	ID      int64  `json:"id"`
	Name    string `json:"name"`
	Host    string `json:"host"`
	Port    int    `json:"port"`
	Enabled bool   `json:"enabled"`
}
