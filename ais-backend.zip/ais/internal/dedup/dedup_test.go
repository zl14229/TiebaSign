package dedup

import (
	"testing"
	"time"
)

func TestCheckAndAdd_duplicateWithinWindow(t *testing.T) {
	d := New(30*time.Second, 1000)
	now := time.Now()
	if d.CheckAndAdd("a", now) {
		t.Fatal("first occurrence should not be a duplicate")
	}
	if !d.CheckAndAdd("a", now.Add(5*time.Second)) {
		t.Fatal("second occurrence within window should be a duplicate")
	}
}

func TestCheckAndAdd_expiredAfterWindow(t *testing.T) {
	d := New(30*time.Second, 1000)
	now := time.Now()
	d.CheckAndAdd("a", now)
	if d.CheckAndAdd("a", now.Add(31*time.Second)) {
		t.Fatal("occurrence after window should not be a duplicate")
	}
}

func TestCheckAndAdd_distinctKeysNotDeduped(t *testing.T) {
	d := New(30*time.Second, 1000)
	now := time.Now()
	if d.CheckAndAdd("a", now) || d.CheckAndAdd("b", now) {
		t.Fatal("distinct keys must not be treated as duplicates")
	}
}

func TestCheckAndAdd_evictsOldestWhenFull(t *testing.T) {
	d := New(30*time.Second, 2)
	now := time.Now()
	d.CheckAndAdd("k1", now)
	d.CheckAndAdd("k2", now)
	// 触发淘汰
	if d.CheckAndAdd("k3", now) {
		t.Fatal("adding a new key should succeed")
	}
	// 被淘汰的 k1 再次出现不算重复
	if d.CheckAndAdd("k1", now.Add(1*time.Second)) {
		t.Fatal("evicted key should be re-insertable")
	}
}
