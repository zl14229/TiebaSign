// Package dedup provides a time-windowed in-memory duplicate detector.
package dedup

import (
	"sync"
	"time"
)

type Dedup struct {
	mu         sync.Mutex
	window     time.Duration
	maxEntries int
	seen       map[string]time.Time
}

func New(window time.Duration, maxEntries int) *Dedup {
	return &Dedup{window: window, maxEntries: maxEntries, seen: make(map[string]time.Time)}
}

// CheckAndAdd reports whether key was already seen within the window and
// records it. Returns true when the message is a duplicate.
func (d *Dedup) CheckAndAdd(key string, now time.Time) bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	cutoff := now.Add(-d.window)
	if first, ok := d.seen[key]; ok && first.After(cutoff) {
		return true
	}
	d.seen[key] = now
	if len(d.seen) > d.maxEntries {
		for k, first := range d.seen {
			if first.Before(cutoff) {
				delete(d.seen, k)
			}
		}
		if len(d.seen) > d.maxEntries {
			var oldestKey string
			var oldest time.Time
			for k, first := range d.seen {
				if oldestKey == "" || first.Before(oldest) {
					oldestKey, oldest = k, first
				}
			}
			delete(d.seen, oldestKey)
		}
	}
	return false
}
