// Package pipeline wires a station NMEA line into the dedup / persistence /
// snapshot / broadcast / geofence stages.
package pipeline

import (
	"context"
	"fmt"
	"hash/fnv"
	"log/slog"
	"sync"
	"time"

	"ais/internal/dedup"
	"ais/internal/metrics"
	"ais/internal/model"
	"ais/internal/nmea"
)

type Writer interface {
	Enqueue(p model.Position) error
}

type LatestSetter interface {
	SetLatest(ctx context.Context, p model.Position) error
}

type PositionPublisher interface {
	PublishPosition(ctx context.Context, p model.Position) error
}

type PositionConsumer interface {
	OnPosition(ctx context.Context, p model.Position)
}

type VesselUpserter interface {
	Upsert(ctx context.Context, v model.Vessel) error
}

type PipelineOptions struct {
	Writer      Writer
	Latest      LatestSetter
	Publisher   PositionPublisher
	Engine      PositionConsumer
	VesselStore VesselUpserter
	Dedup       *dedup.Dedup
}

type Pipeline struct {
	mu      sync.Mutex
	parsers map[string]*nmea.Parser
	opts    PipelineOptions
	log     *slog.Logger
}

func New(opts PipelineOptions, log *slog.Logger) *Pipeline {
	return &Pipeline{parsers: map[string]*nmea.Parser{}, opts: opts, log: log}
}

// OnLine implements station.Handler.
func (p *Pipeline) OnLine(stationID, line string) {
	p.mu.Lock()
	parser := p.parsers[stationID]
	if parser == nil {
		parser = nmea.NewParser()
		p.parsers[stationID] = parser
	}
	p.mu.Unlock()

	now := time.Now()
	res, err := parser.Parse(line, stationID, now)
	if err != nil {
		metrics.ParseErrors.Inc()
		p.log.Warn("nmea parse failed", "station", stationID, "err", err)
		return
	}
	if res == nil {
		return
	}
	ctx := context.Background()
	if res.Position != nil {
		if p.opts.Dedup.CheckAndAdd(positionKey(*res.Position, line), now) {
			metrics.Deduped.Inc()
			return
		}
		metrics.MsgsParsed.Inc()
		pos := *res.Position
		if err := p.opts.Writer.Enqueue(pos); err != nil {
			p.log.Warn("enqueue position failed", "mmsi", pos.MMSI, "err", err)
		}
		_ = p.opts.Latest.SetLatest(ctx, pos)
		_ = p.opts.Publisher.PublishPosition(ctx, pos)
		p.opts.Engine.OnPosition(ctx, pos)
	}
	if res.Vessel != nil {
		if err := p.opts.VesselStore.Upsert(ctx, *res.Vessel); err != nil {
			p.log.Warn("vessel upsert failed", "mmsi", res.Vessel.MMSI, "err", err)
		}
	}
}

// OnStatus implements station.Handler.
func (p *Pipeline) OnStatus(stationID string, connected bool, err error) {
	if connected {
		p.log.Info("station connected", "station", stationID)
	} else {
		p.log.Warn("station disconnected", "station", stationID, "err", err)
	}
}

func positionKey(p model.Position, raw string) string {
	h := fnv.New32a()
	_, _ = h.Write([]byte(raw))
	return fmt.Sprintf("%d:%d:%x", p.MMSI, p.Ts.Unix(), h.Sum32())
}
