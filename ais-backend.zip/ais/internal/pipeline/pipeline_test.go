package pipeline

import (
	"context"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"ais/internal/dedup"
	"ais/internal/model"
)

const (
	sentenceType1  = "!AIVDM,1,1,,B,177KQJ5000G?tO`K>RA1wUbN0TKH,0*5C"
	sentenceType5A = "!AIVDM,2,1,6,B,53Jmvl82Bw3CTP7??K5<D5<lThF222222222221:I0oK;4e20L3FH42i,0*5C"
	sentenceType5B = "!AIVDM,2,2,6,B,p88888888888880,2*69"
)

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

type fakeWriter struct {
	mu    sync.Mutex
	items []model.Position
	err   error
}

func (f *fakeWriter) Enqueue(p model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.err != nil {
		return f.err
	}
	f.items = append(f.items, p)
	return nil
}

func (f *fakeWriter) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

type fakeLatest struct {
	mu    sync.Mutex
	items []model.Position
}

func (f *fakeLatest) SetLatest(_ context.Context, p model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, p)
	return nil
}

type fakePublisher struct {
	mu    sync.Mutex
	items []model.Position
}

func (f *fakePublisher) PublishPosition(_ context.Context, p model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, p)
	return nil
}

func (f *fakePublisher) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

type fakeEngine struct {
	mu    sync.Mutex
	items []model.Position
}

func (f *fakeEngine) OnPosition(_ context.Context, p model.Position) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, p)
}

func (f *fakeEngine) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

type fakeVessels struct {
	mu    sync.Mutex
	items []model.Vessel
}

func (f *fakeVessels) Upsert(_ context.Context, v model.Vessel) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.items = append(f.items, v)
	return nil
}

func (f *fakeVessels) count() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.items)
}

func newTestPipeline() (*Pipeline, *fakeWriter, *fakePublisher, *fakeEngine, *fakeVessels) {
	w := &fakeWriter{}
	pub := &fakePublisher{}
	eng := &fakeEngine{}
	ves := &fakeVessels{}
	pipe := New(PipelineOptions{
		Writer:      w,
		Latest:      &fakeLatest{},
		Publisher:   pub,
		Engine:      eng,
		VesselStore: ves,
		Dedup:       dedup.New(30*time.Second, 100000),
	}, discardLogger())
	return pipe, w, pub, eng, ves
}

func TestPipeline_positionMessageFansOut(t *testing.T) {
	pipe, w, pub, eng, _ := newTestPipeline()
	pipe.OnLine("st1", sentenceType1)
	if w.count() != 1 {
		t.Errorf("writer received %d, want 1", w.count())
	}
	if pub.count() != 1 {
		t.Errorf("publisher received %d, want 1", pub.count())
	}
	if eng.count() != 1 {
		t.Errorf("engine received %d, want 1", eng.count())
	}
	w.mu.Lock()
	got := w.items[0]
	w.mu.Unlock()
	if got.MMSI != 477553000 {
		t.Errorf("MMSI = %d, want 477553000", got.MMSI)
	}
}

func TestPipeline_duplicateDropped(t *testing.T) {
	pipe, w, _, _, _ := newTestPipeline()
	pipe.OnLine("st1", sentenceType1)
	pipe.OnLine("st1", sentenceType1)
	if w.count() != 1 {
		t.Errorf("writer received %d, want 1 (duplicate dropped)", w.count())
	}
}

func TestPipeline_vesselMessageUpserts(t *testing.T) {
	pipe, w, _, _, ves := newTestPipeline()
	pipe.OnLine("st1", sentenceType5A)
	pipe.OnLine("st1", sentenceType5B)
	if w.count() != 0 {
		t.Errorf("writer received %d, want 0 (static message)", w.count())
	}
	if ves.count() != 1 {
		t.Errorf("vessel upserts = %d, want 1", ves.count())
	}
}
