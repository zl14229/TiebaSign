package config

import (
	"os"
	"strings"
	"testing"
	"time"
)

func clearAISEnv(t *testing.T) {
	t.Helper()
	for _, kv := range os.Environ() {
		k := kv[:strings.Index(kv, "=")]
		if strings.HasPrefix(k, "AIS_") {
			os.Unsetenv(k)
		}
	}
}

func TestLoad_defaults(t *testing.T) {
	clearAISEnv(t)
	c, err := Load()
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if c.HTTPAddr != "0.0.0.0:8080" {
		t.Errorf("HTTPAddr = %q, want 0.0.0.0:8080", c.HTTPAddr)
	}
	if c.RetentionDays != 30 {
		t.Errorf("RetentionDays = %d, want 30", c.RetentionDays)
	}
	if c.WriterBatchSize != 1000 {
		t.Errorf("WriterBatchSize = %d, want 1000", c.WriterBatchSize)
	}
	if c.WriterFlushInterval != time.Second {
		t.Errorf("WriterFlushInterval = %v, want 1s", c.WriterFlushInterval)
	}
	if c.FenceDebounceCount != 2 {
		t.Errorf("FenceDebounceCount = %d, want 2", c.FenceDebounceCount)
	}
	if c.FenceSilenceTimeout != 5*time.Minute {
		t.Errorf("FenceSilenceTimeout = %v, want 5m", c.FenceSilenceTimeout)
	}
	if len(c.Stations) != 0 {
		t.Errorf("Stations = %v, want empty", c.Stations)
	}
}

func TestLoad_envOverrides(t *testing.T) {
	clearAISEnv(t)
	t.Setenv("AIS_HTTP_ADDR", ":9999")
	t.Setenv("AIS_JWT_TTL", "2h")
	t.Setenv("AIS_RETENTION_DAYS", "45")
	t.Setenv("AIS_STATIONS", `[{"id":"s1","name":"n","host":"1.2.3.4","port":4001,"enabled":true}]`)
	c, err := Load()
	if err != nil {
		t.Fatalf("Load() error = %v", err)
	}
	if c.HTTPAddr != ":9999" {
		t.Errorf("HTTPAddr = %q, want :9999", c.HTTPAddr)
	}
	if c.JWTTTL != 2*time.Hour {
		t.Errorf("JWTTTL = %v, want 2h", c.JWTTTL)
	}
	if c.RetentionDays != 45 {
		t.Errorf("RetentionDays = %d, want 45", c.RetentionDays)
	}
	if len(c.Stations) != 1 || c.Stations[0].Host != "1.2.3.4" {
		t.Errorf("Stations = %+v, want one station with host 1.2.3.4", c.Stations)
	}
}

func TestLoad_invalidDuration(t *testing.T) {
	clearAISEnv(t)
	t.Setenv("AIS_JWT_TTL", "not-a-duration")
	if _, err := Load(); err == nil {
		t.Fatal("Load() expected error for invalid AIS_JWT_TTL")
	}
}
