// Package config loads all runtime configuration from AIS_* environment variables.
package config

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"
)

type Station struct {
	ID      string `json:"id"`
	Name    string `json:"name"`
	Host    string `json:"host"`
	Port    int    `json:"port"`
	Enabled bool   `json:"enabled"`
}

type Config struct {
	HTTPAddr              string
	LogLevel              string
	DBURL                 string
	RedisAddr             string
	RedisPassword         string
	JWTSecret             string
	JWTTTL                time.Duration
	Stations              []Station
	WriterFlushInterval   time.Duration
	WriterBatchSize       int
	WriterQueueSize       int
	RetentionDays         int
	FenceReloadInterval   time.Duration
	FenceSilenceTimeout   time.Duration
	FenceDebounceCount    int
	StationConnectTimeout time.Duration
	StationReconnectBase  time.Duration
	StationReconnectMax   time.Duration
	StationIdleTimeout    time.Duration
	MetricsAddr           string
}

func Load() (Config, error) {
	c := Config{
		HTTPAddr:              "0.0.0.0:8080",
		LogLevel:              "info",
		DBURL:                 "postgres://ais:ais@localhost:5432/ais?sslmode=disable",
		RedisAddr:             "localhost:6379",
		JWTSecret:             "dev-secret-change-me",
		JWTTTL:                24 * time.Hour,
		WriterFlushInterval:   time.Second,
		WriterBatchSize:       1000,
		WriterQueueSize:       100000,
		RetentionDays:         30,
		FenceReloadInterval:   time.Minute,
		FenceSilenceTimeout:   5 * time.Minute,
		FenceDebounceCount:    2,
		StationConnectTimeout: 10 * time.Second,
		StationReconnectBase:  time.Second,
		StationReconnectMax:   60 * time.Second,
		StationIdleTimeout:    5 * time.Minute,
		MetricsAddr:           "0.0.0.0:9090",
	}
	var err error
	if v := os.Getenv("AIS_HTTP_ADDR"); v != "" {
		c.HTTPAddr = v
	}
	if v := os.Getenv("AIS_LOG_LEVEL"); v != "" {
		c.LogLevel = v
	}
	if v := os.Getenv("AIS_DB_URL"); v != "" {
		c.DBURL = v
	}
	if v := os.Getenv("AIS_REDIS_ADDR"); v != "" {
		c.RedisAddr = v
	}
	if v := os.Getenv("AIS_REDIS_PASSWORD"); v != "" {
		c.RedisPassword = v
	}
	if v := os.Getenv("AIS_JWT_SECRET"); v != "" {
		c.JWTSecret = v
	}
	if v := os.Getenv("AIS_JWT_TTL"); v != "" {
		if c.JWTTTL, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_JWT_TTL: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATIONS"); v != "" {
		if err := json.Unmarshal([]byte(v), &c.Stations); err != nil {
			return c, fmt.Errorf("AIS_STATIONS: %w", err)
		}
	}
	if v := os.Getenv("AIS_WRITER_FLUSH_INTERVAL"); v != "" {
		if c.WriterFlushInterval, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_WRITER_FLUSH_INTERVAL: %w", err)
		}
	}
	if v := os.Getenv("AIS_WRITER_BATCH_SIZE"); v != "" {
		if c.WriterBatchSize, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_WRITER_BATCH_SIZE: %w", err)
		}
	}
	if v := os.Getenv("AIS_WRITER_QUEUE_SIZE"); v != "" {
		if c.WriterQueueSize, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_WRITER_QUEUE_SIZE: %w", err)
		}
	}
	if v := os.Getenv("AIS_RETENTION_DAYS"); v != "" {
		if c.RetentionDays, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_RETENTION_DAYS: %w", err)
		}
	}
	if v := os.Getenv("AIS_FENCE_RELOAD_INTERVAL"); v != "" {
		if c.FenceReloadInterval, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_FENCE_RELOAD_INTERVAL: %w", err)
		}
	}
	if v := os.Getenv("AIS_FENCE_SILENCE_TIMEOUT"); v != "" {
		if c.FenceSilenceTimeout, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_FENCE_SILENCE_TIMEOUT: %w", err)
		}
	}
	if v := os.Getenv("AIS_FENCE_DEBOUNCE_COUNT"); v != "" {
		if c.FenceDebounceCount, err = strconv.Atoi(v); err != nil {
			return c, fmt.Errorf("AIS_FENCE_DEBOUNCE_COUNT: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_CONNECT_TIMEOUT"); v != "" {
		if c.StationConnectTimeout, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_CONNECT_TIMEOUT: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_RECONNECT_BASE"); v != "" {
		if c.StationReconnectBase, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_RECONNECT_BASE: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_RECONNECT_MAX"); v != "" {
		if c.StationReconnectMax, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_RECONNECT_MAX: %w", err)
		}
	}
	if v := os.Getenv("AIS_STATION_IDLE_TIMEOUT"); v != "" {
		if c.StationIdleTimeout, err = time.ParseDuration(v); err != nil {
			return c, fmt.Errorf("AIS_STATION_IDLE_TIMEOUT: %w", err)
		}
	}
	if v := os.Getenv("AIS_METRICS_ADDR"); v != "" {
		c.MetricsAddr = v
	}
	return c, nil
}
