// Package metrics registers Prometheus metrics used by the whole service.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	MsgsParsed = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_messages_parsed_total",
		Help: "Total AIS messages decoded into positions.",
	})
	ParseErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_messages_parse_errors_total",
		Help: "Total NMEA sentences that failed to parse.",
	})
	Deduped = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_messages_deduped_total",
		Help: "Total duplicate messages dropped by the dedup window.",
	})
	FenceEvents = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "ais_fence_events_total",
		Help: "Fence events emitted, by type.",
	}, []string{"type"})
	WSConnections = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "ais_ws_connections",
		Help: "Current number of connected WebSocket clients.",
	})
	FlushFailures = promauto.NewCounter(prometheus.CounterOpts{
		Name: "ais_writer_flush_failures_total",
		Help: "Total batches dropped after failed retry in the position writer.",
	})
)
