CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE ais_positions (
  mmsi BIGINT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  lat DOUBLE PRECISION NOT NULL,
  lon DOUBLE PRECISION NOT NULL,
  sog REAL NOT NULL DEFAULT 0,
  cog REAL NOT NULL DEFAULT 0,
  heading SMALLINT NOT NULL DEFAULT 511,
  nav_status SMALLINT NOT NULL DEFAULT 0,
  msg_type SMALLINT NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT '',
  geom geometry(Point, 4326) GENERATED ALWAYS AS
    (ST_SetSRID(ST_MakePoint(lon, lat), 4326)) STORED
) PARTITION BY RANGE (ts);

CREATE INDEX idx_ais_positions_mmsi_ts ON ais_positions (mmsi, ts);
CREATE INDEX idx_ais_positions_geom ON ais_positions USING GIST (geom);

CREATE TABLE geofences (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  area geometry(Polygon, 4326) NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true,
  enter_alert BOOLEAN NOT NULL DEFAULT true,
  leave_alert BOOLEAN NOT NULL DEFAULT true,
  debounce_count SMALLINT NOT NULL DEFAULT 2,
  silence_timeout_min INT NOT NULL DEFAULT 5,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_geofences_area ON geofences USING GIST (area);
CREATE INDEX idx_geofences_enabled ON geofences (enabled) WHERE enabled;

CREATE TABLE fence_events (
  id BIGSERIAL PRIMARY KEY,
  fence_id BIGINT NOT NULL REFERENCES geofences(id) ON DELETE CASCADE,
  mmsi BIGINT NOT NULL,
  event_type SMALLINT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION
);
CREATE INDEX idx_fence_events_fence_ts ON fence_events (fence_id, ts);
CREATE INDEX idx_fence_events_mmsi_ts ON fence_events (mmsi, ts);

CREATE TABLE vessels (
  mmsi BIGINT PRIMARY KEY,
  name TEXT NOT NULL DEFAULT '',
  imo BIGINT,
  callsign TEXT NOT NULL DEFAULT '',
  ship_type SMALLINT NOT NULL DEFAULT 0,
  length_m REAL NOT NULL DEFAULT 0,
  beam_m REAL NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE base_stations (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  host TEXT NOT NULL,
  port INT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true
);
