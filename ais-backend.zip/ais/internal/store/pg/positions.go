package pg

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Positions struct {
	pool *pgxpool.Pool
}

func NewPositions(pool *pgxpool.Pool) *Positions {
	return &Positions{pool: pool}
}

var _ store.PositionStore = (*Positions)(nil)

func (p *Positions) InsertBatch(ctx context.Context, rows []model.Position) error {
	if len(rows) == 0 {
		return nil
	}
	days := map[string]struct{}{}
	for _, r := range rows {
		days[PartitionName(r.Ts)] = struct{}{}
	}
	for day := range days {
		t, err := time.Parse("20060102", day)
		if err != nil {
			return err
		}
		if err := EnsurePartition(ctx, p.pool, t); err != nil {
			return err
		}
	}
	batch := &pgx.Batch{}
	for _, r := range rows {
		batch.Queue(`INSERT INTO ais_positions (mmsi, ts, lat, lon, sog, cog, heading, nav_status, msg_type, source)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
			r.MMSI, r.Ts, r.Lat, r.Lon, r.SOG, r.COG, r.Heading, r.NavStatus, r.MsgType, r.Source)
	}
	br := p.pool.SendBatch(ctx, batch)
	defer br.Close()
	for range rows {
		if _, err := br.Exec(); err != nil {
			return fmt.Errorf("insert position: %w", err)
		}
	}
	return nil
}

func (p *Positions) Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error) {
	var rows pgx.Rows
	var err error
	if bucketSec > 1 {
		rows, err = p.pool.Query(ctx, `
			SELECT to_timestamp(floor(extract(epoch FROM ts) / $4) * $4) AS bucket,
			       avg(lat)::float8, avg(lon)::float8, max(sog)::float4
			FROM ais_positions
			WHERE mmsi = $1 AND ts >= $2 AND ts <= $3
			GROUP BY 1 ORDER BY 1 LIMIT $5`,
			mmsi, start, end, bucketSec, limit)
	} else {
		rows, err = p.pool.Query(ctx, `
			SELECT ts, lat, lon, sog
			FROM ais_positions
			WHERE mmsi = $1 AND ts >= $2 AND ts <= $3
			ORDER BY ts LIMIT $4`,
			mmsi, start, end, limit)
	}
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	pts := []model.TrackPoint{}
	for rows.Next() {
		var tp model.TrackPoint
		if err := rows.Scan(&tp.Ts, &tp.Lat, &tp.Lon, &tp.SOG); err != nil {
			return nil, err
		}
		pts = append(pts, tp)
	}
	return pts, rows.Err()
}

func (p *Positions) LatestFallback(ctx context.Context) ([]model.Position, error) {
	rows, err := p.pool.Query(ctx, `
		SELECT DISTINCT ON (mmsi) mmsi, ts, lat, lon, sog, cog, heading, nav_status, msg_type, source
		FROM ais_positions
		ORDER BY mmsi, ts DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []model.Position{}
	for rows.Next() {
		var pos model.Position
		if err := rows.Scan(&pos.MMSI, &pos.Ts, &pos.Lat, &pos.Lon, &pos.SOG, &pos.COG,
			&pos.Heading, &pos.NavStatus, &pos.MsgType, &pos.Source); err != nil {
			return nil, err
		}
		out = append(out, pos)
	}
	return out, rows.Err()
}

func (p *Positions) FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error) {
	rows, err := p.pool.Query(ctx, `
		SELECT DISTINCT mmsi
		FROM ais_positions
		WHERE ts >= $2 AND ts < $3
		  AND ST_Intersects(geom, (SELECT area FROM geofences WHERE id = $1))
		ORDER BY mmsi`,
		fenceID, start, end)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []uint32{}
	for rows.Next() {
		var mmsi uint32
		if err := rows.Scan(&mmsi); err != nil {
			return nil, err
		}
		out = append(out, mmsi)
	}
	return out, rows.Err()
}
