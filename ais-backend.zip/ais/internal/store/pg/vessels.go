package pg

import (
	"context"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Vessels struct {
	pool *pgxpool.Pool
}

func NewVessels(pool *pgxpool.Pool) *Vessels {
	return &Vessels{pool: pool}
}

var _ store.VesselStore = (*Vessels)(nil)

func (s *Vessels) Upsert(ctx context.Context, v model.Vessel) error {
	_, err := s.pool.Exec(ctx, `
		INSERT INTO vessels (mmsi, name, imo, callsign, ship_type, length_m, beam_m, updated_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
		ON CONFLICT (mmsi) DO UPDATE SET
			name      = COALESCE(NULLIF(EXCLUDED.name, ''), vessels.name),
			imo       = COALESCE(EXCLUDED.imo, vessels.imo),
			callsign  = COALESCE(NULLIF(EXCLUDED.callsign, ''), vessels.callsign),
			ship_type = CASE WHEN EXCLUDED.ship_type <> 0 THEN EXCLUDED.ship_type ELSE vessels.ship_type END,
			length_m  = CASE WHEN EXCLUDED.length_m > 0 THEN EXCLUDED.length_m ELSE vessels.length_m END,
			beam_m    = CASE WHEN EXCLUDED.beam_m > 0 THEN EXCLUDED.beam_m ELSE vessels.beam_m END,
			updated_at = EXCLUDED.updated_at`,
		v.MMSI, v.Name, v.IMO, v.Callsign, v.ShipType, v.LengthM, v.BeamM, v.UpdatedAt)
	return err
}

func (s *Vessels) List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error) {
	var total int64
	if search != "" {
		like := "%" + search + "%"
		if err := s.pool.QueryRow(ctx,
			`SELECT count(*) FROM vessels WHERE name ILIKE $1 OR callsign ILIKE $1`, like).Scan(&total); err != nil {
			return nil, 0, err
		}
		rows, err := s.pool.Query(ctx, `
			SELECT mmsi, name, imo, callsign, ship_type, length_m, beam_m, updated_at
			FROM vessels WHERE name ILIKE $1 OR callsign ILIKE $1
			ORDER BY mmsi LIMIT $2 OFFSET $3`, like, pageSize, (page-1)*pageSize)
		if err != nil {
			return nil, 0, err
		}
		out, _, err := scanVessels(rows)
		return out, total, err
	}
	if err := s.pool.QueryRow(ctx, `SELECT count(*) FROM vessels`).Scan(&total); err != nil {
		return nil, 0, err
	}
	rows, err := s.pool.Query(ctx, `
		SELECT mmsi, name, imo, callsign, ship_type, length_m, beam_m, updated_at
		FROM vessels ORDER BY mmsi LIMIT $1 OFFSET $2`, pageSize, (page-1)*pageSize)
	if err != nil {
		return nil, 0, err
	}
	out, _, err := scanVessels(rows)
	return out, total, err
}

func scanVessels(rows pgx.Rows) ([]model.Vessel, int64, error) {
	defer rows.Close()
	var out []model.Vessel
	for rows.Next() {
		var v model.Vessel
		if err := rows.Scan(&v.MMSI, &v.Name, &v.IMO, &v.Callsign, &v.ShipType, &v.LengthM, &v.BeamM, &v.UpdatedAt); err != nil {
			return nil, 0, err
		}
		out = append(out, v)
	}
	return out, 0, rows.Err()
}
