package pg

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Users struct {
	pool *pgxpool.Pool
}

func NewUsers(pool *pgxpool.Pool) *Users {
	return &Users{pool: pool}
}

var _ store.UserStore = (*Users)(nil)

func (s *Users) Create(ctx context.Context, username, passwordHash, role string) (model.User, error) {
	var u model.User
	err := s.pool.QueryRow(ctx, `
		INSERT INTO users (username, password_hash, role)
		VALUES ($1,$2,$3)
		RETURNING id, username, password_hash, role, created_at`,
		username, passwordHash, role).Scan(&u.ID, &u.Username, &u.PasswordHash, &u.Role, &u.CreatedAt)
	return u, err
}

func (s *Users) GetByUsername(ctx context.Context, username string) (model.User, error) {
	var u model.User
	err := s.pool.QueryRow(ctx, `
		SELECT id, username, password_hash, role, created_at
		FROM users WHERE username = $1`, username).Scan(&u.ID, &u.Username, &u.PasswordHash, &u.Role, &u.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return u, store.ErrNotFound
	}
	return u, err
}
