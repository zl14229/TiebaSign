package pg

import (
	"context"
	"io"
	"log/slog"
	"sync"
	"testing"
	"time"

	"ais/internal/model"
)

type fakeInserter struct {
	mu    sync.Mutex
	calls [][]model.Position
	fail  bool
}

func (f *fakeInserter) InsertBatch(_ context.Context, rows []model.Position) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.fail {
		return io.ErrClosedPipe
	}
	f.calls = append(f.calls, append([]model.Position(nil), rows...))
	return nil
}

func (f *fakeInserter) callCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.calls)
}

func (f *fakeInserter) rowsInCall(i int) int {
	f.mu.Lock()
	defer f.mu.Unlock()
	if i >= len(f.calls) {
		return 0
	}
	return len(f.calls[i])
}

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func pos(mmsi uint32, ts time.Time) model.Position {
	return model.Position{MMSI: mmsi, Ts: ts, Lat: 22.5, Lon: 113.9}
}

func waitFor(t *testing.T, timeout time.Duration, cond func() bool, msg string) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal(msg)
}

func TestWriter_flushOnBatchSize(t *testing.T) {
	ins := &fakeInserter{}
	w := NewWriter(ins, WriterOptions{FlushInterval: time.Hour, BatchSize: 3, QueueSize: 100}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	base := time.Now()
	for i := 0; i < 3; i++ {
		if err := w.Enqueue(pos(uint32(100+i), base)); err != nil {
			t.Fatalf("Enqueue() error = %v", err)
		}
	}
	waitFor(t, 3*time.Second, func() bool { return ins.callCount() == 1 }, "flush by batch size did not happen")
	if got := ins.rowsInCall(0); got != 3 {
		t.Errorf("first flush rows = %d, want 3", got)
	}
}

func TestWriter_flushOnInterval(t *testing.T) {
	ins := &fakeInserter{}
	w := NewWriter(ins, WriterOptions{FlushInterval: 20 * time.Millisecond, BatchSize: 1000, QueueSize: 100}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	if err := w.Enqueue(pos(1, time.Now())); err != nil {
		t.Fatalf("Enqueue() error = %v", err)
	}
	waitFor(t, 3*time.Second, func() bool { return ins.callCount() >= 1 }, "flush by interval did not happen")
}

func TestWriter_queueFullDrops(t *testing.T) {
	ins := &fakeInserter{}
	w := NewWriter(ins, WriterOptions{FlushInterval: time.Hour, BatchSize: 1000, QueueSize: 2}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	base := time.Now()
	if err := w.Enqueue(pos(1, base)); err != nil {
		t.Fatal(err)
	}
	if err := w.Enqueue(pos(2, base)); err != nil {
		t.Fatal(err)
	}
	if err := w.Enqueue(pos(3, base)); err == nil {
		t.Fatal("Enqueue() expected ErrQueueFull when queue is full")
	}
}

func TestWriter_retryOnceThenDropOnFailure(t *testing.T) {
	ins := &fakeInserter{fail: true}
	w := NewWriter(ins, WriterOptions{FlushInterval: 10 * time.Millisecond, BatchSize: 1000, QueueSize: 100}, discardLogger())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go w.Run(ctx)

	if err := w.Enqueue(pos(1, time.Now())); err != nil {
		t.Fatal(err)
	}
	waitFor(t, 3*time.Second, func() bool {
		_, dropped := w.Stats()
		return dropped > 0
	}, "expected dropped counter to increase after failed retry")
	flushed, dropped := w.Stats()
	if flushed != 0 {
		t.Errorf("flushed = %d, want 0 (inserter always fails)", flushed)
	}
	if dropped == 0 {
		t.Errorf("dropped = %d, want > 0", dropped)
	}
}
