package pg

import (
	"context"
	"os"
	"testing"
	"time"
)

func TestMigrateAndPartitions(t *testing.T) {
	url := os.Getenv("TEST_DATABASE_URL")
	if url == "" {
		t.Skip("set TEST_DATABASE_URL (e.g. postgres://ais:ais@localhost:5432/ais?sslmode=disable) to run")
	}
	ctx := context.Background()
	pool, err := Connect(ctx, url)
	if err != nil {
		t.Fatalf("Connect() error = %v", err)
	}
	defer pool.Close()

	if err := Migrate(ctx, pool); err != nil {
		t.Fatalf("Migrate() error = %v", err)
	}
	// 幂等：重复执行不报错
	if err := Migrate(ctx, pool); err != nil {
		t.Fatalf("Migrate() second run error = %v", err)
	}

	now := time.Now().UTC()
	if err := EnsurePartitions(ctx, pool, now.Add(-time.Hour), now.Add(48*time.Hour)); err != nil {
		t.Fatalf("EnsurePartitions() error = %v", err)
	}

	if _, err := pool.Exec(ctx, `
		INSERT INTO ais_positions (mmsi, ts, lat, lon, sog, cog, heading, nav_status, msg_type, source)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
		123456789, now, 22.5, 113.9, 10.0, 90.0, 90, 0, 1, "test"); err != nil {
		t.Fatalf("insert into partition error = %v", err)
	}

	var n int64
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM ais_positions WHERE mmsi=$1`, 123456789).Scan(&n); err != nil {
		t.Fatal(err)
	}
	if n != 1 {
		t.Errorf("count = %d, want 1", n)
	}

	// 空间查询可用
	var intersects bool
	if err := pool.QueryRow(ctx, `
		SELECT ST_Intersects(geom, ST_SetSRID(ST_MakePoint(113.9, 22.5), 4326))
		FROM ais_positions WHERE mmsi=$1`, 123456789).Scan(&intersects); err != nil {
		t.Fatal(err)
	}
	if !intersects {
		t.Error("ST_Intersects = false, want true")
	}

	// 围栏/事件/元数据表可用
	var fenceCount int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM geofences`).Scan(&fenceCount); err != nil {
		t.Fatal(err)
	}
	var userCount int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM users`).Scan(&userCount); err != nil {
		t.Fatal(err)
	}
}
