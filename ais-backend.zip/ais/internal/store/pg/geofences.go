package pg

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"ais/internal/model"
	"ais/internal/store"
)

type Geofences struct {
	pool *pgxpool.Pool
}

func NewGeofences(pool *pgxpool.Pool) *Geofences {
	return &Geofences{pool: pool}
}

var _ store.GeofenceStore = (*Geofences)(nil)

const geofenceCols = `id, name, ST_AsGeoJSON(area), enabled, enter_alert, leave_alert, debounce_count, silence_timeout_min, created_at`

func scanGeofence(row pgx.Row) (model.Geofence, error) {
	var g model.Geofence
	var areaJSON []byte
	err := row.Scan(&g.ID, &g.Name, &areaJSON, &g.Enabled, &g.EnterAlert, &g.LeaveAlert,
		&g.DebounceCount, &g.SilenceTimeoutMin, &g.CreatedAt)
	if err != nil {
		return g, err
	}
	if err := json.Unmarshal(areaJSON, &g.Area); err != nil {
		return g, err
	}
	return g, nil
}

func (s *Geofences) List(ctx context.Context) ([]model.Geofence, error) {
	rows, err := s.pool.Query(ctx, `SELECT `+geofenceCols+` FROM geofences ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return collectGeofences(rows)
}

func (s *Geofences) ListEnabled(ctx context.Context) ([]model.Geofence, error) {
	rows, err := s.pool.Query(ctx, `SELECT `+geofenceCols+` FROM geofences WHERE enabled ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return collectGeofences(rows)
}

func collectGeofences(rows pgx.Rows) ([]model.Geofence, error) {
	var out []model.Geofence
	for rows.Next() {
		var g model.Geofence
		var areaJSON []byte
		if err := rows.Scan(&g.ID, &g.Name, &areaJSON, &g.Enabled, &g.EnterAlert, &g.LeaveAlert,
			&g.DebounceCount, &g.SilenceTimeoutMin, &g.CreatedAt); err != nil {
			return nil, err
		}
		if err := json.Unmarshal(areaJSON, &g.Area); err != nil {
			return nil, err
		}
		out = append(out, g)
	}
	return out, rows.Err()
}

func (s *Geofences) Get(ctx context.Context, id int64) (model.Geofence, error) {
	g, err := scanGeofence(s.pool.QueryRow(ctx,
		`SELECT `+geofenceCols+` FROM geofences WHERE id = $1`, id))
	if errors.Is(err, pgx.ErrNoRows) {
		return g, store.ErrNotFound
	}
	return g, err
}

func (s *Geofences) Create(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	areaJSON, err := g.Area.MarshalJSON()
	if err != nil {
		return g, err
	}
	return scanGeofence(s.pool.QueryRow(ctx, `
		INSERT INTO geofences (name, area, enabled, enter_alert, leave_alert, debounce_count, silence_timeout_min)
		VALUES ($1, ST_GeomFromGeoJSON($2), $3, $4, $5, $6, $7)
		RETURNING `+geofenceCols,
		g.Name, string(areaJSON), g.Enabled, g.EnterAlert, g.LeaveAlert, g.DebounceCount, g.SilenceTimeoutMin))
}

func (s *Geofences) Update(ctx context.Context, g model.Geofence) (model.Geofence, error) {
	areaJSON, err := g.Area.MarshalJSON()
	if err != nil {
		return g, err
	}
	updated, err := scanGeofence(s.pool.QueryRow(ctx, `
		UPDATE geofences SET
			name = $2, area = ST_GeomFromGeoJSON($3), enabled = $4,
			enter_alert = $5, leave_alert = $6, debounce_count = $7, silence_timeout_min = $8
		WHERE id = $1
		RETURNING `+geofenceCols,
		g.ID, g.Name, string(areaJSON), g.Enabled, g.EnterAlert, g.LeaveAlert, g.DebounceCount, g.SilenceTimeoutMin))
	if errors.Is(err, pgx.ErrNoRows) {
		return updated, store.ErrNotFound
	}
	return updated, err
}

func (s *Geofences) Delete(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM geofences WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return store.ErrNotFound
	}
	return nil
}

func (s *Geofences) Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT id, fence_id, mmsi, event_type, ts, COALESCE(lat, 0), COALESCE(lon, 0)
		FROM fence_events
		WHERE fence_id = $1 AND ts >= $2 AND ts < $3
		ORDER BY ts DESC LIMIT $4`,
		fenceID, start, end, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []model.FenceEvent
	for rows.Next() {
		var e model.FenceEvent
		if err := rows.Scan(&e.ID, &e.FenceID, &e.MMSI, &e.EventType, &e.Ts, &e.Lat, &e.Lon); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

func (s *Geofences) InsertEvent(ctx context.Context, e model.FenceEvent) error {
	_, err := s.pool.Exec(ctx, `
		INSERT INTO fence_events (fence_id, mmsi, event_type, ts, lat, lon)
		VALUES ($1,$2,$3,$4,$5,$6)`,
		e.FenceID, e.MMSI, e.EventType, e.Ts, e.Lat, e.Lon)
	return err
}

func (s *Geofences) DeleteEventsBefore(ctx context.Context, before time.Time) (int64, error) {
	tag, err := s.pool.Exec(ctx, `DELETE FROM fence_events WHERE ts < $1`, before)
	if err != nil {
		return 0, err
	}
	return tag.RowsAffected(), nil
}
