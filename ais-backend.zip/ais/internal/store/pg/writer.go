package pg

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"ais/internal/model"
)

var ErrQueueFull = errors.New("writer queue full")

type Inserter interface {
	InsertBatch(ctx context.Context, rows []model.Position) error
}

type WriterOptions struct {
	FlushInterval time.Duration
	BatchSize     int
	QueueSize     int
}

type Writer struct {
	inserter Inserter
	opts     WriterOptions
	log      *slog.Logger

	ch      chan model.Position
	buf     []model.Position
	flushed uint64
	dropped uint64
}

func NewWriter(inserter Inserter, opts WriterOptions, log *slog.Logger) *Writer {
	if opts.FlushInterval <= 0 {
		opts.FlushInterval = time.Second
	}
	if opts.BatchSize <= 0 {
		opts.BatchSize = 1000
	}
	if opts.QueueSize <= 0 {
		opts.QueueSize = 100000
	}
	return &Writer{
		inserter: inserter,
		opts:     opts,
		log:      log,
		ch:       make(chan model.Position, opts.QueueSize),
	}
}

// Enqueue adds a position to the write queue. Returns ErrQueueFull when the
// queue is full (the message is dropped and counted).
func (w *Writer) Enqueue(p model.Position) error {
	select {
	case w.ch <- p:
		return nil
	default:
		w.dropped++
		w.log.Error("writer queue full, dropping position",
			"mmsi", p.MMSI, "dropped_total", w.dropped)
		return ErrQueueFull
	}
}

func (w *Writer) Run(ctx context.Context) {
	ticker := time.NewTicker(w.opts.FlushInterval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			w.finalFlush()
			return
		case p := <-w.ch:
			w.buf = append(w.buf, p)
			if len(w.buf) >= w.opts.BatchSize {
				w.flush(context.Background())
			}
		case <-ticker.C:
			w.flush(context.Background())
		}
	}
}

func (w *Writer) flush(ctx context.Context) {
	if len(w.buf) == 0 {
		return
	}
	rows := w.buf
	w.buf = nil
	if err := w.inserter.InsertBatch(ctx, rows); err != nil {
		w.log.Error("flush positions failed", "err", err, "rows", len(rows))
		time.Sleep(time.Second)
		if err2 := w.inserter.InsertBatch(context.Background(), rows); err2 != nil {
			w.log.Error("flush positions retry failed, dropping batch", "err", err2, "rows", len(rows))
			w.dropped += uint64(len(rows))
			return
		}
	}
	w.flushed += uint64(len(rows))
}

// finalFlush runs at shutdown with a bounded timeout so queued rows are not
// silently lost when the database is healthy.
func (w *Writer) finalFlush() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	w.flush(ctx)
}

func (w *Writer) Stats() (flushed, dropped uint64) {
	return w.flushed, w.dropped
}
