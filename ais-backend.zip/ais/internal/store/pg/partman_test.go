package pg

import (
	"testing"
	"time"
)

func TestPartitionName(t *testing.T) {
	got := PartitionName(time.Date(2026, 8, 7, 15, 30, 0, 0, time.UTC))
	if got != "ais_positions_20260807" {
		t.Errorf("PartitionName = %q, want ais_positions_20260807", got)
	}
}

func TestPartitionRange(t *testing.T) {
	from, to := PartitionRange(time.Date(2026, 8, 7, 15, 30, 0, 0, time.UTC))
	if from != time.Date(2026, 8, 7, 0, 0, 0, 0, time.UTC) {
		t.Errorf("from = %v, want 2026-08-07 00:00:00 UTC", from)
	}
	if to != time.Date(2026, 8, 8, 0, 0, 0, 0, time.UTC) {
		t.Errorf("to = %v, want 2026-08-08 00:00:00 UTC", to)
	}
}

func TestOldPartitions(t *testing.T) {
	before := time.Date(2026, 8, 7, 0, 0, 0, 0, time.UTC)
	names := []string{
		"ais_positions_20260801",
		"ais_positions_20260806",
		"ais_positions_20260807",
		"ais_positions_20260808",
		"not_a_partition",
	}
	old := OldPartitions(names, before)
	if len(old) != 2 {
		t.Fatalf("OldPartitions len = %d, want 2 (%v)", len(old), old)
	}
	if old[0] != "ais_positions_20260801" || old[1] != "ais_positions_20260806" {
		t.Errorf("OldPartitions = %v, want [ais_positions_20260801 ais_positions_20260806]", old)
	}
}
