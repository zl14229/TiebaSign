package pg

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

func PartitionName(t time.Time) string {
	return "ais_positions_" + t.UTC().Format("20060102")
}

func PartitionRange(t time.Time) (from, to time.Time) {
	day := t.UTC().Truncate(24 * time.Hour)
	return day, day.Add(24 * time.Hour)
}

func EnsurePartition(ctx context.Context, pool *pgxpool.Pool, t time.Time) error {
	name := PartitionName(t)
	from, to := PartitionRange(t)
	_, err := pool.Exec(ctx, fmt.Sprintf(
		"CREATE TABLE IF NOT EXISTS %s PARTITION OF ais_positions FOR VALUES FROM ($1) TO ($2)", name,
	), from, to)
	return err
}

func EnsurePartitions(ctx context.Context, pool *pgxpool.Pool, from, to time.Time) error {
	for d := from.UTC().Truncate(24 * time.Hour); d.Before(to); d = d.Add(24 * time.Hour) {
		if err := EnsurePartition(ctx, pool, d); err != nil {
			return fmt.Errorf("ensure partition %s: %w", PartitionName(d), err)
		}
	}
	return nil
}

func ListPartitions(ctx context.Context, pool *pgxpool.Pool) ([]string, error) {
	rows, err := pool.Query(ctx, `
		SELECT child.relname
		FROM pg_inherits
		JOIN pg_class parent ON pg_inherits.inhparent = parent.oid
		JOIN pg_class child  ON pg_inherits.inhrelid = child.oid
		WHERE parent.relname = 'ais_positions' AND child.relkind = 'r'
		ORDER BY child.relname`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return nil, err
		}
		out = append(out, name)
	}
	return out, rows.Err()
}

func OldPartitions(names []string, before time.Time) []string {
	cutoff := before.UTC().Truncate(24 * time.Hour)
	var out []string
	for _, n := range names {
		suffix := strings.TrimPrefix(n, "ais_positions_")
		d, err := time.Parse("20060102", suffix)
		if err != nil {
			continue
		}
		if d.Before(cutoff) {
			out = append(out, n)
		}
	}
	return out
}

func DropPartitionsBefore(ctx context.Context, pool *pgxpool.Pool, before time.Time) ([]string, error) {
	names, err := ListPartitions(ctx, pool)
	if err != nil {
		return nil, err
	}
	old := OldPartitions(names, before)
	for _, n := range old {
		if _, err := pool.Exec(ctx, "DROP TABLE IF EXISTS "+n); err != nil {
			return old, fmt.Errorf("drop partition %s: %w", n, err)
		}
	}
	return old, nil
}
