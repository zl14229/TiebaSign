// Package store defines repository interfaces implemented by the pg package.
package store

import (
	"context"
	"errors"
	"time"

	"ais/internal/model"
)

var ErrNotFound = errors.New("not found")

type PositionStore interface {
	InsertBatch(ctx context.Context, rows []model.Position) error
	Track(ctx context.Context, mmsi uint32, start, end time.Time, bucketSec int, limit int) ([]model.TrackPoint, error)
	LatestFallback(ctx context.Context) ([]model.Position, error)
	FenceHistoryVessels(ctx context.Context, fenceID int64, start, end time.Time) ([]uint32, error)
}

type GeofenceStore interface {
	List(ctx context.Context) ([]model.Geofence, error)
	ListEnabled(ctx context.Context) ([]model.Geofence, error)
	Get(ctx context.Context, id int64) (model.Geofence, error)
	Create(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Update(ctx context.Context, g model.Geofence) (model.Geofence, error)
	Delete(ctx context.Context, id int64) error
	Events(ctx context.Context, fenceID int64, start, end time.Time, limit int) ([]model.FenceEvent, error)
	InsertEvent(ctx context.Context, e model.FenceEvent) error
	DeleteEventsBefore(ctx context.Context, before time.Time) (int64, error)
}

type VesselStore interface {
	Upsert(ctx context.Context, v model.Vessel) error
	List(ctx context.Context, page, pageSize int, search string) ([]model.Vessel, int64, error)
}

type UserStore interface {
	Create(ctx context.Context, username, passwordHash, role string) (model.User, error)
	GetByUsername(ctx context.Context, username string) (model.User, error)
}
