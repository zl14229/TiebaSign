// Package nmea wraps go-ais to decode NMEA 0183 VDM/VDO sentences into
// domain positions and vessels.
package nmea

import (
	"strings"
	"time"

	ais "github.com/BertoldVdb/go-ais"
	"github.com/BertoldVdb/go-ais/aisnmea"

	"ais/internal/model"
)

type Result struct {
	Position *model.Position
	Vessel   *model.Vessel
}

// Parser wraps the go-ais NMEA codec. Multi-sentence reassembly is
// stateful, so one Parser instance must be used per station connection.
type Parser struct {
	codec *aisnmea.NMEACodec
}

func NewParser() *Parser {
	c := ais.CodecNew(false, false)
	c.DropSpace = true
	return &Parser{codec: aisnmea.NMEACodecNew(c)}
}

// Parse feeds one raw NMEA sentence. It returns (nil, nil) when the
// sentence is only a fragment of a multi-sentence message (reassembly
// continues internally), and an error when the sentence cannot be parsed.
func (p *Parser) Parse(raw string, station string, ts time.Time) (*Result, error) {
	pkt, err := p.codec.ParseSentence(raw)
	if err != nil {
		return nil, err
	}
	if pkt == nil || pkt.Packet == nil {
		return nil, nil
	}
	return mapPacket(pkt.Packet, station, ts), nil
}

func mapPacket(pkt ais.Packet, station string, ts time.Time) *Result {
	hdr := pkt.GetHeader()
	mmsi := hdr.UserID
	switch m := pkt.(type) {
	case ais.PositionReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), m.TrueHeading, uint16(m.NavigationalStatus), station, ts)
	case ais.BaseStationReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude), 0, 0, 0, 0, station, ts)
	case ais.StandardSearchAndRescueAircraftReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), 0, 0, station, ts)
	case ais.StandardClassBPositionReport:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), m.TrueHeading, 0, station, ts)
	case ais.ExtendedClassBPositionReport:
		r := pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), m.TrueHeading, 0, station, ts)
		if r == nil {
			return nil
		}
		r.Vessel = &model.Vessel{
			MMSI:      mmsi,
			Name:      strings.TrimSpace(m.Name),
			ShipType:  int16(m.Type),
			LengthM:   float32(m.Dimension.A + m.Dimension.B),
			BeamM:     float32(m.Dimension.C + m.Dimension.D),
			UpdatedAt: ts,
		}
		return r
	case ais.AidsToNavigationReport:
		r := pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude), 0, 0, 0, 0, station, ts)
		if r == nil {
			return nil
		}
		r.Vessel = &model.Vessel{
			MMSI:      mmsi,
			Name:      strings.TrimSpace(m.Name),
			ShipType:  30, // AtoN
			UpdatedAt: ts,
		}
		return r
	case ais.LongRangeAisBroadcastMessage:
		return pos(mmsi, hdr.MessageID, float64(m.Latitude), float64(m.Longitude),
			float32(m.Sog), float32(m.Cog), 0, uint16(m.NavigationalStatus), station, ts)
	case ais.ShipStaticData:
		v := &model.Vessel{
			MMSI:      mmsi,
			Name:      strings.TrimSpace(m.Name),
			Callsign:  strings.TrimSpace(m.CallSign),
			ShipType:  int16(m.Type),
			LengthM:   float32(m.Dimension.A + m.Dimension.B),
			BeamM:     float32(m.Dimension.C + m.Dimension.D),
			UpdatedAt: ts,
		}
		if m.ImoNumber > 0 {
			imo := m.ImoNumber
			v.IMO = &imo
		}
		return &Result{Vessel: v}
	case ais.StaticDataReport:
		v := &model.Vessel{MMSI: mmsi, UpdatedAt: ts}
		if !m.PartNumber {
			v.Name = strings.TrimSpace(m.ReportA.Name)
		} else {
			v.Callsign = strings.TrimSpace(m.ReportB.CallSign)
			v.ShipType = int16(m.ReportB.ShipType)
			v.LengthM = float32(m.ReportB.Dimension.A + m.ReportB.Dimension.B)
			v.BeamM = float32(m.ReportB.Dimension.C + m.ReportB.Dimension.D)
		}
		return &Result{Vessel: v}
	}
	return nil
}

// pos builds a Position result, rejecting out-of-range coordinates
// (including the AIS "not available" sentinels lat=91 / lon=181).
func pos(mmsi uint32, msgType uint8, lat, lon float64, sog, cog float32, heading, nav uint16, station string, ts time.Time) *Result {
	if lat < -90 || lat > 90 || lon < -180 || lon > 180 {
		return nil
	}
	return &Result{Position: &model.Position{
		MMSI: mmsi, Ts: ts, Lat: lat, Lon: lon,
		SOG: sog, COG: cog,
		Heading:   int16(heading),
		NavStatus: int16(nav),
		MsgType:   int16(msgType),
		Source:    station,
	}}
}
