package nmea

import (
	"math"
	"testing"
	"time"
)

// 以下语句来自 go-ais v0.4.0 测试数据（aisnmea/testdata/aistest.nmea）与
// decode_test.go，校验和均有效，解码期望值已交叉验证。
const (
	sentenceType1      = "!AIVDM,1,1,,B,177KQJ5000G?tO`K>RA1wUbN0TKH,0*5C"
	sentenceType5A     = "!AIVDM,2,1,6,B,53Jmvl82Bw3CTP7??K5<D5<lThF222222222221:I0oK;4e20L3FH42i,0*5C"
	sentenceType5B     = "!AIVDM,2,2,6,B,p88888888888880,2*69"
	sentenceType18     = "!AIVDM,1,1,,B,B52KlJP00=l4bhUItIG?Gwl5WP06,0*03"
	sentenceType24A    = "!AIVDM,1,1,,B,H6:iQG@p4q@tpO?K;P000000000,2*4D"
	sentenceNoPosition = "!AIVDM,1,1,,B,177nTc10?w<tSF0l4Q@>43Qv0>`<,0*6C" // lat=91 lon=181 哨兵
	sentenceNonVDM     = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A"
)

func approx(a, b, eps float64) bool { return math.Abs(a-b) < eps }

func TestParse_positionReportType1(t *testing.T) {
	p := NewParser()
	ts := time.Date(2026, 8, 7, 10, 0, 0, 0, time.UTC)
	res, err := p.Parse(sentenceType1, "st1", ts)
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res == nil || res.Position == nil {
		t.Fatal("expected a position result")
	}
	got := res.Position
	if got.MMSI != 477553000 {
		t.Errorf("MMSI = %d, want 477553000", got.MMSI)
	}
	if got.MsgType != 1 {
		t.Errorf("MsgType = %d, want 1", got.MsgType)
	}
	if !approx(got.Lat, 47.582833, 1e-6) {
		t.Errorf("Lat = %v, want ~47.582833", got.Lat)
	}
	if !approx(got.Lon, -122.345833, 1e-6) {
		t.Errorf("Lon = %v, want ~-122.345833", got.Lon)
	}
	if !approx(float64(got.COG), 51.0, 1e-6) {
		t.Errorf("COG = %v, want 51.0", got.COG)
	}
	if got.Heading != 181 {
		t.Errorf("Heading = %d, want 181", got.Heading)
	}
	if got.NavStatus != 5 {
		t.Errorf("NavStatus = %d, want 5", got.NavStatus)
	}
	if got.Source != "st1" {
		t.Errorf("Source = %q, want st1", got.Source)
	}
	if !got.Ts.Equal(ts) {
		t.Errorf("Ts = %v, want %v", got.Ts, ts)
	}
}

func TestParse_classBPositionReportType18(t *testing.T) {
	p := NewParser()
	res, err := p.Parse(sentenceType18, "st2", time.Now())
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res == nil || res.Position == nil {
		t.Fatal("expected a position result")
	}
	if res.Position.MMSI != 338097258 {
		t.Errorf("MMSI = %d, want 338097258", res.Position.MMSI)
	}
	if !approx(res.Position.Lat, 37.786275, 1e-6) || !approx(res.Position.Lon, -122.270132, 1e-6) {
		t.Errorf("position = (%v, %v), want (~37.786275, ~-122.270132)", res.Position.Lat, res.Position.Lon)
	}
}

func TestParse_multiSentenceType5(t *testing.T) {
	p := NewParser()
	ts := time.Now()
	res, err := p.Parse(sentenceType5A, "st3", ts)
	if err != nil {
		t.Fatalf("Parse() fragment error = %v", err)
	}
	if res != nil {
		t.Fatalf("expected nil result for first fragment, got %+v", res)
	}
	res, err = p.Parse(sentenceType5B, "st3", ts)
	if err != nil {
		t.Fatalf("Parse() second fragment error = %v", err)
	}
	if res == nil || res.Vessel == nil {
		t.Fatal("expected a vessel result after reassembly")
	}
	v := res.Vessel
	if v.MMSI != 229474000 {
		t.Errorf("MMSI = %d, want 229474000", v.MMSI)
	}
	if v.Name != "SEASMILE" {
		t.Errorf("Name = %q, want SEASMILE", v.Name)
	}
	if v.Callsign != "9HA3361" {
		t.Errorf("Callsign = %q, want 9HA3361", v.Callsign)
	}
	if v.IMO == nil || *v.IMO != 9632820 {
		t.Errorf("IMO = %v, want 9632820", v.IMO)
	}
	if v.ShipType != 74 {
		t.Errorf("ShipType = %d, want 74", v.ShipType)
	}
}

func TestParse_staticDataReportType24PartA(t *testing.T) {
	p := NewParser()
	res, err := p.Parse(sentenceType24A, "st4", time.Now())
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res == nil || res.Vessel == nil {
		t.Fatal("expected a vessel result")
	}
	if res.Vessel.MMSI != 413950301 {
		t.Errorf("MMSI = %d, want 413950301", res.Vessel.MMSI)
	}
	if res.Vessel.Name != "NANTONG3628" {
		t.Errorf("Name = %q, want NANTONG3628", res.Vessel.Name)
	}
}

func TestParse_invalidPositionReturnsNil(t *testing.T) {
	p := NewParser()
	res, err := p.Parse(sentenceNoPosition, "st5", time.Now())
	if err != nil {
		t.Fatalf("Parse() error = %v", err)
	}
	if res != nil {
		t.Fatalf("expected nil result for invalid position, got %+v", res)
	}
}

func TestParse_nonVDMSentenceReturnsError(t *testing.T) {
	p := NewParser()
	if _, err := p.Parse(sentenceNonVDM, "st6", time.Now()); err == nil {
		t.Fatal("expected error for non-VDM sentence")
	}
}
