package wshub

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

func TestHub_broadcastToClient(t *testing.T) {
	hub := NewHub()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go hub.Run(ctx)

	ts := httptest.NewServer(http.HandlerFunc(hub.ServeWS))
	defer ts.Close()

	wsURL := "ws" + strings.TrimPrefix(ts.URL, "http") + "/ws"
	conn, _, err := websocket.DefaultDialer.Dial(wsURL, nil)
	if err != nil {
		t.Fatalf("dial error = %v", err)
	}
	defer conn.Close()

	waitUntil(t, 3*time.Second, func() bool { return hub.Connections() == 1 }, "client did not register")

	hub.Broadcast([]byte(`{"type":"position"}`))
	_ = conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	_, data, err := conn.ReadMessage()
	if err != nil {
		t.Fatalf("ReadMessage() error = %v", err)
	}
	if string(data) != `{"type":"position"}` {
		t.Errorf("got %s, want {\"type\":\"position\"}", data)
	}
}

func TestHub_broadcastToMultipleClients(t *testing.T) {
	hub := NewHub()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go hub.Run(ctx)

	ts := httptest.NewServer(http.HandlerFunc(hub.ServeWS))
	defer ts.Close()
	wsURL := "ws" + strings.TrimPrefix(ts.URL, "http") + "/ws"

	conns := make([]*websocket.Conn, 3)
	for i := range conns {
		c, _, err := websocket.DefaultDialer.Dial(wsURL, nil)
		if err != nil {
			t.Fatalf("dial %d error = %v", i, err)
		}
		defer c.Close()
		conns[i] = c
	}
	waitUntil(t, 3*time.Second, func() bool { return hub.Connections() == 3 }, "clients did not register")

	hub.Broadcast([]byte("hello"))
	for _, c := range conns {
		_ = c.SetReadDeadline(time.Now().Add(3 * time.Second))
		if _, data, err := c.ReadMessage(); err != nil || string(data) != "hello" {
			t.Errorf("client got %q, err %v; want hello", data, err)
		}
	}
}

func waitUntil(t *testing.T, timeout time.Duration, cond func() bool, msg string) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal(msg)
}
