#!/bin/sh
# AIS 数据库备份：pg_basebackup（物理备份，tar+压缩）→ 本地保留 + 上传阿里云 OSS
# 由 compose 的 backup 服务常驻运行，BACKUP_INTERVAL_HOURS 控制间隔。
set -eu

: "${PGHOST:=postgis}"
: "${PGPORT:=5432}"
: "${PGUSER:=ais}"
: "${POSTGRES_PASSWORD:=ais}"
: "${BACKUP_DIR:=/backup/data}"
: "${BACKUP_KEEP_DAYS:=7}"
: "${BACKUP_INTERVAL_HOURS:=24}"

export PGPASSWORD="${POSTGRES_PASSWORD}"

run_backup() {
    ts="$(date -u +%Y%m%dT%H%M%SZ)"
    dest="${BACKUP_DIR}/${ts}"
    mkdir -p "${dest}"

    echo "[backup] start pg_basebackup -> ${dest}"
    pg_basebackup -h "${PGHOST}" -p "${PGPORT}" -U "${PGUSER}" \
        -D "${dest}" -Ft -z -P

    if [ -n "${OSS_BUCKET:-}" ] && [ -n "${OSS_ENDPOINT:-}" ]; then
        echo "[backup] upload to oss://${OSS_BUCKET}/ais-backup/${ts}/"
        for f in "${dest}"/*.tar.gz; do
            [ -e "$f" ] || continue
            ossutil -e "${OSS_ENDPOINT}" -i "${OSS_ACCESS_KEY_ID}" -k "${OSS_ACCESS_KEY_SECRET}" \
                cp "$f" "oss://${OSS_BUCKET}/ais-backup/${ts}/$(basename "$f")" --force >/dev/null
        done
        rm -rf "${dest}"
        echo "[backup] uploaded and removed local copy"
    else
        echo "[backup] OSS not configured, keep local copy"
    fi

    # 清理本地超过 BACKUP_KEEP_DAYS 的备份
    find "${BACKUP_DIR}" -mindepth 1 -maxdepth 1 -mtime "+${BACKUP_KEEP_DAYS}" -exec rm -rf {} +
    echo "[backup] done"
}

echo "[backup] container started, interval=${BACKUP_INTERVAL_HOURS}h"
while :; do
    run_backup || echo "[backup] run failed, will retry next interval"
    sleep "$((BACKUP_INTERVAL_HOURS * 3600))"
done
