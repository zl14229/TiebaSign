// Command ais is the AIS gateway + API binary.
//
// Subcommands:
//
//	ais run           启动 gateway + api（默认）
//	ais user-create -username admin -password x [-role admin]
//	ais maintenance    手动执行分区与事件清理
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"golang.org/x/crypto/bcrypt"

	"ais/internal/api"
	"ais/internal/cache"
	"ais/internal/config"
	"ais/internal/dedup"
	"ais/internal/fence"
	"ais/internal/logging"
	"ais/internal/metrics"
	"ais/internal/model"
	"ais/internal/pipeline"
	"ais/internal/station"
	"ais/internal/store/pg"
	"ais/internal/wshub"
)

func main() {
	sub := "run"
	if len(os.Args) > 1 {
		sub = os.Args[1]
	}
	var err error
	switch sub {
	case "run":
		err = runServer()
	case "user-create":
		err = runUserCreate()
	case "maintenance":
		err = runMaintenance()
	default:
		err = fmt.Errorf("unknown subcommand %q (expected run, user-create, maintenance)", sub)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "fatal:", err)
		os.Exit(1)
	}
}

func loadConfig() (config.Config, *slog.Logger, error) {
	cfg, err := config.Load()
	if err != nil {
		return cfg, nil, err
	}
	return cfg, logging.New(cfg.LogLevel), nil
}

func runServer() error {
	cfg, log, err := loadConfig()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	pool, err := pg.Connect(ctx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect postgres: %w", err)
	}
	defer pool.Close()
	if err := pg.Migrate(ctx, pool); err != nil {
		return fmt.Errorf("migrate: %w", err)
	}

	positions := pg.NewPositions(pool)
	geofences := pg.NewGeofences(pool)
	vessels := pg.NewVessels(pool)
	users := pg.NewUsers(pool)

	writer := pg.NewWriter(positions, pg.WriterOptions{
		FlushInterval: cfg.WriterFlushInterval,
		BatchSize:     cfg.WriterBatchSize,
		QueueSize:     cfg.WriterQueueSize,
	}, log)
	go writer.Run(ctx)

	redisClient := cache.New(cfg.RedisAddr, cfg.RedisPassword)
	if err := redisClient.Ping(ctx); err != nil {
		return fmt.Errorf("connect redis: %w", err)
	}
	defer redisClient.Close()

	posHub := wshub.NewHub()
	eventHub := wshub.NewHub()
	go posHub.Run(ctx)
	go eventHub.Run(ctx)

	engine := fence.NewEngine(geofences, redisClient, geofences, fence.Options{
		ReloadInterval: cfg.FenceReloadInterval,
		SilenceTimeout: cfg.FenceSilenceTimeout,
		DebounceCount:  cfg.FenceDebounceCount,
	}, log)
	go engine.Run(ctx)

	pipe := pipeline.New(pipeline.PipelineOptions{
		Writer:      writer,
		Latest:      redisClient,
		Publisher:   redisClient,
		Engine:      engine,
		VesselStore: vessels,
		Dedup:       dedup.New(30*time.Second, 1_000_000),
	}, log)
	mgr := station.NewManager(stationConfigs(cfg.Stations), pipe, station.Options{
		ConnectTimeout: cfg.StationConnectTimeout,
		ReconnectBase:  cfg.StationReconnectBase,
		ReconnectMax:   cfg.StationReconnectMax,
		IdleTimeout:    cfg.StationIdleTimeout,
		ReadBufSize:    65536,
	}, log)
	go mgr.Run(ctx)

	// 订阅 Redis pub/sub → 本地 WebSocket 扇出（多实例时各实例消费同一频道）
	posCh, posErr := redisClient.SubscribePositions(ctx)
	eventCh, eventErr := redisClient.SubscribeFenceEvents(ctx)
	go func() {
		for {
			select {
			case p, ok := <-posCh:
				if !ok {
					return
				}
				posHub.Broadcast(envelope("position", p))
			case err := <-posErr:
				log.Error("position subscription ended", "err", err)
				return
			case <-ctx.Done():
				return
			}
		}
	}()
	go func() {
		for {
			select {
			case e, ok := <-eventCh:
				if !ok {
					return
				}
				metrics.FenceEvents.WithLabelValues(eventTypeLabel(e.EventType)).Inc()
				eventHub.Broadcast(envelope("fence_event", e))
			case err := <-eventErr:
				log.Error("fence event subscription ended", "err", err)
				return
			case <-ctx.Done():
				return
			}
		}
	}()

	// WS 连接数指标
	go func() {
		ticker := time.NewTicker(10 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				metrics.WSConnections.Set(float64(posHub.Connections() + eventHub.Connections()))
			case <-ctx.Done():
				return
			}
		}
	}()

	// 分区维护（自愈：每小时确保分区存在 + 每日清理超期分区与事件）
	go runMaintenanceLoop(ctx, pool, cfg, log)

	srv := &api.Server{
		Cfg:        api.ServerConfig{JWTSecret: cfg.JWTSecret, JWTTTL: cfg.JWTTTL},
		Positions:  positions,
		Latest:     redisClient,
		Vessels:    vessels,
		Users:      users,
		Geofences:  geofences,
		PosHub:     posHub,
		EventHub:   eventHub,
		StationMgr: mgr,
		Log:        log,
	}
	httpServer := &http.Server{
		Addr:              cfg.HTTPAddr,
		Handler:           srv.Handler(),
		ReadHeaderTimeout: 10 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() { errCh <- httpServer.ListenAndServe() }()
	log.Info("ais server started", "addr", cfg.HTTPAddr)

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		log.Info("shutting down")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		return httpServer.Shutdown(shutdownCtx)
	}
}

func stationConfigs(cfgs []config.Station) []station.Config {
	out := make([]station.Config, 0, len(cfgs))
	for _, c := range cfgs {
		out = append(out, station.Config{ID: c.ID, Name: c.Name, Host: c.Host, Port: c.Port, Enabled: c.Enabled})
	}
	return out
}

func envelope(kind string, data any) []byte {
	b, err := json.Marshal(map[string]any{"type": kind, "data": data})
	if err != nil {
		return nil
	}
	return b
}

func eventTypeLabel(t int16) string {
	if t == model.EventTypeLeave {
		return "leave"
	}
	return "enter"
}

func runUserCreate() error {
	fs := flag.NewFlagSet("user-create", flag.ExitOnError)
	username := fs.String("username", "", "login name")
	password := fs.String("password", "", "password")
	role := fs.String("role", "user", "role (user/admin)")
	_ = fs.Parse(os.Args[2:])
	if *username == "" || *password == "" {
		return errors.New("--username and --password are required")
	}
	cfg, log, err := loadConfig()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	pool, err := pg.Connect(ctx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect postgres: %w", err)
	}
	defer pool.Close()
	hash, err := bcrypt.GenerateFromPassword([]byte(*password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	u, err := pg.NewUsers(pool).Create(ctx, *username, string(hash), *role)
	if err != nil {
		return fmt.Errorf("create user: %w", err)
	}
	log.Info("user created", "id", u.ID, "username", u.Username, "role", u.Role)
	return nil
}

func runMaintenance() error {
	cfg, log, err := loadConfig()
	if err != nil {
		return err
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	pool, err := pg.Connect(ctx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect postgres: %w", err)
	}
	defer pool.Close()
	now := time.Now().UTC()
	if err := pg.EnsurePartitions(ctx, pool, now, now.Add(48*time.Hour)); err != nil {
		return fmt.Errorf("ensure partitions: %w", err)
	}
	before := now.AddDate(0, 0, -cfg.RetentionDays)
	dropped, err := pg.DropPartitionsBefore(ctx, pool, before)
	if err != nil {
		return fmt.Errorf("drop partitions: %w", err)
	}
	deleted, err := pg.NewGeofences(pool).DeleteEventsBefore(ctx, before)
	if err != nil {
		return fmt.Errorf("delete events: %w", err)
	}
	log.Info("maintenance done", "dropped_partitions", len(dropped), "deleted_events", deleted)
	return nil
}

func runMaintenanceLoop(ctx context.Context, pool *pgxpool.Pool, cfg config.Config, log *slog.Logger) {
	ticker := time.NewTicker(6 * time.Hour)
	defer ticker.Stop()
	run := func() {
		now := time.Now().UTC()
		if err := pg.EnsurePartitions(ctx, pool, now, now.Add(48*time.Hour)); err != nil {
			log.Error("ensure partitions failed", "err", err)
			return
		}
		dropped, err := pg.DropPartitionsBefore(ctx, pool, now.AddDate(0, 0, -cfg.RetentionDays))
		if err != nil {
			log.Error("drop partitions failed", "err", err)
			return
		}
		if len(dropped) > 0 {
			log.Info("dropped stale partitions", "names", dropped)
		}
		if _, err := pg.NewGeofences(pool).DeleteEventsBefore(ctx, now.AddDate(0, 0, -cfg.RetentionDays)); err != nil {
			log.Error("clean events failed", "err", err)
		}
	}
	run()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			run()
		}
	}
}
